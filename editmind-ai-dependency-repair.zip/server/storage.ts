import fs from 'node:fs';
import path from 'node:path';
import { config, ensureStorageDirectories } from './config.ts';

export type StorageBucket = 'uploads' | 'temp' | 'exports';

function getBucketDir(bucket: StorageBucket): string {
  switch (bucket) {
    case 'uploads':
      return config.uploadsDir;
    case 'temp':
      return config.tempDir;
    case 'exports':
      return config.exportsDir;
  }
}

export function resolveSafeStoragePath(bucket: StorageBucket, ...segments: string[]): string {
  const baseDir = path.resolve(getBucketDir(bucket));
  const sanitized = segments.map((s) => s.replace(/[^a-zA-Z0-9._-]/g, '_'));
  const resolved = path.resolve(baseDir, ...sanitized);
  if (resolved !== baseDir && !resolved.startsWith(baseDir + path.sep)) {
    throw new Error('Invalid storage path outside confined directory.');
  }
  return resolved;
}

export function ensureUserMediaDirectories(userId: string): {
  userUploadsDir: string;
  userThumbsDir: string;
  userTempDir: string;
} {
  ensureStorageDirectories();
  const userUploadsDir = resolveSafeStoragePath('uploads', userId);
  const userThumbsDir = resolveSafeStoragePath('uploads', userId, 'thumbs');
  const userTempDir = resolveSafeStoragePath('temp', 'uploads', userId);

  fs.mkdirSync(userUploadsDir, { recursive: true });
  fs.mkdirSync(userThumbsDir, { recursive: true });
  fs.mkdirSync(userTempDir, { recursive: true });

  return { userUploadsDir, userThumbsDir, userTempDir };
}

export function ensureUserSceneThumbsDir(userId: string, mediaId: string): string {
  ensureUserMediaDirectories(userId);
  const sceneDir = resolveSafeStoragePath('uploads', userId, 'thumbs', 'scenes', mediaId);
  fs.mkdirSync(sceneDir, { recursive: true });
  return sceneDir;
}

export function safeUnlink(filePath: string | null | undefined): void {
  if (!filePath) return;
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch {
    // Best-effort cleanup
  }
}

export function safeRmDir(dirPath: string | null | undefined): void {
  if (!dirPath) return;
  try {
    if (fs.existsSync(dirPath)) {
      fs.rmSync(dirPath, { recursive: true, force: true });
    }
  } catch {
    // Best-effort cleanup
  }
}

export function sweepExpiredTempFiles(): number {
  ensureStorageDirectories();
  const cutoff = Date.now() - config.tempFileTtlMs;
  let removedCount = 0;

  const walkAndPrune = (dir: string): void => {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walkAndPrune(fullPath);
        const remaining = fs.readdirSync(fullPath);
        if (remaining.length === 0) {
          fs.rmdirSync(fullPath);
        }
      } else if (entry.isFile()) {
        const stat = fs.statSync(fullPath);
        if (stat.mtimeMs < cutoff) {
          fs.unlinkSync(fullPath);
          removedCount += 1;
        }
      }
    }
  };

  walkAndPrune(config.tempDir);
  return removedCount;
}

export function getStorageStats(): {
  dataDir: string;
  availableBytes: number | null;
  totalBytes: number | null;
  ephemeralWarning: string;
} {
  ensureStorageDirectories();
  try {
    const stats = fs.statfsSync(config.dataDir);
    const availableBytes = Number(stats.bavail) * Number(stats.bsize);
    const totalBytes = Number(stats.blocks) * Number(stats.bsize);
    return {
      dataDir: config.dataDir,
      availableBytes,
      totalBytes,
      ephemeralWarning:
        'Local container storage is ephemeral across redeploys. Production deployments should mount S3-compatible object storage (MinIO/R2/S3).',
    };
  } catch {
    return {
      dataDir: config.dataDir,
      availableBytes: null,
      totalBytes: null,
      ephemeralWarning: 'Storage telemetry unavailable on this host.',
    };
  }
}
