import { execFile } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);

export const ALLOWED_AUDIO_EXTENSIONS = new Set(['.mp3', '.wav', '.aac', '.flac']);
export const ALLOWED_VIDEO_EXTENSIONS = new Set(['.mp4', '.mov']);

export const EXTENSION_MIME_MAP: Record<string, string> = {
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.aac': 'audio/aac',
  '.flac': 'audio/flac',
  '.mp4': 'video/mp4',
  '.mov': 'video/quicktime',
};

export interface ProbeResult {
  valid: boolean;
  error?: string;
  durationSec: number;
  codecName: string;
  width: number | null;
  height: number | null;
  sampleRate: number | null;
  channels: number | null;
}

interface FFprobeStream {
  codec_type?: string;
  codec_name?: string;
  width?: number;
  height?: number;
  sample_rate?: string;
  channels?: number;
  duration?: string;
}

interface FFprobeOutput {
  streams?: FFprobeStream[];
  format?: {
    duration?: string;
    format_name?: string;
  };
}

export function sanitizeDisplayFilename(rawName: string): string {
  const base = path.basename(rawName || 'media');
  const cleaned = base.replace(/[\u0000-\u001f<>:"/\\|?*]/g, '_').trim();
  return cleaned.slice(0, 140) || 'media';
}

export function getValidatedExtension(
  originalName: string,
  mediaKind: 'audio' | 'video'
): string | null {
  const ext = path.extname(originalName || '').toLowerCase();
  if (mediaKind === 'audio') {
    return ALLOWED_AUDIO_EXTENSIONS.has(ext) ? ext : null;
  }
  return ALLOWED_VIDEO_EXTENSIONS.has(ext) ? ext : null;
}

export async function probeMediaFile(
  filePath: string,
  expectedKind: 'audio' | 'video'
): Promise<ProbeResult> {
  try {
    const { stdout } = await execFileAsync(
      'ffprobe',
      ['-v', 'quiet', '-print_format', 'json', '-show_format', '-show_streams', filePath],
      { timeout: 15000, maxBuffer: 2 * 1024 * 1024 }
    );

    const parsed = JSON.parse(stdout) as FFprobeOutput;
    const streams = Array.isArray(parsed.streams) ? parsed.streams : [];
    const formatDuration = Number(parsed.format?.duration || 0);

    if (expectedKind === 'audio') {
      const audioStream = streams.find((s) => s.codec_type === 'audio');
      if (!audioStream) {
        return {
          valid: false,
          error: 'No valid audio stream detected inside uploaded file.',
          durationSec: 0,
          codecName: '',
          width: null,
          height: null,
          sampleRate: null,
          channels: null,
        };
      }
      const streamDuration = Number(audioStream.duration || 0);
      const durationSec = Number.isFinite(formatDuration) && formatDuration > 0
        ? formatDuration
        : Number.isFinite(streamDuration) && streamDuration > 0
        ? streamDuration
        : 0;

      if (durationSec <= 0) {
        return {
          valid: false,
          error: 'Audio duration could not be verified or file is empty.',
          durationSec: 0,
          codecName: audioStream.codec_name || '',
          width: null,
          height: null,
          sampleRate: null,
          channels: null,
        };
      }

      const sampleRate = audioStream.sample_rate ? Number(audioStream.sample_rate) : null;
      return {
        valid: true,
        durationSec,
        codecName: audioStream.codec_name || 'audio',
        width: null,
        height: null,
        sampleRate: sampleRate && Number.isFinite(sampleRate) ? sampleRate : null,
        channels: typeof audioStream.channels === 'number' ? audioStream.channels : null,
      };
    }

    const videoStream = streams.find((s) => s.codec_type === 'video');
    if (!videoStream) {
      return {
        valid: false,
        error: 'No valid video stream detected inside uploaded file.',
        durationSec: 0,
        codecName: '',
        width: null,
        height: null,
        sampleRate: null,
        channels: null,
      };
    }

    const streamDuration = Number(videoStream.duration || 0);
    const durationSec = Number.isFinite(formatDuration) && formatDuration > 0
      ? formatDuration
      : Number.isFinite(streamDuration) && streamDuration > 0
      ? streamDuration
      : 0;

    if (durationSec <= 0) {
      return {
        valid: false,
        error: 'Video duration could not be verified or file is empty.',
        durationSec: 0,
        codecName: videoStream.codec_name || '',
        width: null,
        height: null,
        sampleRate: null,
        channels: null,
      };
    }

    const audioStream = streams.find((s) => s.codec_type === 'audio');
    const sampleRate = audioStream?.sample_rate ? Number(audioStream.sample_rate) : null;

    return {
      valid: true,
      durationSec,
      codecName: videoStream.codec_name || 'video',
      width: typeof videoStream.width === 'number' ? videoStream.width : null,
      height: typeof videoStream.height === 'number' ? videoStream.height : null,
      sampleRate: sampleRate && Number.isFinite(sampleRate) ? sampleRate : null,
      channels: typeof audioStream?.channels === 'number' ? audioStream.channels : null,
    };
  } catch {
    return {
      valid: false,
      error: 'Uploaded file could not be parsed as valid media by FFprobe.',
      durationSec: 0,
      codecName: '',
      width: null,
      height: null,
      sampleRate: null,
      channels: null,
    };
  }
}

export async function generateVideoThumbnail(
  videoPath: string,
  thumbPath: string,
  durationSec: number
): Promise<boolean> {
  const seekSec = durationSec > 2 ? Math.min(durationSec * 0.25, 3).toFixed(2) : '0.10';
  try {
    await execFileAsync(
      'ffmpeg',
      [
        '-y',
        '-ss',
        seekSec,
        '-i',
        videoPath,
        '-vframes',
        '1',
        '-vf',
        'scale=480:-2',
        '-q:v',
        '4',
        thumbPath,
      ],
      { timeout: 15000 }
    );
    return fs.existsSync(thumbPath) && fs.statSync(thumbPath).size > 0;
  } catch {
    return false;
  }
}

export async function generateLowDataVideoProxy(
  videoPath: string,
  proxyPath: string
): Promise<boolean> {
  try {
    await execFileAsync(
      'ffmpeg',
      [
        '-y',
        '-i',
        videoPath,
        '-vf',
        'scale=-2:480',
        '-c:v',
        'libx264',
        '-preset',
        'veryfast',
        '-crf',
        '28',
        '-c:a',
        'aac',
        '-b:a',
        '96k',
        '-movflags',
        '+faststart',
        proxyPath,
      ],
      { timeout: 60000 }
    );
    return fs.existsSync(proxyPath) && fs.statSync(proxyPath).size > 0;
  } catch {
    return false;
  }
}
