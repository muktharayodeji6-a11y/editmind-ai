import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import type { EngineModuleDescriptor } from './contracts.ts';
import { getStorageStats } from '../storage.ts';

const execFileAsync = promisify(execFile);

export interface BinaryProbe {
  name: string;
  available: boolean;
  version: string | null;
}

async function probeBinary(cmd: string, args: string[]): Promise<BinaryProbe> {
  try {
    const { stdout, stderr } = await execFileAsync(cmd, args, { timeout: 3000 });
    const raw = (stdout || stderr || '').trim().split('\n')[0] || '';
    return {
      name: cmd,
      available: true,
      version: raw.slice(0, 120) || 'installed',
    };
  } catch {
    return {
      name: cmd,
      available: false,
      version: null,
    };
  }
}

export const ENGINE_MODULES: EngineModuleDescriptor[] = [
  {
    id: 'beat-intelligence',
    name: 'Beat Intelligence',
    milestoneTarget: 3,
    status: 'active',
    provider: 'Self-hosted DSP (FFmpeg PCM + Multi-Band Spectral Flux + DP Beat Tracker)',
    summary: 'Detects BPM, beat grids, downbeats, tempo shifts, and high-energy transients from uploaded audio.',
    outputs: ['BPM estimate', 'Beat timestamps', 'Downbeat markers', 'Transient peaks'],
    externalDependencyPolicy: 'Local open-source audio analysis; zero external LLM calls.',
  },
  {
    id: 'music-intelligence',
    name: 'Music Intelligence',
    milestoneTarget: 3,
    status: 'active',
    provider: 'Self-hosted Structural Novelty & Energy Curve Analyzer',
    summary: 'Segments tracks into intro, verse, chorus, build-up, drop, and outro regions using acoustic energy shifts.',
    outputs: ['Section boundaries', 'Energy envelope', 'Drop indicators'],
    externalDependencyPolicy: 'Local self-similarity matrix & RMS energy curves.',
  },
  {
    id: 'video-intelligence',
    name: 'Video Intelligence',
    milestoneTarget: 4,
    status: 'active',
    provider:
      'Self-hosted FFprobe + FFmpeg (scdet, blackdetect, freezedetect) + Node Optical-Flow & Saliency CV',
    summary:
      'Extracts shot cuts, camera motion type, optical-flow intensity, black/frozen unusable footage, scene thumbnails, and visual saliency signals.',
    outputs: [
      'Stream metadata & orientation',
      'Shot boundaries & thumbnails',
      'Camera movement & motion intensity',
      'Usability flags & visual saliency',
    ],
    externalDependencyPolicy: 'Self-hosted FFmpeg/FFprobe & pixel-stream CV; zero mandatory commercial APIs.',
  },
  {
    id: 'editing-intelligence',
    name: 'Editing Intelligence',
    milestoneTarget: 5,
    status: 'planned',
    provider: 'EDITMIND Constraint-Based Sequence Solver',
    summary: 'Maps musical structure and beat grids to candidate video moments based on the selected editing style.',
    outputs: ['Timeline EDL', 'Clip in/out points', 'Pacing curve'],
    externalDependencyPolicy: 'Independent rule & scoring engine built in-house.',
  },
  {
    id: 'transition-intelligence',
    name: 'Transition Intelligence',
    milestoneTarget: 5,
    status: 'planned',
    provider: 'Rhythm & Motion Continuity Selector',
    summary: 'Assigns hard cuts, crossfades, or kinetic transitions synchronized to downbeats and visual flow.',
    outputs: ['Transition assignments', 'Duration curves'],
    externalDependencyPolicy: 'Deterministic + style-weighted FFmpeg filtergraph mapping.',
  },
  {
    id: 'quality-intelligence',
    name: 'Quality Intelligence',
    milestoneTarget: 7,
    status: 'planned',
    provider: 'FFprobe Stream & Sync Verifier',
    summary: 'Verifies A/V stream integrity, duration parity, codec compliance, and playable MP4 output before export.',
    outputs: ['Stream validation', 'A/V sync check', 'Export readiness flag'],
    externalDependencyPolicy: 'Local FFprobe verification on every rendered export.',
  },
];

export async function inspectSystemCapabilities() {
  const [ffmpeg, ffprobe, python3] = await Promise.all([
    probeBinary('ffmpeg', ['-version']),
    probeBinary('ffprobe', ['-version']),
    probeBinary('python3', ['--version']),
  ]);

  const storage = getStorageStats();

  return {
    milestone: 4,
    runtime: {
      nodeVersion: process.version,
      platform: process.platform,
      arch: process.arch,
      databaseEngine: 'node:sqlite (SQLite WAL)',
    },
    binaries: [ffmpeg, ffprobe, python3],
    storage,
    engineModules: ENGINE_MODULES,
    mobileOptimizationPolicy: {
      heavyProcessingLocation: 'server-only',
      autoModelDownloadsOnClient: false,
      autoMediaUploads: false,
      backgroundSync: false,
      resumableUploadsTargetMilestone: 2,
    },
    externalAiPolicy: {
      geminiMandatory: false,
      geminiConfigured: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'),
      coreEngineIndependence: 'Core editing, audio/video analysis, and FFmpeg rendering operate without commercial LLM APIs.',
    },
  };
}
