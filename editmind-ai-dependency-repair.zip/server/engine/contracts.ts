export type EngineModuleId =
  | 'beat-intelligence'
  | 'music-intelligence'
  | 'video-intelligence'
  | 'editing-intelligence'
  | 'transition-intelligence'
  | 'quality-intelligence';

export type ModuleImplementationStatus = 'planned' | 'active';

export interface EngineModuleDescriptor {
  id: EngineModuleId;
  name: string;
  milestoneTarget: number;
  status: ModuleImplementationStatus;
  provider: string;
  summary: string;
  outputs: string[];
  externalDependencyPolicy: string;
}

export interface TempoSegment {
  startSec: number;
  endSec: number;
  bpm: number;
}

export interface TempoChangeEvent {
  timestampSec: number;
  fromBpm: number;
  toBpm: number;
  deltaPercent: number;
}

export interface AudioSignificantEvent {
  type: 'silence' | 'energy-surge' | 'energy-drop' | 'tempo-shift';
  startSec: number;
  endSec: number;
  intensity: number;
  summary: string;
}

export interface BeatMarker {
  timestampSec: number;
  strength: number;
  isDownbeat: boolean;
  isStrong: boolean;
  intervalSec: number;
}

export interface BeatAnalysisResult {
  bpm: number;
  bpmConfidence: number;
  rhythmPattern: 'steady-4/4' | 'steady-3/4' | 'syncopated' | 'tempo-shifting' | 'weak-or-irregular';
  rhythmRegularity: number;
  averageBeatIntervalSec: number;
  beatTimestampsSec: number[];
  downbeatTimestampsSec: number[];
  strongBeatTimestampsSec: number[];
  beats: BeatMarker[];
  downbeatConfidence: number;
  energyPeaksSec: number[];
  tempoSegments: TempoSegment[];
  tempoChanges: TempoChangeEvent[];
  events: AudioSignificantEvent[];
}

export type MusicSectionLabel =
  | 'intro'
  | 'verse'
  | 'chorus'
  | 'build-up'
  | 'drop'
  | 'break'
  | 'outro'
  | 'uncertain';

export interface MusicSectionSegment {
  label: MusicSectionLabel;
  startSec: number;
  endSec: number;
  energyScore: number;
  confidence: number;
  rationale: string;
  uncertain?: boolean;
  secondaryLabel?: MusicSectionLabel;
}

export interface AudioWaveformPoint {
  timeSec: number;
  peak: number;
  rms: number;
}

export interface EnergyFramePoint {
  timeSec: number;
  rms: number;
  lowEnergy: number;
  midHighEnergy: number;
}

export interface StructuredAudioAnalysis {
  version: string;
  mediaId: string;
  durationSec: number;
  sampleRateAnalyzed: number;
  processingMs: number;
  analyzedAt: string;
  beatIntelligence: BeatAnalysisResult;
  sections: MusicSectionSegment[];
  overallStructureConfidence: number;
  energySummary: {
    meanRms: number;
    peakRms: number;
    dynamicRangeDb: number;
  };
  waveform: AudioWaveformPoint[];
  energyCurve: EnergyFramePoint[];
  notes: string[];
}

export type VideoOrientation = 'landscape' | 'portrait' | 'square';

export type CameraMovementType =
  | 'static'
  | 'pan-left'
  | 'pan-right'
  | 'tilt-up'
  | 'tilt-down'
  | 'zoom-in'
  | 'zoom-out'
  | 'handheld-dynamic'
  | 'mixed';

export type SceneTransitionBoundary = 'start-of-clip' | 'hard-cut' | 'gradual-transition' | 'black-gap';

export type SceneUsabilityIssue =
  | 'black-frames'
  | 'frozen-static'
  | 'low-detail-blur'
  | 'underexposed'
  | 'overexposed';

export interface VideoStreamMetadata {
  width: number;
  height: number;
  encodedWidth: number;
  encodedHeight: number;
  rotationDeg: number;
  orientation: VideoOrientation;
  aspectRatioLabel: string;
  fps: number;
  durationSec: number;
  codecName: string;
  pixFmt: string;
  bitrateKbps: number | null;
  hasAudio: boolean;
  audioCodec: string | null;
}

export interface SceneVisualDetections {
  personLikelihood: number;
  personLikely: boolean;
  foregroundObjectLikelihood: number;
  salientRegionCount: number;
  salientFocusPoint: { x: number; y: number } | null;
  framingBalance: 'centered' | 'rule-of-thirds' | 'distributed' | 'minimal';
}

export interface VideoSceneSegment {
  sceneIndex: number;
  assetId: string;
  startSec: number;
  endSec: number;
  durationSec: number;
  boundaryType: SceneTransitionBoundary;
  boundaryConfidence: number;
  representativeTimestampSec: number;
  thumbnailAvailable: boolean;
  thumbnailUrl?: string | null;
  motionIntensity: number;
  cameraMovement: CameraMovementType;
  cameraMovementConfidence: number;
  cameraPanSpeed: number;
  cameraZoomRate: number;
  visualQualityScore: number;
  interestScore: number;
  avgBrightness: number;
  avgContrast: number;
  avgSharpness: number;
  colorfulness: number;
  usable: boolean;
  unusableReason: string | null;
  issues: SceneUsabilityIssue[];
  detections: SceneVisualDetections;
  summary: string;
}

export interface VideoSignificantMoment {
  timestampSec: number;
  sceneIndex: number;
  type: 'peak-motion' | 'subject-focus' | 'high-interest-peak' | 'scene-transition';
  score: number;
  summary: string;
}

export interface VideoTimelineSamplePoint {
  timeSec: number;
  motionIntensity: number;
  brightness: number;
  interestScore: number;
}

export interface VideoDetectionCapabilities {
  sceneDetectionMethod: string;
  cameraMotionMethod: string;
  personDetectionMethod: string;
  objectDetectionMethod: string;
  neuralModelsInstalled: boolean;
  honestyNote: string;
}

export interface StructuredVideoAnalysis {
  version: string;
  mediaId: string;
  durationSec: number;
  processingMs: number;
  analyzedAt: string;
  sampleFpsUsed: number;
  metadata: VideoStreamMetadata;
  sceneCount: number;
  usableSceneCount: number;
  usableDurationSec: number;
  blackDurationSec: number;
  frozenDurationSec: number;
  averageMotionIntensity: number;
  averageQualityScore: number;
  dominantCameraMovement: CameraMovementType;
  scenes: VideoSceneSegment[];
  blackIntervals: Array<{ startSec: number; endSec: number; durationSec: number }>;
  frozenIntervals: Array<{ startSec: number; endSec: number; durationSec: number }>;
  significantMoments: VideoSignificantMoment[];
  timelineCurve: VideoTimelineSamplePoint[];
  capabilities: VideoDetectionCapabilities;
  notes: string[];
}

export interface EditDecisionCut {
  trackIndex: number;
  assetId: string;
  sourceInSec: number;
  sourceOutSec: number;
  timelineInSec: number;
  timelineOutSec: number;
  transitionType: 'cut' | 'crossfade' | 'dip-black' | 'whip';
}

export interface AudioFrameFeatures {
  durationSec: number;
  sampleRate: number;
  frameDurationSec: number;
  frameCenterOffsetSec: number;
  decoderOffsetSec: number;
  subFrameStepSec: number;
  subFrameEnergy: Float32Array;
  rms: Float32Array;
  lowEnergy: Float32Array;
  midEnergy: Float32Array;
  highEnergy: Float32Array;
  onsetFlux: Float32Array;
  spectralCentroid: Float32Array;
  melBands: Float32Array[];
  waveform: AudioWaveformPoint[];
  energyCurve: EnergyFramePoint[];
}

export interface BeatIntelligenceModule {
  readonly descriptor: EngineModuleDescriptor;
  analyzeAudio(audioFilePath: string): Promise<BeatAnalysisResult>;
  analyzeFeatures(features: AudioFrameFeatures): BeatAnalysisResult;
}

export interface MusicIntelligenceModule {
  readonly descriptor: EngineModuleDescriptor;
  detectStructure(
    audioFilePath: string,
    beats: BeatAnalysisResult
  ): Promise<{ sections: MusicSectionSegment[]; confidence: number }>;
  detectStructureFromFeatures(
    features: AudioFrameFeatures,
    beats: BeatAnalysisResult
  ): { sections: MusicSectionSegment[]; confidence: number };
}

export interface VideoIntelligenceModule {
  readonly descriptor: EngineModuleDescriptor;
  analyzeScenes(videoFilePath: string, assetId: string): Promise<VideoSceneSegment[]>;
}

export interface EditingIntelligenceModule {
  readonly descriptor: EngineModuleDescriptor;
  generateEditPlan(input: {
    beats: BeatAnalysisResult;
    sections: MusicSectionSegment[];
    scenes: VideoSceneSegment[];
    style: string;
    targetDurationSec: number;
  }): Promise<EditDecisionCut[]>;
}

export interface TransitionIntelligenceModule {
  readonly descriptor: EngineModuleDescriptor;
  selectTransitions(cuts: EditDecisionCut[], beats: BeatAnalysisResult, style: string): Promise<EditDecisionCut[]>;
}

export interface QualityIntelligenceModule {
  readonly descriptor: EngineModuleDescriptor;
  validateRender(mp4Path: string, expectedDurationSec: number): Promise<{ valid: boolean; diagnostics: string[] }>;
}
