import type {
  AudioFrameFeatures,
  BeatAnalysisResult,
  EngineModuleDescriptor,
  MusicIntelligenceModule,
  MusicSectionLabel,
  MusicSectionSegment,
} from '../contracts.ts';
import { decodeAudioToMonoPcmWithTiming, extractAudioFeatures } from './dsp.ts';

interface WindowSummary {
  startSec: number;
  endSec: number;
  meanRms: number;
  meanLow: number;
  lowRatio: number;
  midRatio: number;
  highRatio: number;
  centroidHz: number;
  fluxMean: number;
  onsetDensity: number;
  melShape: Float64Array;
  featureVec: Float64Array;
}

interface RawSectionCandidate {
  startW: number;
  endW: number;
  startSec: number;
  endSec: number;
  durationSec: number;
  normEnergy: number;
  startEnergy: number;
  midEnergyLevel: number;
  endEnergy: number;
  linearSlope: number;
  positiveStepRatio: number;
  avgLow: number;
  avgMid: number;
  avgHigh: number;
  avgMeanLow: number;
  avgOnsetDensity: number;
  centroidDrift: number;
  highRatioDrift: number;
  firstWinRms: number;
  lastWinRms: number;
  firstWinLow: number;
  lastWinLow: number;
  meanMelShape: Float64Array;
}

function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}

function cosineSimilarity(a: Float64Array, b: Float64Array): number {
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom > 1e-9 ? dot / denom : 0;
}

function buildAnalysisWindows(
  features: AudioFrameFeatures,
  beats: BeatAnalysisResult
): WindowSummary[] {
  const {
    durationSec,
    frameDurationSec,
    frameCenterOffsetSec,
    decoderOffsetSec,
    rms,
    lowEnergy,
    midEnergy,
    highEnergy,
    onsetFlux,
    spectralCentroid,
    melBands,
  } = features;
  const totalFrames = rms.length;
  const timeBiasSec = frameCenterOffsetSec + decoderOffsetSec;

  // Compute global onset flux normalization threshold for onsetDensity
  let maxFlux = 1e-6;
  for (let f = 0; f < totalFrames; f++) {
    if (onsetFlux[f] > maxFlux) maxFlux = onsetFlux[f];
  }

  // Prefer true downbeat bar boundaries when reliable; else meter-grouped beats; else uniform 2s bars
  const boundaries: number[] = [0];
  if (beats.downbeatConfidence >= 0.30 && beats.downbeatTimestampsSec.length >= 4) {
    for (const dbTs of beats.downbeatTimestampsSec) {
      if (dbTs - boundaries[boundaries.length - 1] >= 0.9 && dbTs < durationSec - 0.6) {
        boundaries.push(dbTs);
      }
    }
  } else if (beats.bpmConfidence >= 0.36 && beats.beatTimestampsSec.length >= 8) {
    const step = beats.rhythmPattern === 'steady-3/4' ? 3 : 4;
    for (let i = step; i < beats.beatTimestampsSec.length; i += step) {
      const ts = beats.beatTimestampsSec[i];
      if (ts - boundaries[boundaries.length - 1] >= 1.1 && ts < durationSec - 0.6) {
        boundaries.push(ts);
      }
    }
  } else {
    const stepSec = Math.max(1.5, Math.min(2.5, durationSec / 8));
    for (let t = stepSec; t < durationSec - 0.7; t += stepSec) {
      boundaries.push(Number(t.toFixed(3)));
    }
  }

  if (durationSec - boundaries[boundaries.length - 1] < 0.7 && boundaries.length > 1) {
    boundaries[boundaries.length - 1] = durationSec;
  } else {
    boundaries.push(durationSec);
  }

  const windows: WindowSummary[] = [];
  for (let w = 0; w < boundaries.length - 1; w++) {
    const startSec = boundaries[w];
    const endSec = boundaries[w + 1];
    const startF = Math.max(0, Math.floor(Math.max(0, startSec - timeBiasSec) / frameDurationSec));
    const endF = Math.min(
      totalFrames,
      Math.max(startF + 1, Math.floor(Math.max(0, endSec - timeBiasSec) / frameDurationSec))
    );
    const count = Math.max(1, endF - startF);

    let sumRms = 0;
    let sumLow = 0;
    let sumMid = 0;
    let sumHigh = 0;
    let sumFlux = 0;
    let sumCent = 0;
    let activeOnsetFrames = 0;
    const melSum = new Float64Array(12);

    for (let f = startF; f < endF; f++) {
      sumRms += rms[f];
      sumLow += lowEnergy[f];
      sumMid += midEnergy[f];
      sumHigh += highEnergy[f];
      sumFlux += onsetFlux[f];
      sumCent += spectralCentroid[f];
      if (onsetFlux[f] > maxFlux * 0.22 && rms[f] > 0.005) activeOnsetFrames++;
      const bands = melBands[f];
      for (let b = 0; b < 12; b++) melSum[b] += bands[b];
    }

    const meanRms = sumRms / count;
    const meanLow = sumLow / count;
    const totalSpec = sumLow + sumMid + sumHigh + 1e-6;
    const lowRatio = sumLow / totalSpec;
    const midRatio = sumMid / totalSpec;
    const highRatio = sumHigh / totalSpec;
    const onsetDensity = activeOnsetFrames / count;

    const melShape = new Float64Array(12);
    let melNorm = 0;
    for (let b = 0; b < 12; b++) {
      const m = melSum[b] / count;
      melShape[b] = m;
      melNorm += m * m;
    }
    melNorm = Math.sqrt(melNorm);
    if (melNorm > 1e-6) {
      for (let b = 0; b < 12; b++) melShape[b] /= melNorm;
    }

    // Feature vector combines normalized spectral timbre (12) + scaled energy/balance/rhythm cues (5)
    const vec = new Float64Array(17);
    for (let b = 0; b < 12; b++) vec[b] = melShape[b];
    vec[12] = meanRms * 3.5;
    vec[13] = lowRatio * 2.2;
    vec[14] = midRatio * 1.6;
    vec[15] = highRatio * 1.8;
    vec[16] = onsetDensity * 2.0;

    windows.push({
      startSec: Number(startSec.toFixed(2)),
      endSec: Number(endSec.toFixed(2)),
      meanRms,
      meanLow,
      lowRatio,
      midRatio,
      highRatio,
      centroidHz: sumCent / count,
      fluxMean: sumFlux / count,
      onsetDensity,
      melShape,
      featureVec: vec,
    });
  }

  return windows;
}

function summarizeSlice(
  windows: WindowSummary[],
  startW: number,
  endW: number,
  maxRms: number,
  trackMeanCentroid: number
): RawSectionCandidate {
  const slice = windows.slice(startW, endW);
  const len = Math.max(1, slice.length);

  let sumRms = 0;
  let sumLowR = 0;
  let sumMidR = 0;
  let sumHighR = 0;
  let sumMeanLow = 0;
  let sumOnsetDens = 0;
  const meanMelShape = new Float64Array(12);

  for (const w of slice) {
    sumRms += w.meanRms;
    sumLowR += w.lowRatio;
    sumMidR += w.midRatio;
    sumHighR += w.highRatio;
    sumMeanLow += w.meanLow;
    sumOnsetDens += w.onsetDensity;
    for (let b = 0; b < 12; b++) meanMelShape[b] += w.melShape[b];
  }
  for (let b = 0; b < 12; b++) meanMelShape[b] /= len;

  const energies = slice.map((w) => w.meanRms / maxRms);
  const sortedE = [...energies].sort((a, b) => a - b);
  const midEnergyLevel = sortedE[Math.floor(sortedE.length / 2)] ?? 0;

  // Least-squares linear energy slope across windows in the section (total drift start -> end)
  let linearSlope = 0;
  if (len >= 2) {
    const meanX = (len - 1) / 2;
    const meanY = energies.reduce((a, b) => a + b, 0) / len;
    let num = 0;
    let den = 0;
    for (let i = 0; i < len; i++) {
      num += (i - meanX) * (energies[i] - meanY);
      den += (i - meanX) * (i - meanX);
    }
    const perWinSlope = den > 1e-6 ? num / den : 0;
    linearSlope = perWinSlope * (len - 1);
  }

  let positiveSteps = 0;
  for (let i = 1; i < len; i++) {
    if (energies[i] >= energies[i - 1] - 0.015 && energies[i] > energies[0] + 0.02) {
      positiveSteps++;
    }
  }
  const positiveStepRatio = len > 1 ? positiveSteps / (len - 1) : 0;

  // First half vs second half spectral centroid & high-band drift
  const split = Math.max(1, Math.floor(len / 2));
  let startCent = 0;
  let endCent = 0;
  let startHigh = 0;
  let endHigh = 0;
  for (let i = 0; i < split; i++) {
    startCent += slice[i].centroidHz;
    startHigh += slice[i].highRatio;
  }
  for (let i = split; i < len; i++) {
    endCent += slice[i].centroidHz;
    endHigh += slice[i].highRatio;
  }
  const endCnt = Math.max(1, len - split);
  const centroidDrift =
    len >= 2 ? (endCent / endCnt - startCent / split) / Math.max(200, trackMeanCentroid) : 0;
  const highRatioDrift = len >= 2 ? endHigh / endCnt - startHigh / split : 0;

  return {
    startW,
    endW,
    startSec: slice[0].startSec,
    endSec: slice[len - 1].endSec,
    durationSec: Number((slice[len - 1].endSec - slice[0].startSec).toFixed(2)),
    normEnergy: sumRms / len / maxRms,
    startEnergy: energies[0],
    midEnergyLevel,
    endEnergy: energies[len - 1],
    linearSlope,
    positiveStepRatio,
    avgLow: sumLowR / len,
    avgMid: sumMidR / len,
    avgHigh: sumHighR / len,
    avgMeanLow: sumMeanLow / len,
    avgOnsetDensity: sumOnsetDens / len,
    centroidDrift,
    highRatioDrift,
    firstWinRms: slice[0].meanRms,
    lastWinRms: slice[len - 1].meanRms,
    firstWinLow: slice[0].meanLow,
    lastWinLow: slice[len - 1].meanLow,
    meanMelShape,
  };
}

export class EditmindMusicIntelligence implements MusicIntelligenceModule {
  readonly descriptor: EngineModuleDescriptor = {
    id: 'music-intelligence',
    name: 'Music Intelligence',
    milestoneTarget: 3,
    status: 'active',
    provider: 'Self-hosted Multi-Scale Structural Novelty & Acoustic Classifier',
    summary:
      'Segments tracks into intro, verse, chorus, build-up, drop, break, outro, or uncertain regions using multi-scale novelty and spectral balance.',
    outputs: ['Section boundaries', 'Energy envelope', 'Drop/Chorus differentiation'],
    externalDependencyPolicy: 'Local multi-scale self-similarity matrix & acoustic balance scoring.',
  };

  async detectStructure(
    audioFilePath: string,
    beats: BeatAnalysisResult
  ): Promise<{ sections: MusicSectionSegment[]; confidence: number }> {
    const { samples, decoderOffsetSec } = await decodeAudioToMonoPcmWithTiming(audioFilePath);
    const features = extractAudioFeatures(samples, { decoderOffsetSec });
    return this.detectStructureFromFeatures(features, beats);
  }

  detectStructureFromFeatures(
    features: AudioFrameFeatures,
    beats: BeatAnalysisResult
  ): { sections: MusicSectionSegment[]; confidence: number } {
    const windows = buildAnalysisWindows(features, beats);
    if (windows.length === 0) {
      return { sections: [], confidence: 0 };
    }

    const maxRms = Math.max(1e-6, ...windows.map((w) => w.meanRms));
    const minRms = Math.min(...windows.map((w) => w.meanRms));
    const maxLow = Math.max(1e-6, ...windows.map((w) => w.meanLow));
    const maxFlux = Math.max(1e-6, ...windows.map((w) => w.fluxMean));
    const minFlux = Math.min(...windows.map((w) => w.fluxMean));
    const energySpread = (maxRms - minRms) / maxRms;
    const fluxSpread = (maxFlux - minFlux) / maxFlux;
    const trackMeanCentroid =
      windows.reduce((acc, w) => acc + w.centroidHz, 0) / Math.max(1, windows.length);

    // Short clips (< 8 seconds) form a single segment with honest uncertainty check
    if (windows.length <= 2 || features.durationSec < 8) {
      const avgEnergy =
        windows.reduce((acc, w) => acc + w.meanRms, 0) / Math.max(1, windows.length) / maxRms;
      const conf = Number(clamp01(0.32 + energySpread * 0.4).toFixed(3));
      const label: MusicSectionLabel =
        conf < 0.44 ? 'uncertain' : avgEnergy > 0.62 ? 'chorus' : 'verse';
      return {
        sections: [
          {
            label,
            startSec: 0,
            endSec: Number(features.durationSec.toFixed(2)),
            energyScore: Number(avgEnergy.toFixed(3)),
            confidence: conf,
            uncertain: label === 'uncertain',
            rationale:
              label === 'uncertain'
                ? 'Short audio clip with insufficient structural contrast for definitive section labeling.'
                : 'Short audio segment; single primary energy region.',
          },
        ],
        confidence: conf,
      };
    }

    // Multi-scale checkerboard self-similarity novelty (L=2 bars + L=min(4, N/4) bars)
    const nWin = windows.length;
    const computeCheckerboard = (L: number): Float64Array => {
      const nov = new Float64Array(nWin);
      if (L < 1 || nWin <= L * 2) return nov;
      for (let i = L; i < nWin - L; i++) {
        let within = 0;
        let cross = 0;
        let countW = 0;
        let countC = 0;
        for (let a = -L; a < L; a++) {
          for (let b = -L; b < L; b++) {
            const sim = cosineSimilarity(windows[i + a].featureVec, windows[i + b].featureVec);
            if ((a < 0 && b < 0) || (a >= 0 && b >= 0)) {
              within += sim;
              countW++;
            } else {
              cross += sim;
              countC++;
            }
          }
        }
        nov[i] = Math.max(0, within / Math.max(1, countW) - cross / Math.max(1, countC));
      }
      return nov;
    };

    const novShort = computeCheckerboard(Math.min(2, Math.max(1, Math.floor(nWin / 4))));
    const novLong = computeCheckerboard(Math.min(4, Math.max(2, Math.floor(nWin / 4))));
    const novelty = new Float64Array(nWin);
    for (let i = 0; i < nWin; i++) {
      novelty[i] = 0.65 * novShort[i] + 0.35 * novLong[i];
    }

    // 2-bar smoothed energy/flux contrast curves (catches gradual multi-bar transitions)
    const rmsContrast2Bar = new Float64Array(nWin);
    const fluxContrast2Bar = new Float64Array(nWin);
    for (let i = 2; i < nWin - 1; i++) {
      const prevR = (windows[i - 2].meanRms + windows[i - 1].meanRms) / 2;
      const nextR = (windows[i].meanRms + windows[i + 1].meanRms) / 2;
      rmsContrast2Bar[i] = Math.abs(nextR - prevR) / maxRms;

      const prevF = (windows[i - 2].fluxMean + windows[i - 1].fluxMean) / 2;
      const nextF = (windows[i].fluxMean + windows[i + 1].fluxMean) / 2;
      fluxContrast2Bar[i] = Math.abs(nextF - prevF) / maxFlux;
    }

    // 1-bar step indicators for sharp impact / breakdown transitions
    const rmsStep1 = new Float64Array(nWin);
    const lowStep1 = new Float64Array(nWin);
    const onsetStep1 = new Float64Array(nWin);
    for (let i = 1; i < nWin; i++) {
      rmsStep1[i] = Math.abs(windows[i].meanRms - windows[i - 1].meanRms) / maxRms;
      lowStep1[i] = Math.abs(windows[i].meanLow - windows[i - 1].meanLow) / maxLow;
      onsetStep1[i] = Math.abs(windows[i].onsetDensity - windows[i - 1].onsetDensity);
    }

    // Select boundaries with adaptive local novelty thresholding + gradual contrast detection
    const maxNovelty = Math.max(1e-6, ...novelty);
    const minWinGap = 2; // Minimum 2 bars (~3.5-5s) so Intro/Build-up/Break don't collapse
    const boundaryIndices: number[] = [0];

    for (let i = 2; i < nWin - 1; i++) {
      // Local neighborhood novelty stats excluding immediate neighbors
      const vals: number[] = [];
      for (let k = Math.max(0, i - 5); k <= Math.min(nWin - 1, i + 5); k++) {
        if (Math.abs(k - i) >= 2) vals.push(novelty[k]);
      }
      const localMean = vals.length > 0 ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
      const localStd =
        vals.length > 1
          ? Math.sqrt(vals.reduce((a, v) => a + Math.pow(v - localMean, 2), 0) / vals.length)
          : 0;

      const isNovPeak = novelty[i] >= novelty[i - 1] && novelty[i] >= novelty[i + 1];
      const novTrigger =
        isNovPeak &&
        ((novelty[i] >= maxNovelty * 0.16 && novelty[i] - localMean >= Math.max(0.012, localStd * 0.55)) ||
          novelty[i] >= maxNovelty * 0.36);

      const isContrastPeak =
        rmsContrast2Bar[i] >= rmsContrast2Bar[i - 1] &&
        rmsContrast2Bar[i] >= rmsContrast2Bar[i + 1];
      const isFluxPeak =
        fluxContrast2Bar[i] >= fluxContrast2Bar[i - 1] &&
        fluxContrast2Bar[i] >= fluxContrast2Bar[i + 1];
      const gradualTrigger =
        (isContrastPeak && rmsContrast2Bar[i] >= 0.16) ||
        (isFluxPeak && fluxContrast2Bar[i] >= 0.22);

      const sharpTrigger =
        rmsStep1[i] >= 0.21 || lowStep1[i] >= 0.23 || onsetStep1[i] >= 0.18;

      // Suppress splits in the middle of a monotonic rising ramp (build-up) so it stays intact
      const insideMonotonicRise =
        windows[i - 1].meanRms < windows[i].meanRms * 0.98 &&
        windows[i].meanRms < windows[i + 1].meanRms * 0.98 &&
        windows[i + 1].centroidHz >= windows[i - 1].centroidHz * 0.96;

      if (novTrigger || (!insideMonotonicRise && (gradualTrigger || sharpTrigger))) {
        // Snap soft novelty peak to adjacent sharp step (+-1 bar) to prevent transition bleed
        let snapIdx = i;
        if (!sharpTrigger) {
          if (
            i + 1 < nWin - 1 &&
            rmsStep1[i + 1] > rmsStep1[i] * 1.45 &&
            rmsStep1[i + 1] >= 0.16
          ) {
            snapIdx = i + 1;
          } else if (
            i - 1 >= 2 &&
            rmsStep1[i - 1] > rmsStep1[i] * 1.45 &&
            rmsStep1[i - 1] >= 0.16
          ) {
            snapIdx = i - 1;
          }
        }

        if (
          snapIdx - boundaryIndices[boundaryIndices.length - 1] >= minWinGap &&
          nWin - snapIdx >= minWinGap
        ) {
          boundaryIndices.push(snapIdx);
          if (snapIdx > i) i = snapIdx;
        }
      }
    }
    boundaryIndices.push(nWin);

    // Build initial raw sections & conservatively merge same-tier chord loops or continuous ramps
    let rawSections: RawSectionCandidate[] = [];
    for (let s = 0; s < boundaryIndices.length - 1; s++) {
      rawSections.push(
        summarizeSlice(
          windows,
          boundaryIndices[s],
          boundaryIndices[s + 1],
          maxRms,
          trackMeanCentroid
        )
      );
    }

    let merged = true;
    while (merged && rawSections.length > 1) {
      merged = false;
      for (let i = 0; i < rawSections.length - 1; i++) {
        const a = rawSections[i];
        const b = rawSections[i + 1];
        const sim = cosineSimilarity(a.meanMelShape, b.meanMelShape);
        const energyDiff = Math.abs(a.normEnergy - b.normEnergy);
        const onsetDiff = Math.abs(a.avgOnsetDensity - b.avgOnsetDensity);
        const lowDiff = Math.abs(a.avgLow - b.avgLow);

        const highDiff = Math.abs(a.avgHigh - b.avgHigh);
        const eitherTiny = a.durationSec < 3.4 || b.durationSec < 3.4;
        // Same arrangement tier (e.g., 4-bar chord loop across an 8-bar verse/chorus/intro)
        const sameArrangementTier =
          (sim >= 0.72 &&
            energyDiff < 0.06 &&
            onsetDiff < 0.08 &&
            lowDiff < 0.05 &&
            highDiff < 0.05) ||
          (energyDiff < 0.045 &&
            onsetDiff < 0.10 &&
            lowDiff < 0.10 &&
            highDiff < 0.08 &&
            Math.abs(a.linearSlope) < 0.10 &&
            Math.abs(b.linearSlope) < 0.10);
        // Continuous upward ramp split into two consecutive rising segments
        const continuousRamp =
          a.linearSlope >= 0.08 &&
          b.linearSlope >= 0.06 &&
          b.startEnergy >= a.endEnergy - 0.12 &&
          b.endEnergy > a.startEnergy + 0.15 &&
          i > 0; // don't swallow intro into build-up

        if (
          (eitherTiny && energyDiff < 0.14 && sim >= 0.80) ||
          sameArrangementTier ||
          continuousRamp
        ) {
          const combined = summarizeSlice(windows, a.startW, b.endW, maxRms, trackMeanCentroid);
          rawSections.splice(i, 2, combined);
          merged = true;
          break;
        }
      }
    }

    // Track-level reference statistics
    const peakSectionEnergy = Math.max(1e-6, ...rawSections.map((r) => r.normEnergy));
    const peakOnsetDensity = Math.max(1e-6, ...rawSections.map((r) => r.avgOnsetDensity));
    const sortedEnergies = [...rawSections.map((r) => r.normEnergy)].sort((a, b) => a - b);
    const p60 = sortedEnergies[Math.floor(sortedEnergies.length * 0.6)] ?? 0.6;

    // Detect if track is structurally uniform/ambiguous
    const trackUniform = energySpread < 0.14 && fluxSpread < 0.20;

    // Two-pass classification: Pass 1 identifies clear structural anchors (intro, outro, build-up, break);
    // Pass 2 resolves high-energy Chorus vs Drop & Verse vs Uncertain with full context!
    const preliminaryLabels: Array<MusicSectionLabel | null> = new Array(rawSections.length).fill(null);

    if (!trackUniform) {
      for (let i = 0; i < rawSections.length; i++) {
        const sec = rawSections[i];
        const prev = i > 0 ? rawSections[i - 1] : null;
        const next = i < rawSections.length - 1 ? rawSections[i + 1] : null;

        if (
          i === 0 &&
          rawSections.length >= 3 &&
          sec.normEnergy < Math.max(0.62, peakSectionEnergy * 0.78) &&
          ((next && sec.normEnergy <= next.normEnergy + 0.04) ||
            sec.avgOnsetDensity < peakOnsetDensity * 0.85)
        ) {
          preliminaryLabels[i] = 'intro';
          continue;
        }

        if (
          i === rawSections.length - 1 &&
          rawSections.length >= 3 &&
          sec.normEnergy < Math.max(0.64, peakSectionEnergy * 0.80) &&
          sec.linearSlope <= 0.08 &&
          ((prev && sec.normEnergy <= prev.normEnergy - 0.08) ||
            sec.endEnergy <= sec.startEnergy + 0.02)
        ) {
          preliminaryLabels[i] = 'outro';
          continue;
        }

        // Strict build-up vs break separation:
        // True build-up shows sustained monotonic energy + spectral tension rising into a peak section
        // Compare next section against build-up start energy (not just build-up mean, since ramps climb high!)
        const leadsIntoPeak =
          next !== null &&
          next.normEnergy >= peakSectionEnergy * 0.72 &&
          next.normEnergy >= sec.startEnergy + 0.22 &&
          next.normEnergy >= sec.normEnergy + 0.04;
        const progressiveRise =
          sec.linearSlope >= 0.16 &&
          (sec.positiveStepRatio >= 0.5 ||
            sec.centroidDrift >= 0.06 ||
            sec.highRatioDrift >= 0.02);
        const sharpDropFromPrev = prev !== null && prev.normEnergy - sec.normEnergy >= 0.28;

        if (
          leadsIntoPeak &&
          progressiveRise &&
          !(sharpDropFromPrev && sec.midEnergyLevel < 0.36 && sec.positiveStepRatio < 0.5)
        ) {
          preliminaryLabels[i] = 'build-up';
          continue;
        }

        // Breakdown / Break: interior low-energy valley after high energy without progressive ramp
        if (
          prev !== null &&
          next !== null &&
          sharpDropFromPrev &&
          sec.normEnergy <= 0.48 &&
          (sec.avgMeanLow < prev.avgMeanLow * 0.85 ||
            sec.avgOnsetDensity < prev.avgOnsetDensity * 0.88) &&
          !progressiveRise
        ) {
          preliminaryLabels[i] = 'break';
          continue;
        }
      }
    }

    const sections: MusicSectionSegment[] = [];
    for (let i = 0; i < rawSections.length; i++) {
      const sec = rawSections[i];
      const prev = i > 0 ? rawSections[i - 1] : null;
      const next = i < rawSections.length - 1 ? rawSections[i + 1] : null;
      const prevLabel = i > 0 ? sections[i - 1]?.label ?? preliminaryLabels[i - 1] : null;
      const nextLabel = i < rawSections.length - 1 ? preliminaryLabels[i + 1] : null;

      let label: MusicSectionLabel = preliminaryLabels[i] ?? 'verse';
      let secondaryLabel: MusicSectionLabel | undefined;
      let rationale = '';
      let localConfidence = 0.48 + Math.min(0.36, energySpread * 0.55);

      if (trackUniform) {
        label = 'uncertain';
        localConfidence = Math.min(0.38, 0.22 + energySpread * 0.8);
        rationale =
          'Uniform energy and onset density across the track limit confident structural segmentation.';
      } else if (label === 'intro') {
        rationale = 'Opening lower-energy region before main beat/arrangement entry.';
        localConfidence += 0.12;
      } else if (label === 'outro') {
        rationale = 'Closing lower-energy decay toward track end.';
        localConfidence += 0.12;
      } else if (label === 'build-up') {
        rationale =
          'Progressive upward energy and spectral tension rising directly into a peak impact section.';
        localConfidence += 0.1;
      } else if (label === 'break') {
        rationale =
          'Low-energy breakdown valley following a high-energy section with reduced bass/percussive drive.';
        localConfidence += 0.1;
      } else {
        // Differentiate high-energy Chorus vs Drop vs moderate Verse
        const isHighEnergyTier =
          sec.normEnergy >= Math.max(p60, peakSectionEnergy * 0.72) && energySpread >= 0.18;

        if (isHighEnergyTier) {
          const boundaryRmsJump = prev ? (sec.firstWinRms - prev.lastWinRms) / maxRms : 0;
          const boundaryLowJump = prev ? (sec.firstWinLow - prev.lastWinLow) / maxLow : 0;
          const bassToMid = sec.avgLow / Math.max(0.05, sec.avgMid);
          const precededByBuildOrBreak =
            prevLabel === 'build-up' || prevLabel === 'break';

          // Drop score favors EDM build-up/break launches, sharp sub-bass steps, and bass-heavy balance
          let dropScore = 0;
          if (precededByBuildOrBreak) dropScore += 0.40;
          if (boundaryRmsJump >= 0.28 && boundaryLowJump >= 0.24) dropScore += 0.26;
          else if (boundaryLowJump >= 0.26) dropScore += 0.16;
          if (bassToMid >= 0.92 || sec.avgLow >= 0.34) dropScore += 0.20;
          if (sec.avgOnsetDensity >= 0.30 && sec.avgLow >= 0.26) dropScore += 0.12;
          // Penalty if preceded only by steady mid-level verse without build/break
          if (prevLabel === 'verse' && !precededByBuildOrBreak && boundaryLowJump < 0.28) {
            dropScore -= 0.14;
          }

          // Chorus score favors melodic mid-band richness, steady peak energy plateau, and verse->chorus lift
          let chorusScore = 0;
          if (!precededByBuildOrBreak) chorusScore += 0.24;
          if (sec.avgMid >= 0.35 && sec.avgMid >= sec.avgLow * 0.90) chorusScore += 0.30;
          if (prev && sec.normEnergy - prev.normEnergy >= 0.12 && prevLabel !== 'break') {
            chorusScore += 0.20;
          } else if (sec.normEnergy >= peakSectionEnergy * 0.85 && sec.avgMid >= 0.36) {
            chorusScore += 0.15;
          }
          if (Math.abs(sec.linearSlope) < 0.20) chorusScore += 0.15;
          if (nextLabel === 'verse' || nextLabel === 'outro') chorusScore += 0.08;

          const margin = Math.abs(dropScore - chorusScore);
          if (dropScore >= 0.48 && dropScore > chorusScore + 0.06) {
            label = 'drop';
            secondaryLabel = chorusScore >= 0.40 ? 'chorus' : undefined;
            localConfidence += 0.08 + Math.min(0.12, margin * 0.4);
            rationale = precededByBuildOrBreak
              ? 'High-impact bass and rhythmic drop launched directly out of build-up/breakdown.'
              : 'Sharp low-band impact surge with strong sub-bass dominance.';
          } else if (chorusScore >= 0.42 && chorusScore >= dropScore - 0.06) {
            label = 'chorus';
            secondaryLabel = dropScore >= 0.42 ? 'drop' : undefined;
            localConfidence += 0.08 + Math.min(0.12, margin * 0.4);
            rationale =
              'Sustained peak melodic/harmonic mid-band chorus energy relative to verse baseline.';
          } else {
            label = 'uncertain';
            secondaryLabel = dropScore >= chorusScore ? 'drop' : 'chorus';
            localConfidence = Math.min(localConfidence, 0.41);
            rationale = `Ambiguous high-energy transition (${secondaryLabel} candidate with low separation).`;
          }
        } else {
          // Moderate / lower body section -> Verse (or Break if deep drop, handled in pass 1)
          const clarityFromPeak = peakSectionEnergy - sec.normEnergy;
          if (clarityFromPeak >= 0.14 || prevLabel === 'intro' || prevLabel === 'chorus') {
            label = 'verse';
            localConfidence += Math.min(0.10, clarityFromPeak * 0.3);
            rationale = 'Steady moderate-energy verse/groove body section below chorus peak tier.';
          } else {
            label = 'uncertain';
            secondaryLabel = 'verse';
            localConfidence = Math.min(localConfidence, 0.42);
            rationale =
              'Moderate energy region with weak contrast against adjacent peak sections.';
          }
        }
      }

      // Honest global uncertainty guard: downgrade genuinely low-confidence classifications
      const calibratedConf = Number(clamp01(localConfidence).toFixed(3));
      let finalLabel = label;
      let finalConf = Math.min(0.95, calibratedConf);
      let finalRationale = rationale;

      if (finalConf < 0.44 && finalLabel !== 'uncertain') {
        secondaryLabel = finalLabel;
        finalLabel = 'uncertain';
        finalRationale = `${rationale} (Marked uncertain due to low structural confidence ${Math.round(finalConf * 100)}%.)`;
      }

      sections.push({
        label: finalLabel,
        startSec: sec.startSec,
        endSec: sec.endSec,
        energyScore: Number(sec.normEnergy.toFixed(3)),
        confidence: finalConf,
        rationale: finalRationale,
        uncertain: finalLabel === 'uncertain',
        ...(secondaryLabel ? { secondaryLabel } : {}),
      });
    }

    const overallConfidence = Number(
      (
        sections.reduce((acc, s) => acc + s.confidence, 0) / Math.max(1, sections.length)
      ).toFixed(3)
    );

    return {
      sections,
      confidence: overallConfidence,
    };
  }
}
