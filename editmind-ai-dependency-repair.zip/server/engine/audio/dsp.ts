import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import type { AudioFrameFeatures, AudioWaveformPoint, EnergyFramePoint } from '../contracts.ts';

const execFileAsync = promisify(execFile);

export const ANALYSIS_SAMPLE_RATE = 22050;
export const FFT_SIZE = 1024;
export const HOP_SIZE = 256;
export const SUB_FRAME_HOP = 44; // ~2.0 ms @ 22050 Hz
export const SUB_FRAME_WIN = 88; // ~4.0 ms RMS window

const HANN_WINDOW = (() => {
  const win = new Float32Array(FFT_SIZE);
  for (let i = 0; i < FFT_SIZE; i++) {
    win[i] = 0.5 * (1 - Math.cos((2 * Math.PI * i) / (FFT_SIZE - 1)));
  }
  return win;
})();

const BIT_REV = (() => {
  const bits = Math.log2(FFT_SIZE);
  const rev = new Uint16Array(FFT_SIZE);
  for (let i = 0; i < FFT_SIZE; i++) {
    let x = i;
    let r = 0;
    for (let b = 0; b < bits; b++) {
      r = (r << 1) | (x & 1);
      x >>= 1;
    }
    rev[i] = r;
  }
  return rev;
})();

const TWIDDLE_COS = (() => {
  const arr = new Float32Array(FFT_SIZE / 2);
  for (let i = 0; i < FFT_SIZE / 2; i++) {
    arr[i] = Math.cos((-2 * Math.PI * i) / FFT_SIZE);
  }
  return arr;
})();

const TWIDDLE_SIN = (() => {
  const arr = new Float32Array(FFT_SIZE / 2);
  for (let i = 0; i < FFT_SIZE / 2; i++) {
    arr[i] = Math.sin((-2 * Math.PI * i) / FFT_SIZE);
  }
  return arr;
})();

function fftMagnitude(real: Float32Array, imag: Float32Array, magOut: Float32Array): void {
  const n = FFT_SIZE;
  for (let i = 0; i < n; i++) {
    const j = BIT_REV[i];
    if (i < j) {
      const tr = real[i];
      real[i] = real[j];
      real[j] = tr;
      const ti = imag[i];
      imag[i] = imag[j];
      imag[j] = ti;
    }
  }

  for (let size = 2; size <= n; size <<= 1) {
    const half = size >> 1;
    const step = n / size;
    for (let i = 0; i < n; i += size) {
      for (let j = 0; j < half; j++) {
        const k = j * step;
        const cos = TWIDDLE_COS[k];
        const sin = TWIDDLE_SIN[k];
        const rOdd = real[i + j + half];
        const iOdd = imag[i + j + half];
        const tr = rOdd * cos - iOdd * sin;
        const ti = rOdd * sin + iOdd * cos;
        real[i + j + half] = real[i + j] - tr;
        imag[i + j + half] = imag[i + j] - ti;
        real[i + j] += tr;
        imag[i + j] += ti;
      }
    }
  }

  const bins = n / 2;
  for (let b = 0; b < bins; b++) {
    magOut[b] = Math.hypot(real[b], imag[b]);
  }
}

export interface DecodedPcmWithTiming {
  samples: Float32Array;
  decoderOffsetSec: number;
}

/**
 * Inspects container/stream start_time cleanly without introducing spurious MP3 Xing offsets.
 * FFmpeg automatically strips LAME/Xing encoder delay and MP4 iTunSMPB priming during PCM decode,
 * whereas multiplexed video/audio containers (MOV/MP4/MKV) with delayed audio streams retain a
 * positive stream start_time relative to container t=0 that raw f32le pipes do not emit.
 */
export async function probeAudioDecoderOffsetSec(filePath: string): Promise<number> {
  try {
    const { stdout } = await execFileAsync(
      'ffprobe',
      [
        '-v',
        'error',
        '-select_streams',
        'a:0',
        '-show_entries',
        'format=format_name,start_time:stream=codec_name,start_time',
        '-of',
        'json',
        filePath,
      ],
      { timeout: 5000 }
    );
    const parsed = JSON.parse(stdout) as {
      format?: { format_name?: string; start_time?: string };
      streams?: Array<{ codec_name?: string; start_time?: string }>;
    };
    const formatName = (parsed.format?.format_name || '').toLowerCase();
    const stream = parsed.streams?.[0];
    const codecName = (stream?.codec_name || '').toLowerCase();
    const streamStart = Number(stream?.start_time ?? parsed.format?.start_time ?? 0);

    // Pure MP3 streams report encoder delay (~0.025s) as start_time, which FFmpeg already trims.
    if (formatName === 'mp3' || codecName === 'mp3') {
      return 0;
    }

    // Multiplexed containers where audio stream explicitly starts later than t=0
    const isContainer =
      formatName.includes('mov') ||
      formatName.includes('mp4') ||
      formatName.includes('matroska') ||
      formatName.includes('webm') ||
      formatName.includes('mpegts');
    if (isContainer && Number.isFinite(streamStart) && streamStart > 0.005 && streamStart < 10) {
      return Number(streamStart.toFixed(4));
    }

    return 0;
  } catch {
    return 0;
  }
}

export async function decodeAudioToMonoPcmWithTiming(
  filePath: string,
  maxDurationSec = 900
): Promise<DecodedPcmWithTiming> {
  const [samples, decoderOffsetSec] = await Promise.all([
    decodeAudioToMonoPcm(filePath, maxDurationSec),
    probeAudioDecoderOffsetSec(filePath),
  ]);
  return { samples, decoderOffsetSec };
}

export function decodeAudioToMonoPcm(filePath: string, maxDurationSec = 900): Promise<Float32Array> {
  return new Promise((resolve, reject) => {
    const args = [
      '-v',
      'error',
      '-t',
      String(maxDurationSec),
      '-i',
      filePath,
      '-vn',
      '-ac',
      '1',
      '-ar',
      String(ANALYSIS_SAMPLE_RATE),
      '-f',
      'f32le',
      'pipe:1',
    ];

    const proc = spawn('ffmpeg', args, { stdio: ['ignore', 'pipe', 'pipe'] });
    const chunks: Buffer[] = [];
    let stderrText = '';

    proc.stdout.on('data', (chunk: Buffer) => {
      chunks.push(chunk);
    });
    proc.stderr.on('data', (chunk: Buffer) => {
      stderrText += chunk.toString();
    });
    proc.on('error', (err) => reject(err));
    proc.on('close', (code) => {
      if (code !== 0) {
        reject(new Error(`FFmpeg PCM decode failed (${code}): ${stderrText.slice(0, 200)}`));
        return;
      }
      const raw = Buffer.concat(chunks);
      const usableBytes = raw.length - (raw.length % 4);
      if (usableBytes < FFT_SIZE * 4) {
        reject(new Error('Decoded audio stream is too short for spectral analysis.'));
        return;
      }
      const aligned = new Uint8Array(usableBytes);
      raw.copy(aligned, 0, 0, usableBytes);
      resolve(new Float32Array(aligned.buffer));
    });
  });
}

export function extractAudioFeatures(
  samples: Float32Array,
  options: { decoderOffsetSec?: number } = {}
): AudioFrameFeatures {
  const sampleRate = ANALYSIS_SAMPLE_RATE;
  const decoderOffsetSec = options.decoderOffsetSec ?? 0;
  const durationSec = samples.length / sampleRate + decoderOffsetSec;
  const frameDurationSec = HOP_SIZE / sampleRate;
  const frameCenterOffsetSec = (FFT_SIZE - 1) / (2 * sampleRate);
  const subFrameStepSec = SUB_FRAME_HOP / sampleRate;
  const numFrames = Math.max(1, Math.floor((samples.length - FFT_SIZE) / HOP_SIZE) + 1);
  const bins = FFT_SIZE / 2;

  const rms = new Float32Array(numFrames);
  const lowEnergy = new Float32Array(numFrames);
  const midEnergy = new Float32Array(numFrames);
  const highEnergy = new Float32Array(numFrames);
  const onsetFlux = new Float32Array(numFrames);
  const spectralCentroid = new Float32Array(numFrames);
  const melBands: Float32Array[] = new Array(numFrames);

  const real = new Float32Array(FFT_SIZE);
  const imag = new Float32Array(FFT_SIZE);
  const mag = new Float32Array(bins);
  const prevLogMag = new Float32Array(bins);

  const binHz = sampleRate / FFT_SIZE;
  const lowMaxBin = Math.floor(180 / binHz);
  const midMaxBin = Math.floor(2500 / binHz);

  // 12 log-spaced spectral band boundaries from 40 Hz to 10000 Hz
  const bandEdges: number[] = [];
  for (let m = 0; m <= 12; m++) {
    const hz = 40 * Math.pow(10000 / 40, m / 12);
    bandEdges.push(Math.min(bins - 1, Math.max(1, Math.round(hz / binHz))));
  }

  for (let f = 0; f < numFrames; f++) {
    const offset = f * HOP_SIZE;
    let sumSq = 0;

    for (let i = 0; i < FFT_SIZE; i++) {
      const s = samples[offset + i] || 0;
      sumSq += s * s;
      real[i] = s * HANN_WINDOW[i];
      imag[i] = 0;
    }

    rms[f] = Math.sqrt(sumSq / FFT_SIZE);
    fftMagnitude(real, imag, mag);

    let lowSum = 0;
    let midSum = 0;
    let highSum = 0;
    let lowFlux = 0;
    let midFlux = 0;
    let highFlux = 0;
    let weightedFreq = 0;
    let totalMag = 0;

    for (let b = 1; b < bins; b++) {
      const m = mag[b];
      const logM = Math.log1p(12 * m);
      const diff = logM - prevLogMag[b];
      const posDiff = diff > 0 ? diff : 0;
      prevLogMag[b] = logM;

      weightedFreq += b * binHz * m;
      totalMag += m;

      if (b <= lowMaxBin) {
        lowSum += m * m;
        lowFlux += posDiff;
      } else if (b <= midMaxBin) {
        midSum += m * m;
        midFlux += posDiff;
      } else {
        highSum += m * m;
        highFlux += posDiff;
      }
    }

    lowEnergy[f] = Math.sqrt(lowSum / Math.max(1, lowMaxBin));
    midEnergy[f] = Math.sqrt(midSum / Math.max(1, midMaxBin - lowMaxBin));
    highEnergy[f] = Math.sqrt(highSum / Math.max(1, bins - midMaxBin));
    spectralCentroid[f] = totalMag > 1e-6 ? weightedFreq / totalMag : 0;

    onsetFlux[f] =
      f === 0
        ? 0
        : (0.55 * lowFlux) / Math.max(1, lowMaxBin) +
          (0.3 * midFlux) / Math.max(1, midMaxBin - lowMaxBin) +
          (0.15 * highFlux) / Math.max(1, bins - midMaxBin);

    const bands = new Float32Array(12);
    for (let bIdx = 0; bIdx < 12; bIdx++) {
      const startB = bandEdges[bIdx];
      const endB = Math.max(startB + 1, bandEdges[bIdx + 1]);
      let acc = 0;
      for (let b = startB; b < endB; b++) {
        acc += mag[b];
      }
      bands[bIdx] = Math.log1p(acc / (endB - startB));
    }
    melBands[f] = bands;
  }

  // Build compact waveform envelope (~180 points) for mobile UI
  const waveformPoints = 180;
  const waveform: AudioWaveformPoint[] = [];
  const samplesPerBucket = Math.max(1, Math.floor(samples.length / waveformPoints));
  for (let i = 0; i < waveformPoints; i++) {
    const start = i * samplesPerBucket;
    const end = Math.min(samples.length, start + samplesPerBucket);
    if (start >= samples.length) break;
    let peak = 0;
    let sq = 0;
    for (let s = start; s < end; s++) {
      const a = Math.abs(samples[s]);
      if (a > peak) peak = a;
      sq += a * a;
    }
    waveform.push({
      timeSec: Number(((start + (end - start) / 2) / sampleRate + decoderOffsetSec).toFixed(3)),
      peak: Number(Math.min(1, peak).toFixed(4)),
      rms: Number(Math.min(1, Math.sqrt(sq / Math.max(1, end - start))).toFixed(4)),
    });
  }

  // Compute 2 ms high-resolution energy envelope for sub-frame beat attack refinement
  const numSubFrames = Math.max(1, Math.floor((samples.length - SUB_FRAME_WIN) / SUB_FRAME_HOP) + 1);
  const subFrameEnergy = new Float32Array(numSubFrames);
  for (let sf = 0; sf < numSubFrames; sf++) {
    const start = sf * SUB_FRAME_HOP;
    let sq = 0;
    for (let i = 0; i < SUB_FRAME_WIN; i++) {
      const v = samples[start + i] || 0;
      sq += v * v;
    }
    subFrameEnergy[sf] = Math.sqrt(sq / SUB_FRAME_WIN);
  }

  // Build compact energy curve (~140 points) centered in FFT analysis windows
  const energyPoints = 140;
  const energyCurve: EnergyFramePoint[] = [];
  const framesPerBucket = Math.max(1, Math.floor(numFrames / energyPoints));
  let maxLow = 1e-6;
  let maxMidHigh = 1e-6;
  for (let f = 0; f < numFrames; f++) {
    if (lowEnergy[f] > maxLow) maxLow = lowEnergy[f];
    const mh = midEnergy[f] + highEnergy[f];
    if (mh > maxMidHigh) maxMidHigh = mh;
  }

  for (let i = 0; i < energyPoints; i++) {
    const startF = i * framesPerBucket;
    const endF = Math.min(numFrames, startF + framesPerBucket);
    if (startF >= numFrames) break;
    let r = 0;
    let l = 0;
    let mh = 0;
    const count = Math.max(1, endF - startF);
    for (let f = startF; f < endF; f++) {
      r += rms[f];
      l += lowEnergy[f];
      mh += midEnergy[f] + highEnergy[f];
    }
    energyCurve.push({
      timeSec: Number(
        ((startF + count / 2) * frameDurationSec + frameCenterOffsetSec + decoderOffsetSec).toFixed(3)
      ),
      rms: Number(Math.min(1, r / count).toFixed(4)),
      lowEnergy: Number(Math.min(1, l / count / maxLow).toFixed(4)),
      midHighEnergy: Number(Math.min(1, mh / count / maxMidHigh).toFixed(4)),
    });
  }

  return {
    durationSec,
    sampleRate,
    frameDurationSec,
    frameCenterOffsetSec,
    decoderOffsetSec,
    subFrameStepSec,
    subFrameEnergy,
    rms,
    lowEnergy,
    midEnergy,
    highEnergy,
    onsetFlux,
    spectralCentroid,
    melBands,
    waveform,
    energyCurve,
  };
}
