import crypto from 'node:crypto';
import fs from 'node:fs';
import { db } from '../../db.ts';
import { resolveSafeStoragePath } from '../../storage.ts';
import type { StructuredAudioAnalysis } from '../contracts.ts';
import { EditmindBeatIntelligence } from './beatIntelligence.ts';
import {
  ANALYSIS_SAMPLE_RATE,
  decodeAudioToMonoPcmWithTiming,
  extractAudioFeatures,
} from './dsp.ts';
import { EditmindMusicIntelligence } from './musicIntelligence.ts';

export const AUDIO_ENGINE_VERSION = 'editmind-audio-v2';

interface MediaAssetAudioRow {
  id: string;
  user_id: string;
  project_id: string;
  media_kind: string;
  original_name: string;
  stored_filename: string;
  duration_sec: number;
  sha256: string;
}

interface CachedAnalysisRow {
  id: string;
  media_id: string;
  file_sha256: string;
  engine_version: string;
  analysis_json: string;
  processing_ms: number;
  created_at: string;
  updated_at: string;
}

const beatModule = new EditmindBeatIntelligence();
const musicModule = new EditmindMusicIntelligence();

export function getCachedAudioAnalysis(
  mediaId: string,
  userId: string
): { status: 'ready' | 'not_analyzed'; cached: boolean; analysis: StructuredAudioAnalysis | null } {
  const asset = db
    .prepare(
      `SELECT id, user_id, project_id, media_kind, original_name, stored_filename, duration_sec, sha256
       FROM media_assets WHERE id = ? AND user_id = ?`
    )
    .get(mediaId, userId) as unknown as MediaAssetAudioRow | undefined;

  if (!asset || asset.media_kind !== 'audio') {
    return { status: 'not_analyzed', cached: false, analysis: null };
  }

  const cachedRow = db
    .prepare(
      `SELECT * FROM audio_analyses
       WHERE media_id = ? AND user_id = ? AND file_sha256 = ? AND engine_version = ?`
    )
    .get(mediaId, userId, asset.sha256, AUDIO_ENGINE_VERSION) as unknown as
    | CachedAnalysisRow
    | undefined;

  if (!cachedRow) {
    return { status: 'not_analyzed', cached: false, analysis: null };
  }

  try {
    const parsed = JSON.parse(cachedRow.analysis_json) as StructuredAudioAnalysis;
    return { status: 'ready', cached: true, analysis: parsed };
  } catch {
    return { status: 'not_analyzed', cached: false, analysis: null };
  }
}

export async function analyzeAudioAsset(
  mediaId: string,
  userId: string,
  options: { force?: boolean } = {}
): Promise<{ cached: boolean; analysis: StructuredAudioAnalysis }> {
  const asset = db
    .prepare(
      `SELECT id, user_id, project_id, media_kind, original_name, stored_filename, duration_sec, sha256
       FROM media_assets WHERE id = ? AND user_id = ?`
    )
    .get(mediaId, userId) as unknown as MediaAssetAudioRow | undefined;

  if (!asset) {
    throw new Error('Audio asset not found.');
  }
  if (asset.media_kind !== 'audio') {
    throw new Error('Audio intelligence analysis is only supported on audio files.');
  }

  if (!options.force) {
    const existing = getCachedAudioAnalysis(mediaId, userId);
    if (existing.status === 'ready' && existing.analysis) {
      return { cached: true, analysis: existing.analysis };
    }
  }

  const filePath = resolveSafeStoragePath('uploads', userId, asset.stored_filename);
  if (!fs.existsSync(filePath)) {
    throw new Error('Stored audio file is missing on server.');
  }

  const startedAt = performance.now();
  const { samples, decoderOffsetSec } = await decodeAudioToMonoPcmWithTiming(filePath);
  const features = extractAudioFeatures(samples, { decoderOffsetSec });
  const beatIntelligence = beatModule.analyzeFeatures(features);
  const structure = musicModule.detectStructureFromFeatures(features, beatIntelligence);
  const processingMs = Math.max(1, Math.round(performance.now() - startedAt));

  // Energy summary metrics
  let sumRms = 0;
  let peakRms = 0;
  let minNonZeroRms = 1;
  for (let i = 0; i < features.rms.length; i++) {
    const v = features.rms[i];
    sumRms += v;
    if (v > peakRms) peakRms = v;
    if (v > 0.002 && v < minNonZeroRms) minNonZeroRms = v;
  }
  const meanRms = sumRms / Math.max(1, features.rms.length);
  const dynamicRangeDb =
    peakRms > minNonZeroRms ? 20 * Math.log10(peakRms / Math.max(1e-4, minNonZeroRms)) : 0;

  const notes: string[] = [];
  if (beatIntelligence.rhythmPattern === 'weak-or-irregular') {
    notes.push(
      'Rhythmic transients are sparse or irregular; beat markers and BPM carry lower confidence.'
    );
  }
  if (beatIntelligence.tempoChanges.length > 0) {
    notes.push(
      `Detected ${beatIntelligence.tempoChanges.length} local tempo shift(s) across the track.`
    );
  }
  if (structure.confidence < 0.5) {
    notes.push(
      'Dynamic energy contrast across sections is relatively uniform; section labels are approximate.'
    );
  }

  const analysis: StructuredAudioAnalysis = {
    version: AUDIO_ENGINE_VERSION,
    mediaId: asset.id,
    durationSec: Number(features.durationSec.toFixed(3)),
    sampleRateAnalyzed: ANALYSIS_SAMPLE_RATE,
    processingMs,
    analyzedAt: new Date().toISOString(),
    beatIntelligence,
    sections: structure.sections,
    overallStructureConfidence: structure.confidence,
    energySummary: {
      meanRms: Number(meanRms.toFixed(4)),
      peakRms: Number(peakRms.toFixed(4)),
      dynamicRangeDb: Number(dynamicRangeDb.toFixed(1)),
    },
    waveform: features.waveform,
    energyCurve: features.energyCurve,
    notes,
  };

  const nowIso = new Date().toISOString();
  const serialized = JSON.stringify(analysis);

  db.prepare(
    `INSERT INTO audio_analyses (
       id, media_id, user_id, project_id, file_sha256, engine_version,
       analysis_json, processing_ms, created_at, updated_at
     ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(media_id) DO UPDATE SET
       file_sha256 = excluded.file_sha256,
       engine_version = excluded.engine_version,
       analysis_json = excluded.analysis_json,
       processing_ms = excluded.processing_ms,
       updated_at = excluded.updated_at`
  ).run(
    crypto.randomUUID(),
    asset.id,
    userId,
    asset.project_id,
    asset.sha256,
    AUDIO_ENGINE_VERSION,
    serialized,
    processingMs,
    nowIso,
    nowIso
  );

  return { cached: false, analysis };
}

/**
 * Clean interface for Milestone 5 EditingIntelligenceModule to consume structured audio data directly.
 */
export async function getStructuredAudioAnalysisForEngine(
  mediaId: string,
  userId: string
): Promise<StructuredAudioAnalysis> {
  const result = await analyzeAudioAsset(mediaId, userId, { force: false });
  return result.analysis;
}
