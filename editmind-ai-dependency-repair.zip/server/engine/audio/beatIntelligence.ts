import type {
  AudioFrameFeatures,
  AudioSignificantEvent,
  BeatAnalysisResult,
  BeatIntelligenceModule,
  BeatMarker,
  EngineModuleDescriptor,
  TempoChangeEvent,
  TempoSegment,
} from '../contracts.ts';
import { decodeAudioToMonoPcmWithTiming, extractAudioFeatures } from './dsp.ts';

function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}

function cosineDistance(a: Float64Array, b: Float64Array): number {
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  const denom = Math.sqrt(na) * Math.sqrt(nb);
  if (denom <= 1e-9) return 0;
  return Math.max(0, Math.min(1, 1 - dot / denom));
}

function refineBeatTimestamps(beatFrames: number[], features: AudioFrameFeatures): number[] {
  const {
    frameDurationSec,
    frameCenterOffsetSec,
    decoderOffsetSec,
    subFrameStepSec,
    subFrameEnergy,
  } = features;

  if (beatFrames.length === 0) return [];
  const totalSf = subFrameEnergy.length;
  if (totalSf < 8 || subFrameStepSec <= 0) {
    return beatFrames.map((f) =>
      Number((f * frameDurationSec + frameCenterOffsetSec + decoderOffsetSec).toFixed(3))
    );
  }

  const candidateOffsets: Array<number | null> = new Array(beatFrames.length).fill(null);
  const validOffsets: number[] = [];

  for (let i = 0; i < beatFrames.length; i++) {
    const centerSec = beatFrames[i] * frameDurationSec + frameCenterOffsetSec;
    const baseLo = Math.max(0, Math.floor((centerSec - 0.055) / subFrameStepSec));
    const searchLo = Math.max(2, Math.floor((centerSec - 0.018) / subFrameStepSec));
    const searchHi = Math.min(totalSf - 2, Math.ceil((centerSec + 0.032) / subFrameStepSec));

    if (searchHi <= searchLo) continue;

    // Pre-onset baseline (median in [center - 55ms, center - 18ms])
    const baseSlice: number[] = [];
    for (let k = baseLo; k < searchLo; k++) {
      baseSlice.push(subFrameEnergy[k]);
    }
    baseSlice.sort((a, b) => a - b);
    const localBaseline = baseSlice.length > 0 ? baseSlice[Math.floor(baseSlice.length / 2)] : 0;

    let bestScore = 0;
    let bestK = -1;
    let bestPeakE = 0;

    for (let k = searchLo; k <= searchHi; k++) {
      const slope = Math.max(0, subFrameEnergy[k + 1] - subFrameEnergy[k - 2]);
      const tCand = k * subFrameStepSec;
      // Mild preference near expected center (+10ms prior balances flux lead vs center)
      const distPenalty = 1 - 0.12 * Math.min(1, Math.abs(tCand - (centerSec + 0.01)) / 0.032);
      const score = slope * distPenalty;
      if (score > bestScore) {
        bestScore = score;
        bestK = k;
        bestPeakE = Math.max(subFrameEnergy[k], subFrameEnergy[k + 1]);
      }
    }

    if (bestK >= 0 && bestScore > Math.max(0.008, localBaseline * 0.32)) {
      const jump = bestPeakE - localBaseline;
      const threshold25 = localBaseline + jump * 0.25;
      let kneeK = bestK;
      for (let back = 0; back < 4 && kneeK - 1 >= searchLo; back++) {
        if (subFrameEnergy[kneeK - 1] >= threshold25) {
          kneeK--;
        } else {
          break;
        }
      }
      const delta = kneeK * subFrameStepSec - centerSec;
      candidateOffsets[i] = delta;
      validOffsets.push(delta);
    }
  }

  let medianOffset = 0;
  if (validOffsets.length > 0) {
    const sorted = [...validOffsets].sort((a, b) => a - b);
    medianOffset = sorted[Math.floor(sorted.length / 2)];
  }

  return beatFrames.map((f, i) => {
    const centerSec = f * frameDurationSec + frameCenterOffsetSec;
    const rawDelta = candidateOffsets[i];
    // Constrain individual snaps within +-14ms of median rhythmic phase to avoid jitter
    const finalDelta =
      rawDelta !== null
        ? Math.max(medianOffset - 0.014, Math.min(medianOffset + 0.014, rawDelta))
        : medianOffset;
    return Number(Math.max(0, centerSec + finalDelta + decoderOffsetSec).toFixed(3));
  });
}

function normalizeOnsetEnvelope(onsetFlux: Float32Array, rms: Float32Array): Float32Array {
  const n = onsetFlux.length;
  const out = new Float32Array(n);
  const win = 15; // ~175 ms local adaptive baseline

  // Check raw flux dynamic floor so steady ambient/drone beating isn't amplified to 1.0
  let maxRawFlux = 0;
  let meanRms = 0;
  for (let i = 0; i < n; i++) {
    if (onsetFlux[i] > maxRawFlux) maxRawFlux = onsetFlux[i];
    meanRms += rms[i];
  }
  meanRms /= Math.max(1, n);
  const minRawPeakFloor = Math.max(0.018, meanRms * 0.08);
  const denomScale = Math.max(maxRawFlux, minRawPeakFloor);

  const rawDiffs = new Float32Array(n);
  let maxDiff = 0;

  for (let i = 0; i < n; i++) {
    let sum = 0;
    let count = 0;
    const lo = Math.max(0, i - win);
    const hi = Math.min(n - 1, i + win);
    for (let j = lo; j <= hi; j++) {
      sum += onsetFlux[j];
      count++;
    }
    const mean = sum / Math.max(1, count);
    const diff = onsetFlux[i] - mean * 1.05;
    // Gate pure silence and sub-threshold steady-state beating
    const gated = rms[i] > 0.004 && diff > denomScale * 0.02 ? diff : 0;
    rawDiffs[i] = gated;
    if (gated > maxDiff) maxDiff = gated;
  }

  const normDenom = Math.max(maxDiff, minRawPeakFloor);
  for (let i = 0; i < n; i++) {
    out[i] = Math.min(1, rawDiffs[i] / normDenom);
  }
  return out;
}

function estimateTempoFromOnsets(
  odf: Float32Array,
  frameDurationSec: number,
  startFrame = 0,
  endFrame = odf.length
): { bpm: number; confidence: number } {
  const minBpm = 55;
  const maxBpm = 190;
  const minLag = Math.max(2, Math.floor(60 / (maxBpm * frameDurationSec)));
  const maxLag = Math.max(minLag + 2, Math.ceil(60 / (minBpm * frameDurationSec)));

  const sliceLen = endFrame - startFrame;
  if (sliceLen <= maxLag + 4) {
    return { bpm: 0, confidence: 0 };
  }

  let activeEnergy = 0;
  for (let i = startFrame; i < endFrame; i++) {
    activeEnergy += odf[i];
  }
  if (activeEnergy < 1.0) {
    return { bpm: 0, confidence: 0.05 };
  }

  const rawScores = new Float64Array(maxLag + 1);
  const weightedScores = new Float64Array(maxLag + 1);
  let meanRaw = 0;
  let lagCount = 0;

  for (let lag = minLag; lag <= maxLag; lag++) {
    let acf = 0;
    const limit = endFrame - lag;
    for (let i = startFrame; i < limit; i++) {
      acf += odf[i] * odf[i + lag];
    }
    const normAcf = acf / Math.max(1, limit - startFrame);

    // Comb-filter harmonic support (2x and 0.5x lag)
    let h2 = 0;
    if (lag * 2 <= maxLag && endFrame - lag * 2 > startFrame) {
      const lim2 = endFrame - lag * 2;
      for (let i = startFrame; i < lim2; i++) {
        h2 += odf[i] * odf[i + lag * 2];
      }
      h2 /= Math.max(1, lim2 - startFrame);
    }

    const comb = normAcf + 0.35 * h2;
    rawScores[lag] = comb;
    meanRaw += comb;
    lagCount++;

    const bpm = 60 / (lag * frameDurationSec);
    // Gentle log-normal prior centered around 118 BPM strictly to break 2x/0.5x ties
    const prior = Math.exp(-0.5 * Math.pow(Math.log2(bpm / 118) / 0.68, 2));
    weightedScores[lag] = comb * (0.75 + 0.25 * prior);
  }

  meanRaw /= Math.max(1, lagCount);

  let bestLag = minLag;
  let bestWeighted = -1;
  for (let lag = minLag; lag <= maxLag; lag++) {
    if (weightedScores[lag] > bestWeighted) {
      bestWeighted = weightedScores[lag];
      bestLag = lag;
    }
  }

  // Parabolic interpolation around bestLag for sub-frame BPM precision
  let refinedLag = bestLag;
  if (bestLag > minLag && bestLag < maxLag) {
    const y0 = rawScores[bestLag - 1];
    const y1 = rawScores[bestLag];
    const y2 = rawScores[bestLag + 1];
    const denom = 2 * (y0 - 2 * y1 + y2);
    if (Math.abs(denom) > 1e-12) {
      const delta = (y0 - y2) / denom;
      if (Math.abs(delta) < 1) {
        refinedLag = bestLag + delta;
      }
    }
  }

  const bpm = 60 / (refinedLag * frameDurationSec);
  const prominence = meanRaw > 1e-9 ? rawScores[bestLag] / meanRaw : 1;
  const confidence = Math.max(0, Math.min(1, (prominence - 1.15) / 2.2));

  return {
    bpm: Number(bpm.toFixed(2)),
    confidence: Number(confidence.toFixed(3)),
  };
}

function trackBeatsDp(
  odf: Float32Array,
  rms: Float32Array,
  frameDurationSec: number,
  initialBpm: number
): number[] {
  const n = odf.length;
  if (n < 10 || initialBpm <= 0) return [];

  const targetPeriod = Math.max(4, Math.round(60 / (initialBpm * frameDurationSec)));
  const minTau = Math.max(3, Math.round(targetPeriod * 0.55));
  const maxTau = Math.min(n - 1, Math.round(targetPeriod * 1.75));
  const transitionLambda = 0.65;

  // Smooth ODF slightly with a 3-frame triangular kernel for beat alignment tolerance
  const localScore = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const prev = i > 0 ? odf[i - 1] : 0;
    const cur = odf[i];
    const next = i + 1 < n ? odf[i + 1] : 0;
    localScore[i] = 0.25 * prev + 0.5 * cur + 0.25 * next;
  }

  const cumScore = new Float64Array(n);
  const backPtr = new Int32Array(n).fill(-1);

  for (let t = 0; t < n; t++) {
    let bestPrevScore = 0;
    let bestPrevIdx = -1;

    const tauEnd = Math.min(maxTau, t);
    for (let tau = minTau; tau <= tauEnd; tau++) {
      const prevIdx = t - tau;
      const logRatio = Math.log(tau / targetPeriod);
      const cand = cumScore[prevIdx] - transitionLambda * logRatio * logRatio;
      if (cand > bestPrevScore) {
        bestPrevScore = cand;
        bestPrevIdx = prevIdx;
      }
    }

    cumScore[t] = localScore[t] + bestPrevScore;
    backPtr[t] = bestPrevIdx;
  }

  // Start backtrack from highest score near the end of audible audio
  let endFrame = n - 1;
  while (endFrame > 0 && rms[endFrame] < 0.004) {
    endFrame--;
  }
  const searchStart = Math.max(0, endFrame - maxTau);
  let bestEnd = endFrame;
  let bestEndScore = -Infinity;
  for (let t = searchStart; t <= endFrame; t++) {
    if (cumScore[t] > bestEndScore) {
      bestEndScore = cumScore[t];
      bestEnd = t;
    }
  }

  const frames: number[] = [];
  let cursor = bestEnd;
  while (cursor >= 0) {
    // Only keep beat frames that occur in non-dead-silence or have real onset score
    if (rms[cursor] > 0.004 || localScore[cursor] > 0.06) {
      frames.push(cursor);
    }
    cursor = backPtr[cursor];
  }
  frames.reverse();

  // Deduplicate any abnormally close frames (< 45% targetPeriod)
  const cleaned: number[] = [];
  const minSeparation = Math.max(3, Math.round(targetPeriod * 0.45));
  for (const f of frames) {
    if (cleaned.length === 0 || f - cleaned[cleaned.length - 1] >= minSeparation) {
      cleaned.push(f);
    }
  }
  return cleaned;
}

function detectEvents(
  features: AudioFrameFeatures,
  tempoChanges: TempoChangeEvent[]
): AudioSignificantEvent[] {
  const { rms, frameDurationSec, frameCenterOffsetSec, decoderOffsetSec } = features;
  const timeBiasSec = frameCenterOffsetSec + decoderOffsetSec;
  const n = rms.length;
  const events: AudioSignificantEvent[] = [];

  let peakRms = 1e-6;
  for (let i = 0; i < n; i++) {
    if (rms[i] > peakRms) peakRms = rms[i];
  }

  // 1. Silence intervals (>= 0.6s)
  const silenceThreshold = Math.max(0.004, peakRms * 0.035);
  const minSilenceFrames = Math.ceil(0.6 / frameDurationSec);
  let silentStart = -1;
  for (let i = 0; i <= n; i++) {
    const isSilent = i < n && rms[i] < silenceThreshold;
    if (isSilent && silentStart === -1) {
      silentStart = i;
    } else if (!isSilent && silentStart !== -1) {
      const len = i - silentStart;
      if (len >= minSilenceFrames) {
        const startSec = Number(Math.max(0, silentStart * frameDurationSec + timeBiasSec).toFixed(2));
        const endSec = Number(Math.max(startSec, i * frameDurationSec + timeBiasSec).toFixed(2));
        events.push({
          type: 'silence',
          startSec,
          endSec,
          intensity: 0,
          summary: `Low-signal / silence gap (${(endSec - startSec).toFixed(1)}s)`,
        });
      }
      silentStart = -1;
    }
  }

  // 2. Energy surges & drops using 2-second step windows
  const winFrames = Math.max(8, Math.round(2.0 / frameDurationSec));
  const winMeans: number[] = [];
  for (let start = 0; start < n; start += winFrames) {
    const end = Math.min(n, start + winFrames);
    let acc = 0;
    for (let j = start; j < end; j++) acc += rms[j];
    winMeans.push(acc / Math.max(1, end - start));
  }

  for (let w = 2; w < winMeans.length; w++) {
    const baseline = (winMeans[w - 2] + winMeans[w - 1]) / 2;
    const current = winMeans[w];
    if (baseline > peakRms * 0.08 && current > baseline * 1.75) {
      const startSec = Number((w * winFrames * frameDurationSec + timeBiasSec).toFixed(2));
      const endSec = Number(Math.min(features.durationSec, startSec + 2.0).toFixed(2));
      events.push({
        type: 'energy-surge',
        startSec,
        endSec,
        intensity: Number(Math.min(1, current / peakRms).toFixed(3)),
        summary: `Energy surge (+${Math.round(((current - baseline) / baseline) * 100)}%)`,
      });
    } else if (baseline > peakRms * 0.2 && current < baseline * 0.45 && current > silenceThreshold) {
      const startSec = Number((w * winFrames * frameDurationSec + timeBiasSec).toFixed(2));
      const endSec = Number(Math.min(features.durationSec, startSec + 2.0).toFixed(2));
      events.push({
        type: 'energy-drop',
        startSec,
        endSec,
        intensity: Number(Math.min(1, current / peakRms).toFixed(3)),
        summary: `Energy breakdown (-${Math.round(((baseline - current) / baseline) * 100)}%)`,
      });
    }
  }

  // 3. Tempo shift events
  for (const tc of tempoChanges) {
    events.push({
      type: 'tempo-shift',
      startSec: tc.timestampSec,
      endSec: Number(Math.min(features.durationSec, tc.timestampSec + 2.0).toFixed(2)),
      intensity: Number(Math.min(1, Math.abs(tc.deltaPercent) / 40).toFixed(3)),
      summary: `Tempo shift from ${tc.fromBpm.toFixed(0)} to ${tc.toBpm.toFixed(0)} BPM`,
    });
  }

  events.sort((a, b) => a.startSec - b.startSec);
  return events.slice(0, 32);
}

export class EditmindBeatIntelligence implements BeatIntelligenceModule {
  readonly descriptor: EngineModuleDescriptor = {
    id: 'beat-intelligence',
    name: 'Beat Intelligence',
    milestoneTarget: 3,
    status: 'active',
    provider: 'Self-hosted DSP (FFmpeg PCM + Multi-Band Spectral Flux + DP Beat Tracker)',
    summary: 'Detects BPM, beat grids, downbeats, tempo shifts, and high-energy transients from uploaded audio.',
    outputs: ['BPM estimate', 'Beat timestamps', 'Downbeat markers', 'Transient peaks'],
    externalDependencyPolicy: 'Local open-source audio analysis; zero external LLM calls.',
  };

  async analyzeAudio(audioFilePath: string): Promise<BeatAnalysisResult> {
    const { samples, decoderOffsetSec } = await decodeAudioToMonoPcmWithTiming(audioFilePath);
    const features = extractAudioFeatures(samples, { decoderOffsetSec });
    return this.analyzeFeatures(features);
  }

  analyzeFeatures(features: AudioFrameFeatures): BeatAnalysisResult {
    const {
      onsetFlux,
      rms,
      lowEnergy,
      midEnergy,
      highEnergy,
      melBands,
      frameDurationSec,
      frameCenterOffsetSec,
      decoderOffsetSec,
      durationSec,
    } = features;
    const odf = normalizeOnsetEnvelope(onsetFlux, rms);

    const globalTempo = estimateTempoFromOnsets(odf, frameDurationSec);
    if (globalTempo.bpm <= 0) {
      return {
        bpm: 0,
        bpmConfidence: 0,
        rhythmPattern: 'weak-or-irregular',
        rhythmRegularity: 0,
        averageBeatIntervalSec: 0,
        beatTimestampsSec: [],
        downbeatTimestampsSec: [],
        strongBeatTimestampsSec: [],
        beats: [],
        downbeatConfidence: 0,
        energyPeaksSec: [],
        tempoSegments: [],
        tempoChanges: [],
        events: detectEvents(features, []),
      };
    }

    const beatFrames = trackBeatsDp(odf, rms, frameDurationSec, globalTempo.bpm);
    const rawTimestamps = refineBeatTimestamps(beatFrames, features);

    // Compute inter-beat intervals and rhythm regularity
    const ibis: number[] = [];
    for (let i = 1; i < rawTimestamps.length; i++) {
      ibis.push(rawTimestamps[i] - rawTimestamps[i - 1]);
    }
    const meanIbi =
      ibis.length > 0 ? ibis.reduce((a, b) => a + b, 0) / ibis.length : 60 / globalTempo.bpm;
    const ibiStd =
      ibis.length > 1
        ? Math.sqrt(ibis.reduce((acc, v) => acc + Math.pow(v - meanIbi, 2), 0) / ibis.length)
        : 0;
    const rhythmRegularity =
      meanIbi > 0 ? Math.max(0, Math.min(1, 1 - ibiStd / (meanIbi * 0.5))) : 0;

    // Measure beat alignment against real onsets and collect per-beat acoustic cues
    let hitOnsets = 0;
    const beatStrengths: number[] = [];
    const beatLowRaw: number[] = [];
    const beatHighRaw: number[] = [];
    const beatMidHighRatio: number[] = [];
    const beatMelProfiles: Float64Array[] = [];

    let maxLow = 1e-6;
    for (let i = 0; i < lowEnergy.length; i++) {
      if (lowEnergy[i] > maxLow) maxLow = lowEnergy[i];
    }

    for (let bIdx = 0; bIdx < beatFrames.length; bIdx++) {
      const f = beatFrames[bIdx];
      let localMaxOdf = 0;
      let localLow = 0;
      let localMid = 0;
      let localHigh = 0;

      for (let d = -2; d <= 3; d++) {
        const idx = f + d;
        if (idx >= 0 && idx < odf.length) {
          if (odf[idx] > localMaxOdf) localMaxOdf = odf[idx];
          if (lowEnergy[idx] > localLow) localLow = lowEnergy[idx];
          localMid += midEnergy[idx];
          localHigh += highEnergy[idx];
        }
      }

      if (localMaxOdf >= 0.18) hitOnsets++;
      beatStrengths.push(Math.min(1, 0.55 * localMaxOdf + 0.45 * (localLow / maxLow)));
      beatLowRaw.push(localLow);
      beatHighRaw.push((localMid + localHigh) / 6);
      beatMidHighRatio.push((localMid + localHigh) / (localLow * 6 + localMid + localHigh + 1e-6));

      // Average mel profile across [beat_i .. nextBeat) for harmonic/timbral change detection
      const nextF =
        bIdx + 1 < beatFrames.length
          ? Math.max(f + 1, beatFrames[bIdx + 1])
          : Math.min(melBands.length, f + Math.max(4, Math.round(meanIbi / frameDurationSec)));
      const prof = new Float64Array(12);
      const count = Math.max(1, nextF - f);
      for (let k = f; k < nextF && k < melBands.length; k++) {
        const mb = melBands[k];
        for (let m = 0; m < 12; m++) prof[m] += mb[m];
      }
      for (let m = 0; m < 12; m++) prof[m] /= count;
      beatMelProfiles.push(prof);
    }

    // Measure macro-envelope transient modulation using 46ms FFT-window RMS (averages out raw wave cycles)
    let meanRmsAll = 0;
    for (let i = 0; i < rms.length; i++) meanRmsAll += rms[i];
    meanRmsAll /= Math.max(1, rms.length);

    let envModulationScore = 1;
    if (rms.length > 8 && meanRmsAll > 1e-6) {
      const envJumps = new Float32Array(rms.length - 2);
      for (let f = 2; f < rms.length; f++) {
        envJumps[f - 2] = Math.max(0, rms[f] - rms[f - 2]);
      }
      const sortedEnv = Array.from(envJumps).sort((a, b) => a - b);
      const p98Env = sortedEnv[Math.floor(sortedEnv.length * 0.98)] || 0;
      const p95Env = sortedEnv[Math.floor(sortedEnv.length * 0.95)] || 0;
      const modRatio = (0.6 * p98Env + 0.4 * p95Env) / meanRmsAll;
      // Steady sine drones/pads have modRatio < 0.08; percussive/plucked rhythmic tracks have >= 0.25
      envModulationScore = clamp01((modRatio - 0.06) / 0.22);
    }

    const onsetHitRatio = beatFrames.length > 0 ? hitOnsets / beatFrames.length : 0;
    let combinedConfidence = Math.max(
      0,
      Math.min(1, 0.5 * globalTempo.confidence + 0.3 * onsetHitRatio + 0.2 * rhythmRegularity)
    );
    if (onsetHitRatio < 0.35) {
      combinedConfidence = Math.min(combinedConfidence, onsetHitRatio * 0.75);
    }
    if (envModulationScore < 0.65) {
      combinedConfidence = Math.min(combinedConfidence, 0.08 + envModulationScore * 0.30);
    }

    // Local tempo segmentation (windows of 6 beats) to detect tempo shifts
    const tempoSegments: TempoSegment[] = [];
    const tempoChanges: TempoChangeEvent[] = [];
    if (ibis.length >= 8) {
      const stepBeats = 4;
      for (let startB = 0; startB < ibis.length - 3; startB += stepBeats) {
        const endB = Math.min(ibis.length, startB + 6);
        const sub = ibis.slice(startB, endB).sort((a, b) => a - b);
        const medianIbi = sub[Math.floor(sub.length / 2)];
        const segBpm = Number((60 / Math.max(0.2, medianIbi)).toFixed(2));
        const startSec = rawTimestamps[startB];
        const endSec = rawTimestamps[Math.min(rawTimestamps.length - 1, endB)];

        const prevSeg = tempoSegments[tempoSegments.length - 1];
        if (prevSeg && Math.abs(segBpm - prevSeg.bpm) / Math.max(1, prevSeg.bpm) < 0.06) {
          prevSeg.endSec = endSec;
          prevSeg.bpm = Number(((prevSeg.bpm + segBpm) / 2).toFixed(2));
        } else {
          if (prevSeg) {
            const deltaPct = ((segBpm - prevSeg.bpm) / Math.max(1, prevSeg.bpm)) * 100;
            if (Math.abs(deltaPct) >= 6) {
              tempoChanges.push({
                timestampSec: startSec,
                fromBpm: prevSeg.bpm,
                toBpm: segBpm,
                deltaPercent: Number(deltaPct.toFixed(1)),
              });
            }
          }
          tempoSegments.push({ startSec, endSec, bpm: segBpm });
        }
      }
    } else if (rawTimestamps.length >= 2) {
      tempoSegments.push({
        startSec: 0,
        endSec: Number(durationSec.toFixed(2)),
        bpm: globalTempo.bpm,
      });
    }

    // Meter-aware adaptive downbeat & bar-hierarchy detection
    const nBeats = beatFrames.length;
    const spectralNovelty = new Float64Array(nBeats);
    for (let i = 1; i < nBeats; i++) {
      spectralNovelty[i] = cosineDistance(beatMelProfiles[i], beatMelProfiles[i - 1]);
    }
    if (nBeats > 0) {
      spectralNovelty[0] = Math.min(1, (beatLowRaw[0] / maxLow) * 0.4);
    }

    // Local relative low/high contrast vs +-4-beat neighborhood (handles quiet intros + loud drops equally)
    const lowRel = new Float64Array(nBeats);
    const highRel = new Float64Array(nBeats);
    for (let i = 0; i < nBeats; i++) {
      const lo = Math.max(0, i - 4);
      const hi = Math.min(nBeats - 1, i + 4);
      let lSum = 0;
      let hSum = 0;
      let cnt = 0;
      for (let j = lo; j <= hi; j++) {
        lSum += beatLowRaw[j];
        hSum += beatHighRaw[j];
        cnt++;
      }
      const lMean = lSum / Math.max(1, cnt);
      const hMean = hSum / Math.max(1, cnt);
      lowRel[i] = lMean > 1e-6 ? Math.min(2.5, beatLowRaw[i] / lMean) : 0;
      highRel[i] = hMean > 1e-6 ? Math.min(2.5, beatHighRaw[i] / hMean) : 0;
    }

    // Measure local attack peak directly from 2ms sub-frame energy around refined beat timestamps
    // to eliminate coarse FFT-frame grid Moire aliasing on unaccented steady beats
    const beatAttackAmp = new Float64Array(nBeats);
    if (features.subFrameEnergy.length > 8 && features.subFrameStepSec > 0) {
      for (let i = 0; i < nBeats; i++) {
        const tsLocal = Math.max(0, rawTimestamps[i] - decoderOffsetSec);
        const sfLo = Math.max(
          0,
          Math.floor((tsLocal - 0.008) / features.subFrameStepSec)
        );
        const sfHi = Math.min(
          features.subFrameEnergy.length - 1,
          Math.ceil((tsLocal + 0.035) / features.subFrameStepSec)
        );
        let peakE = 0;
        for (let k = sfLo; k <= sfHi; k++) {
          if (features.subFrameEnergy[k] > peakE) peakE = features.subFrameEnergy[k];
        }
        beatAttackAmp[i] = peakE;
      }
    }

    const attackRel = new Float64Array(nBeats);
    for (let i = 0; i < nBeats; i++) {
      const lo = Math.max(0, i - 4);
      const hi = Math.min(nBeats - 1, i + 4);
      let aSum = 0;
      let cnt = 0;
      for (let j = lo; j <= hi; j++) {
        aSum += beatAttackAmp[j];
        cnt++;
      }
      const aMean = aSum / Math.max(1, cnt);
      attackRel[i] = aMean > 1e-6 ? Math.min(2.5, beatAttackAmp[i] / aMean) : lowRel[i];
    }

    // Normalize spectral novelty with a real physical floor so FFT discretization jitter on
    // identical clicks does not blow up into fake bar contrast
    const sortedSpec = Array.from(spectralNovelty).sort((a, b) => a - b);
    const specScale = Math.max(0.04, sortedSpec[Math.floor(sortedSpec.length * 0.85)] || 0.05);

    interface MeterEval {
      meter: 3 | 4;
      bestPhase: number;
      meanRatio: number;
      zMargin: number;
      barWinAboveChance: number;
      candidateScore: number;
      beatEvidence: Float64Array;
    }

    const evaluateMeter = (m: 3 | 4): MeterEval => {
      const beatEvidence = new Float64Array(nBeats);
      for (let i = 0; i < nBeats; i++) {
        const specNorm = Math.min(1.8, spectralNovelty[i] / specScale);
        const rawScore =
          (m === 4 ? 0.34 : 0.48) * attackRel[i] +
          (m === 4 ? 0.14 : 0.22) * lowRel[i] +
          (m === 4 ? 0.20 : 0.22) * beatStrengths[i] +
          0.10 * highRel[i] +
          (m === 4 ? 0.52 : 0.22) * specNorm;

        // For 4/4, add backbeat (snare/clap on beats 2 & 4 relative to downbeat i) confirmation
        if (m === 4 && i + 3 < nBeats) {
          const bb1 = beatMidHighRatio[i + 1];
          const bb3 = beatMidHighRatio[i + 3];
          const onBeat0 = beatMidHighRatio[i];
          const backbeatBoost = Math.max(0, (bb1 + bb3) / 2 - onBeat0);
          beatEvidence[i] = rawScore + 0.45 * backbeatBoost;
        } else {
          beatEvidence[i] = rawScore;
        }
      }

      const phaseTotals = new Float64Array(m);
      const phaseCounts = new Int32Array(m);
      const barWins = new Int32Array(m);
      let fullBars = 0;

      // Skip edge beat 0 and final beat when accumulating phase totals to avoid t=0 boundary bias
      for (let i = 1; i < nBeats - 1; i++) {
        phaseTotals[i % m] += beatEvidence[i];
        phaseCounts[i % m]++;
      }

      for (let base = m; base + m <= nBeats - 1; base += m) {
        let maxVal = -Infinity;
        let minVal = Infinity;
        let winnerOffset = 0;
        for (let q = 0; q < m; q++) {
          const val = beatEvidence[base + q];
          if (val > maxVal) {
            maxVal = val;
            winnerOffset = q;
          }
          if (val < minVal) minVal = val;
        }
        // Require at least 8% bar-internal accent spread so identical-click bars don't vote randomly
        if (maxVal > 1e-6 && (maxVal - minVal) / maxVal >= 0.08) {
          barWins[winnerOffset]++;
        }
        fullBars++;
      }

      const phaseMeans = new Array<number>(m);
      for (let p = 0; p < m; p++) {
        phaseMeans[p] = phaseCounts[p] > 0 ? phaseTotals[p] / phaseCounts[p] : 0;
      }

      let bestPhase = 0;
      let bestMean = -Infinity;
      for (let p = 0; p < m; p++) {
        if (phaseMeans[p] > bestMean) {
          bestMean = phaseMeans[p];
          bestPhase = p;
        }
      }

      let runnerUpMean = -Infinity;
      let sumMeans = 0;
      for (let p = 0; p < m; p++) {
        sumMeans += phaseMeans[p];
        if (p !== bestPhase && phaseMeans[p] > runnerUpMean) {
          runnerUpMean = phaseMeans[p];
        }
      }
      const overallMean = sumMeans / m;
      const variance =
        phaseMeans.reduce((acc, v) => acc + Math.pow(v - overallMean, 2), 0) / m;
      // Floor phaseStd at 4% of overallMean so micro-jitter never inflates zMargin
      const phaseStd = Math.max(overallMean * 0.04, Math.sqrt(variance));

      const meanRatio = overallMean > 1e-6 ? bestMean / overallMean : 1;
      const zMargin = phaseStd > 1e-5 ? (bestMean - runnerUpMean) / phaseStd : 0;
      const winFrac = fullBars > 0 ? barWins[bestPhase] / fullBars : 0;
      const barWinAboveChance = clamp01((winFrac - 1 / m) / (1 - 1 / m));

      const candidateScore =
        0.38 * clamp01(zMargin / 1.9) +
        0.37 * clamp01(barWinAboveChance / 0.55) +
        0.25 * clamp01((meanRatio - 1.04) / 0.22);

      return {
        meter: m,
        bestPhase,
        meanRatio,
        zMargin,
        barWinAboveChance,
        candidateScore,
        beatEvidence,
      };
    };

    const eval4 = evaluateMeter(4);
    const eval3 = evaluateMeter(3);

    // Choose 3/4 when its bar-consistency & margin beat 4/4 (even slightly, since 3/4 is rarer and
    // a 3/4 pulse rotating through a 4-beat window cannot maintain high barWinAboveChance in eval4)
    const score3Comp = eval3.barWinAboveChance + 0.30 * clamp01(eval3.zMargin / 2.0);
    const score4Comp = eval4.barWinAboveChance + 0.30 * clamp01(eval4.zMargin / 2.0);
    const selectedMeter =
      score3Comp > score4Comp + 0.03 && eval3.barWinAboveChance >= 0.30 ? eval3 : eval4;

    const meter = selectedMeter.meter;
    const bestPhase = selectedMeter.bestPhase;

    const bpmScale = clamp01((combinedConfidence - 0.22) / 0.45);
    const downbeatConfidence =
      nBeats >= 6 ? Number((selectedMeter.candidateScore * bpmScale).toFixed(3)) : 0;

    // Adaptive non-fabrication gate: emit downbeats only when genuine metrical hierarchy exists
    const rhythmReliable =
      combinedConfidence >= 0.36 &&
      onsetHitRatio >= 0.35 &&
      rhythmRegularity >= 0.45 &&
      envModulationScore >= 0.50 &&
      nBeats >= 6;
    const meterHierarchyClear =
      selectedMeter.meanRatio >= 1.06 &&
      selectedMeter.candidateScore >= 0.28 &&
      (selectedMeter.barWinAboveChance >= 0.22 || selectedMeter.zMargin >= 0.90);
    const shouldEmitDownbeats = rhythmReliable && meterHierarchyClear;

    // Track bar phase with gap re-anchoring so dropped beats in silent breaks don't shift future bars
    const isDownbeatFlags = new Array<boolean>(nBeats).fill(false);
    if (shouldEmitDownbeats) {
      let currentPhaseOffset = bestPhase;
      for (let i = 0; i < nBeats; i++) {
        if (i > 0 && ibis[i - 1] > meanIbi * 1.65 && i + meter <= nBeats) {
          // Re-anchor phase on the strongest candidate in the next complete bar after a long gap
          let bestLocalQ = 0;
          let bestLocalVal = -Infinity;
          for (let q = 0; q < meter; q++) {
            if (selectedMeter.beatEvidence[i + q] > bestLocalVal) {
              bestLocalVal = selectedMeter.beatEvidence[i + q];
              bestLocalQ = q;
            }
          }
          currentPhaseOffset = (i + bestLocalQ) % meter;
        }
        isDownbeatFlags[i] = i % meter === currentPhaseOffset;
      }
    }

    // Strong beat threshold = 70th percentile of beat strengths
    const sortedStrengths = [...beatStrengths].sort((a, b) => a - b);
    const strongCutoff =
      sortedStrengths[Math.floor(sortedStrengths.length * 0.7)] ?? 0.5;

    const beats: BeatMarker[] = [];
    const downbeatTimestampsSec: number[] = [];
    const strongBeatTimestampsSec: number[] = [];

    for (let i = 0; i < rawTimestamps.length; i++) {
      const ts = rawTimestamps[i];
      const strength = Number((beatStrengths[i] ?? 0).toFixed(3));
      const isDownbeat = isDownbeatFlags[i];
      const isStrong = isDownbeat || strength >= strongCutoff;
      const intervalSec =
        i > 0 ? Number((ts - rawTimestamps[i - 1]).toFixed(3)) : Number(meanIbi.toFixed(3));

      if (isDownbeat) downbeatTimestampsSec.push(ts);
      if (isStrong) strongBeatTimestampsSec.push(ts);

      beats.push({
        timestampSec: ts,
        strength,
        isDownbeat,
        isStrong,
        intervalSec,
      });
    }

    // Energy transient peaks (top peaks at least 0.5s apart) with frame-center alignment
    const energyPeaksSec: number[] = [];
    for (let i = 1; i < odf.length - 1; i++) {
      if (odf[i] > 0.55 && odf[i] >= odf[i - 1] && odf[i] >= odf[i + 1]) {
        const ts = Number(
          (i * frameDurationSec + frameCenterOffsetSec + decoderOffsetSec).toFixed(3)
        );
        if (energyPeaksSec.length === 0 || ts - energyPeaksSec[energyPeaksSec.length - 1] >= 0.5) {
          energyPeaksSec.push(ts);
        }
      }
    }

    let rhythmPattern: BeatAnalysisResult['rhythmPattern'] = 'steady-4/4';
    if (
      combinedConfidence < 0.36 ||
      onsetHitRatio < 0.35 ||
      rhythmRegularity < 0.45 ||
      beats.length < 4
    ) {
      rhythmPattern = 'weak-or-irregular';
    } else if (tempoChanges.length > 0) {
      rhythmPattern = 'tempo-shifting';
    } else if (meter === 3 && shouldEmitDownbeats) {
      rhythmPattern = 'steady-3/4';
    } else if (onsetHitRatio < 0.65) {
      rhythmPattern = 'syncopated';
    }

    return {
      bpm: globalTempo.bpm,
      bpmConfidence: Number(combinedConfidence.toFixed(3)),
      rhythmPattern,
      rhythmRegularity: Number(rhythmRegularity.toFixed(3)),
      averageBeatIntervalSec: Number(meanIbi.toFixed(3)),
      beatTimestampsSec: rawTimestamps,
      downbeatTimestampsSec,
      strongBeatTimestampsSec,
      beats,
      downbeatConfidence,
      energyPeaksSec,
      tempoSegments,
      tempoChanges,
      events: detectEvents(features, tempoChanges),
    };
  }
}
