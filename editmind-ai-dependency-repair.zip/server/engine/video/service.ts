import crypto from 'node:crypto';
import fs from 'node:fs';
import { config } from '../../config.ts';
import { db } from '../../db.ts';
import {
  ensureUserSceneThumbsDir,
  resolveSafeStoragePath,
  safeRmDir,
} from '../../storage.ts';
import type { StructuredVideoAnalysis } from '../contracts.ts';
import { runVideoIntelligencePipeline } from './analyzer.ts';

export const VIDEO_ENGINE_VERSION = 'editmind-video-v1';

interface MediaAssetVideoRow {
  id: string;
  user_id: string;
  project_id: string;
  media_kind: string;
  original_name: string;
  stored_filename: string;
  duration_sec: number;
  sha256: string;
}

interface CachedVideoAnalysisRow {
  id: string;
  media_id: string;
  file_sha256: string;
  engine_version: string;
  analysis_json: string;
  processing_ms: number;
  created_at: string;
  updated_at: string;
}

export function createSceneThumbnailSignature(
  mediaId: string,
  sceneIndex: number,
  userId: string,
  expMs: number
): string {
  return crypto
    .createHmac('sha256', config.mediaSigningSecret)
    .update(`scene-thumb:${mediaId}:${sceneIndex}:${userId}:${expMs}`)
    .digest('hex');
}

export function attachSceneThumbnailGrants(
  analysis: StructuredVideoAnalysis,
  userId: string
): StructuredVideoAnalysis {
  const expMs = Date.now() + 15 * 60 * 1000;
  return {
    ...analysis,
    scenes: analysis.scenes.map((scene) => {
      if (!scene.thumbnailAvailable) {
        return { ...scene, thumbnailUrl: null };
      }
      const sig = createSceneThumbnailSignature(
        analysis.mediaId,
        scene.sceneIndex,
        userId,
        expMs
      );
      return {
        ...scene,
        thumbnailUrl: `/api/video-analysis/${encodeURIComponent(
          analysis.mediaId
        )}/scenes/${scene.sceneIndex}/thumbnail?uid=${encodeURIComponent(
          userId
        )}&exp=${expMs}&sig=${sig}`,
      };
    }),
  };
}

export function getCachedVideoAnalysis(
  mediaId: string,
  userId: string
): { status: 'ready' | 'not_analyzed'; cached: boolean; analysis: StructuredVideoAnalysis | null } {
  const asset = db
    .prepare(
      `SELECT id, user_id, project_id, media_kind, original_name, stored_filename, duration_sec, sha256
       FROM media_assets WHERE id = ? AND user_id = ?`
    )
    .get(mediaId, userId) as unknown as MediaAssetVideoRow | undefined;

  if (!asset || asset.media_kind !== 'video') {
    return { status: 'not_analyzed', cached: false, analysis: null };
  }

  const cachedRow = db
    .prepare(
      `SELECT * FROM video_analyses
       WHERE media_id = ? AND user_id = ? AND file_sha256 = ? AND engine_version = ?`
    )
    .get(mediaId, userId, asset.sha256, VIDEO_ENGINE_VERSION) as unknown as
    | CachedVideoAnalysisRow
    | undefined;

  if (!cachedRow) {
    return { status: 'not_analyzed', cached: false, analysis: null };
  }

  try {
    const parsed = JSON.parse(cachedRow.analysis_json) as StructuredVideoAnalysis;
    return {
      status: 'ready',
      cached: true,
      analysis: attachSceneThumbnailGrants(parsed, userId),
    };
  } catch {
    return { status: 'not_analyzed', cached: false, analysis: null };
  }
}

export async function analyzeVideoAsset(
  mediaId: string,
  userId: string,
  options: { force?: boolean } = {}
): Promise<{ cached: boolean; analysis: StructuredVideoAnalysis }> {
  const asset = db
    .prepare(
      `SELECT id, user_id, project_id, media_kind, original_name, stored_filename, duration_sec, sha256
       FROM media_assets WHERE id = ? AND user_id = ?`
    )
    .get(mediaId, userId) as unknown as MediaAssetVideoRow | undefined;

  if (!asset) {
    throw new Error('Video asset not found.');
  }
  if (asset.media_kind !== 'video') {
    throw new Error('Video intelligence analysis is only supported on video clips.');
  }

  if (!options.force) {
    const existing = getCachedVideoAnalysis(mediaId, userId);
    if (existing.status === 'ready' && existing.analysis) {
      return { cached: true, analysis: existing.analysis };
    }
  }

  const filePath = resolveSafeStoragePath('uploads', userId, asset.stored_filename);
  if (!fs.existsSync(filePath)) {
    throw new Error('Stored video file is missing on server.');
  }

  const sceneThumbsDir = ensureUserSceneThumbsDir(userId, asset.id);
  // Clear stale scene thumbnails before fresh extraction
  safeRmDir(sceneThumbsDir);
  fs.mkdirSync(sceneThumbsDir, { recursive: true });

  const startedAt = performance.now();
  const pipeline = await runVideoIntelligencePipeline(filePath, asset.id, sceneThumbsDir);
  const processingMs = Math.max(1, Math.round(performance.now() - startedAt));

  // Strip transient signed thumbnailUrl before persisting to DB
  const cleanScenes = pipeline.scenes.map(({ thumbnailUrl: _ignored, ...rest }) => rest);

  const analysis: StructuredVideoAnalysis = {
    version: VIDEO_ENGINE_VERSION,
    mediaId: asset.id,
    durationSec: pipeline.metadata.durationSec,
    processingMs,
    analyzedAt: new Date().toISOString(),
    sampleFpsUsed: pipeline.sampleFpsUsed,
    metadata: pipeline.metadata,
    sceneCount: cleanScenes.length,
    usableSceneCount: pipeline.usableSceneCount,
    usableDurationSec: pipeline.usableDurationSec,
    blackDurationSec: pipeline.blackDurationSec,
    frozenDurationSec: pipeline.frozenDurationSec,
    averageMotionIntensity: pipeline.averageMotionIntensity,
    averageQualityScore: pipeline.averageQualityScore,
    dominantCameraMovement: pipeline.dominantCameraMovement,
    scenes: cleanScenes,
    blackIntervals: pipeline.blackIntervals,
    frozenIntervals: pipeline.frozenIntervals,
    significantMoments: pipeline.significantMoments,
    timelineCurve: pipeline.timelineCurve,
    capabilities: pipeline.capabilities,
    notes: pipeline.notes,
  };

  const nowIso = new Date().toISOString();
  const serialized = JSON.stringify(analysis);

  db.prepare(
    `INSERT INTO video_analyses (
       id, media_id, user_id, project_id, file_sha256, engine_version,
       analysis_json, processing_ms, created_at, updated_at
     ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(media_id) DO UPDATE SET
       file_sha256 = excluded.file_sha256,
       engine_version = excluded.engine_version,
       analysis_json = excluded.analysis_json,
       processing_ms = excluded.processing_ms,
       updated_at = excluded.updated_at`
  ).run(
    crypto.randomUUID(),
    asset.id,
    userId,
    asset.project_id,
    asset.sha256,
    VIDEO_ENGINE_VERSION,
    serialized,
    processingMs,
    nowIso,
    nowIso
  );

  return {
    cached: false,
    analysis: attachSceneThumbnailGrants(analysis, userId),
  };
}

export function deleteCachedVideoAnalysisArtifacts(mediaId: string, userId: string): void {
  const sceneThumbsDir = resolveSafeStoragePath('uploads', userId, 'thumbs', 'scenes', mediaId);
  safeRmDir(sceneThumbsDir);
  db.prepare(`DELETE FROM video_analyses WHERE media_id = ? AND user_id = ?`).run(mediaId, userId);
}

/**
 * Clean interface for Milestone 5 EditingIntelligenceModule to consume structured video timeline data.
 */
export async function getStructuredVideoAnalysisForEngine(
  mediaId: string,
  userId: string
): Promise<StructuredVideoAnalysis> {
  const result = await analyzeVideoAsset(mediaId, userId, { force: false });
  return result.analysis;
}
