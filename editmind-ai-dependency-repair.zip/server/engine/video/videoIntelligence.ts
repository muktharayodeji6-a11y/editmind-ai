import type {
  EngineModuleDescriptor,
  VideoIntelligenceModule,
  VideoSceneSegment,
} from '../contracts.ts';
import { runVideoIntelligencePipeline } from './analyzer.ts';

export class EditmindVideoIntelligence implements VideoIntelligenceModule {
  readonly descriptor: EngineModuleDescriptor = {
    id: 'video-intelligence',
    name: 'Video Intelligence',
    milestoneTarget: 4,
    status: 'active',
    provider:
      'Self-hosted FFprobe + FFmpeg (scdet, blackdetect, freezedetect) + Node Optical-Flow & Saliency CV',
    summary:
      'Extracts shot boundaries, camera movement, motion intensity, black/frozen unusable footage, representative scene thumbnails, and visual saliency signals.',
    outputs: [
      'Stream metadata & orientation',
      'Shot boundaries & thumbnails',
      'Camera motion & optical-flow intensity',
      'Black/frozen usability flags & visual saliency',
    ],
    externalDependencyPolicy: 'Self-hosted FFmpeg/FFprobe & pixel-stream CV; zero mandatory commercial APIs.',
  };

  async analyzeScenes(videoFilePath: string, assetId: string): Promise<VideoSceneSegment[]> {
    const output = await runVideoIntelligencePipeline(videoFilePath, assetId);
    return output.scenes;
  }
}
