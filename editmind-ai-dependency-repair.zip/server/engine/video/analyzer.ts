import { execFile, spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';
import type {
  CameraMovementType,
  SceneTransitionBoundary,
  SceneUsabilityIssue,
  SceneVisualDetections,
  VideoDetectionCapabilities,
  VideoSceneSegment,
  VideoSignificantMoment,
  VideoStreamMetadata,
  VideoTimelineSamplePoint,
} from '../contracts.ts';
import { probeVideoMetadata } from './probe.ts';

const execFileAsync = promisify(execFile);

export interface IntervalWindow {
  startSec: number;
  endSec: number;
  durationSec: number;
}

interface RawScdEvent {
  timeSec: number;
  score: number;
}

interface FrameSample {
  index: number;
  timeSec: number;
  brightness: number;
  contrast: number;
  sharpness: number;
  colorfulness: number;
  isBlackFrame: boolean;
  histogram: Float32Array;
  gridLuma: Float32Array;
  histDistPrev: number;
  gridDiffPrev: number;
  motionIntensity: number;
  camDxNorm: number;
  camDyNorm: number;
  zoomDivergence: number;
  foregroundMotion: number;
  personLikelihood: number;
  foregroundObjectLikelihood: number;
  salientRegionCount: number;
  salientFocusX: number;
  salientFocusY: number;
  interestScore: number;
}

export interface VideoPipelineAnalysisOutput {
  metadata: VideoStreamMetadata;
  sampleFpsUsed: number;
  scenes: VideoSceneSegment[];
  blackIntervals: IntervalWindow[];
  frozenIntervals: IntervalWindow[];
  significantMoments: VideoSignificantMoment[];
  timelineCurve: VideoTimelineSamplePoint[];
  usableSceneCount: number;
  usableDurationSec: number;
  blackDurationSec: number;
  frozenDurationSec: number;
  averageMotionIntensity: number;
  averageQualityScore: number;
  dominantCameraMovement: CameraMovementType;
  capabilities: VideoDetectionCapabilities;
  notes: string[];
}

function clamp01(v: number): number {
  if (!Number.isFinite(v)) return 0;
  return Math.max(0, Math.min(1, v));
}

function round3(v: number): number {
  return Math.round(v * 1000) / 1000;
}

function chooseSampleFps(durationSec: number): number {
  if (durationSec <= 90) return 4;
  if (durationSec <= 240) return 3;
  if (durationSec <= 600) return 2;
  return 1.5;
}

function computeEvenSampleDimensions(width: number, height: number): { sw: number; sh: number } {
  const maxDim = 160;
  const scale = maxDim / Math.max(width, height, 1);
  let sw = Math.max(48, Math.round((width * scale) / 2) * 2);
  let sh = Math.max(48, Math.round((height * scale) / 2) * 2);
  if (sw % 2 !== 0) sw += 1;
  if (sh % 2 !== 0) sh += 1;
  return { sw, sh };
}

function parseFfmpegDiagnostics(
  stderrText: string,
  durationSec: number
): {
  blackIntervals: IntervalWindow[];
  frozenIntervals: IntervalWindow[];
  scdEvents: RawScdEvent[];
} {
  const blackIntervals: IntervalWindow[] = [];
  const frozenIntervals: IntervalWindow[] = [];
  const scdEvents: RawScdEvent[] = [];

  const blackRegex = /black_start:([\d.]+)\s+black_end:([\d.]+)\s+black_duration:([\d.]+)/g;
  let bMatch: RegExpExecArray | null;
  while ((bMatch = blackRegex.exec(stderrText)) !== null) {
    const startSec = Number(bMatch[1]);
    const endSec = Number(bMatch[2]);
    const dur = Number(bMatch[3]);
    if (Number.isFinite(startSec) && Number.isFinite(endSec) && dur > 0) {
      blackIntervals.push({
        startSec: round3(startSec),
        endSec: round3(Math.min(durationSec, endSec)),
        durationSec: round3(dur),
      });
    }
  }

  // Parse freezedetect lines sequentially because end can be omitted at EOF
  const lines = stderrText.split(/\r?\n/);
  let openFreezeStart: number | null = null;
  for (const line of lines) {
    const startMatch = /lavfi\.freezedetect\.freeze_start:\s*([\d.]+)/.exec(line);
    if (startMatch) {
      openFreezeStart = Number(startMatch[1]);
      continue;
    }
    const endMatch = /lavfi\.freezedetect\.freeze_end:\s*([\d.]+)/.exec(line);
    if (endMatch && openFreezeStart !== null) {
      const endSec = Math.min(durationSec, Number(endMatch[1]));
      const dur = Math.max(0, endSec - openFreezeStart);
      if (dur >= 0.3) {
        frozenIntervals.push({
          startSec: round3(openFreezeStart),
          endSec: round3(endSec),
          durationSec: round3(dur),
        });
      }
      openFreezeStart = null;
      continue;
    }
    const scdMatch = /lavfi\.scd\.score:\s*([\d.]+),\s*lavfi\.scd\.time:\s*([\d.]+)/.exec(line);
    if (scdMatch) {
      const score = Number(scdMatch[1]);
      const timeSec = Number(scdMatch[2]);
      if (Number.isFinite(score) && Number.isFinite(timeSec) && timeSec > 0.1) {
        scdEvents.push({ timeSec: round3(timeSec), score: round3(score) });
      }
    }
  }

  if (openFreezeStart !== null && durationSec - openFreezeStart >= 0.3) {
    frozenIntervals.push({
      startSec: round3(openFreezeStart),
      endSec: round3(durationSec),
      durationSec: round3(durationSec - openFreezeStart),
    });
  }

  return { blackIntervals, frozenIntervals, scdEvents };
}

function analyzeFramePixels(
  rgb: Uint8Array,
  prevLuma: Uint8Array | null,
  prevHist: Float32Array | null,
  prevGrid: Float32Array | null,
  sw: number,
  sh: number,
  frameIndex: number,
  sampleFps: number
): { sample: FrameSample; luma: Uint8Array } {
  const pixelCount = sw * sh;
  const luma = new Uint8Array(pixelCount);
  const hist = new Float32Array(64); // 4x4x4 RGB bins
  const gridLuma = new Float32Array(16); // 4x4 tiles
  const gridCount = new Int32Array(16);

  // Saliency 8x5 spatial grid
  const salCols = 8;
  const salRows = 5;
  const salCells = salCols * salRows;
  const cellEdge = new Float32Array(salCells);
  const cellSkin = new Float32Array(salCells);
  const cellDiff = new Float32Array(salCells);
  const cellPixels = new Int32Array(salCells);
  const cellColorSumR = new Float32Array(salCells);
  const cellColorSumG = new Float32Array(salCells);
  const cellColorSumB = new Float32Array(salCells);

  let sumY = 0;
  let sumY2 = 0;
  let sumChromaSat = 0;
  let borderR = 0;
  let borderG = 0;
  let borderB = 0;
  let borderCount = 0;

  let skinCandidates = 0;

  for (let y = 0; y < sh; y++) {
    const gy = Math.min(3, Math.floor((y * 4) / sh));
    const sy = Math.min(salRows - 1, Math.floor((y * salRows) / sh));
    const isBorderRow = y < Math.max(2, Math.floor(sh * 0.12)) || y >= sh - Math.max(2, Math.floor(sh * 0.12));

    for (let x = 0; x < sw; x++) {
      const idx = y * sw + x;
      const off = idx * 3;
      const r = rgb[off];
      const g = rgb[off + 1];
      const b = rgb[off + 2];

      const yVal = 0.299 * r + 0.587 * g + 0.114 * b;
      luma[idx] = yVal;
      sumY += yVal;
      sumY2 += yVal * yVal;

      const maxRgb = r > g ? (r > b ? r : b) : g > b ? g : b;
      const minRgb = r < g ? (r < b ? r : b) : g < b ? g : b;
      const sat = maxRgb > 0 ? (maxRgb - minRgb) / maxRgb : 0;
      sumChromaSat += sat;

      const bin = ((r >> 6) << 4) | ((g >> 6) << 2) | (b >> 6);
      hist[bin] += 1;

      const gx = Math.min(3, Math.floor((x * 4) / sw));
      const gIdx = gy * 4 + gx;
      gridLuma[gIdx] += yVal / 255;
      gridCount[gIdx] += 1;

      const sx = Math.min(salCols - 1, Math.floor((x * salCols) / sw));
      const sIdx = sy * salCols + sx;
      cellPixels[sIdx] += 1;
      cellColorSumR[sIdx] += r;
      cellColorSumG[sIdx] += g;
      cellColorSumB[sIdx] += b;

      if (isBorderRow || x < Math.max(2, Math.floor(sw * 0.1)) || x >= sw - Math.max(2, Math.floor(sw * 0.1))) {
        borderR += r;
        borderG += g;
        borderB += b;
        borderCount += 1;
      }

      // YCbCr skin-tone chrominance cluster heuristic (restrictive bounds to limit false wall hits)
      const cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b;
      const cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;
      if (yVal > 42 && yVal < 245 && cb >= 80 && cb <= 126 && cr >= 134 && cr <= 172 && r > g && r > b) {
        skinCandidates += 1;
        cellSkin[sIdx] += 1;
      }

      if (prevLuma) {
        cellDiff[sIdx] += Math.abs(yVal - prevLuma[idx]) / 255;
      }
    }
  }

  for (let i = 0; i < 64; i++) hist[i] /= pixelCount;
  for (let i = 0; i < 16; i++) {
    gridLuma[i] = gridCount[i] > 0 ? gridLuma[i] / gridCount[i] : 0;
  }

  const meanY = sumY / pixelCount;
  const varianceY = Math.max(0, sumY2 / pixelCount - meanY * meanY);
  const brightness = clamp01(meanY / 255);
  const contrast = clamp01((Math.sqrt(varianceY) * 2.4) / 255);
  const colorfulness = clamp01((sumChromaSat / pixelCount) * 1.45);
  const isBlackFrame = brightness < 0.055 && contrast < 0.045;

  // Discrete Laplacian sharpness + spatial edge energy per saliency cell
  let lapSum = 0;
  let edgeCount = 0;
  for (let y = 1; y < sh - 1; y++) {
    const sy = Math.min(salRows - 1, Math.floor((y * salRows) / sh));
    for (let x = 1; x < sw - 1; x++) {
      const idx = y * sw + x;
      const lap = Math.abs(
        4 * luma[idx] - luma[idx - 1] - luma[idx + 1] - luma[idx - sw] - luma[idx + sw]
      );
      lapSum += lap;
      edgeCount += 1;
      const sx = Math.min(salCols - 1, Math.floor((x * salCols) / sw));
      cellEdge[sy * salCols + sx] += lap / 255;
    }
  }
  const sharpness = clamp01(lapSum / Math.max(1, edgeCount) / 28);

  // Histogram L1 distance & grid delta against previous frame
  let histDistPrev = 0;
  let gridDiffPrev = 0;
  if (prevHist && prevGrid) {
    for (let i = 0; i < 64; i++) {
      histDistPrev += Math.abs(hist[i] - prevHist[i]);
    }
    histDistPrev *= 0.5; // [0..1]
    for (let i = 0; i < 16; i++) {
      gridDiffPrev += Math.abs(gridLuma[i] - prevGrid[i]);
    }
    gridDiffPrev /= 16;
  }

  // Block-matching camera optical flow & foreground motion
  let motionIntensity = 0;
  let camDxNorm = 0;
  let camDyNorm = 0;
  let zoomDivergence = 0;
  let foregroundMotion = 0;

  if (prevLuma && !isBlackFrame) {
    // 5x3 grid of 12x12 blocks covering inner frame with ±8px search radius
    const cols = 5;
    const rows = 3;
    const blockSize = Math.max(8, Math.min(14, Math.floor(Math.min(sw, sh) * 0.14)));
    const searchRad = Math.max(5, Math.min(10, Math.floor(Math.min(sw, sh) * 0.1)));

    const dxs: number[] = [];
    const dys: number[] = [];
    const blockCoords: Array<{ rx: number; ry: number; dx: number; dy: number }> = [];
    let meanBlockSad = 0;
    let validBlocks = 0;

    for (let rIdx = 0; rIdx < rows; rIdx++) {
      const cy = Math.round(((rIdx + 0.5) / rows) * (sh - 2 * searchRad - blockSize) + searchRad);
      for (let cIdx = 0; cIdx < cols; cIdx++) {
        const cx = Math.round(((cIdx + 0.5) / cols) * (sw - 2 * searchRad - blockSize) + searchRad);

        // Compute block texture variance to skip flat textureless sky/wall blocks
        let bSum = 0;
        let bSum2 = 0;
        const nB = blockSize * blockSize;
        for (let by = 0; by < blockSize; by++) {
          const rowOff = (cy + by) * sw + cx;
          for (let bx = 0; bx < blockSize; bx++) {
            const v = luma[rowOff + bx];
            bSum += v;
            bSum2 += v * v;
          }
        }
        const bVar = bSum2 / nB - (bSum / nB) * (bSum / nB);
        if (bVar < 28) continue; // Low-texture block unreliable for optical flow

        let bestSad = Infinity;
        let zeroSad = 0;
        let bestDx = 0;
        let bestDy = 0;

        for (let dy = -searchRad; dy <= searchRad; dy++) {
          for (let dx = -searchRad; dx <= searchRad; dx++) {
            let sad = 0;
            for (let by = 0; by < blockSize; by += 2) {
              const curRow = (cy + by) * sw + cx;
              const prevRow = (cy + by - dy) * sw + (cx - dx);
              for (let bx = 0; bx < blockSize; bx += 2) {
                sad += Math.abs(luma[curRow + bx] - prevLuma[prevRow + bx]);
              }
            }
            if (dx === 0 && dy === 0) zeroSad = sad;
            // Slight bias toward zero displacement on ties
            const score = sad + (dx === 0 && dy === 0 ? 0 : Math.abs(dx) + Math.abs(dy)) * 0.35;
            if (score < bestSad) {
              bestSad = score;
              bestDx = dx;
              bestDy = dy;
            }
          }
        }

        // Only trust displacement if it genuinely beats zero displacement or is static
        if (bestDx !== 0 || bestDy !== 0) {
          if (bestSad > zeroSad * 0.94) {
            bestDx = 0;
            bestDy = 0;
          }
        }

        dxs.push(bestDx);
        dys.push(bestDy);
        const rx = (cx + blockSize / 2 - sw / 2) / (sw / 2);
        const ry = (cy + blockSize / 2 - sh / 2) / (sh / 2);
        blockCoords.push({ rx, ry, dx: bestDx, dy: bestDy });
        meanBlockSad += zeroSad / ((blockSize / 2) * (blockSize / 2));
        validBlocks += 1;
      }
    }

    // Also compute global temporal pixel diff even on simple/low-texture scenes
    let frameDiffSum = 0;
    for (let i = 0; i < pixelCount; i++) {
      frameDiffSum += Math.abs(luma[i] - prevLuma[i]);
    }
    const meanPixelDiff = frameDiffSum / pixelCount / 255;

    if (validBlocks >= 3) {
      const sortedDx = [...dxs].sort((a, b) => a - b);
      const sortedDy = [...dys].sort((a, b) => a - b);
      const medDx = sortedDx[Math.floor(sortedDx.length / 2)];
      const medDy = sortedDy[Math.floor(sortedDy.length / 2)];

      // Normalized camera velocity in frame-widths/sec (compensating for sampleFps)
      camDxNorm = (medDx / sw) * sampleFps;
      camDyNorm = (medDy / sh) * sampleFps;

      // Radial zoom divergence after subtracting pan/tilt translation
      let radialSum = 0;
      let radialWeight = 0;
      let residualMagSum = 0;

      for (const b of blockCoords) {
        const resDx = b.dx - medDx;
        const resDy = b.dy - medDy;
        residualMagSum += Math.hypot(resDx, resDy);

        const r2 = b.rx * b.rx + b.ry * b.ry;
        if (r2 > 0.08) {
          // Project residual vector onto radial vector from frame center
          radialSum += (b.dx * b.rx + b.dy * b.ry) / Math.sqrt(r2);
          radialWeight += 1;
        }
      }

      const avgRadialPx = radialWeight > 0 ? radialSum / radialWeight : 0;
      zoomDivergence = (avgRadialPx / Math.max(sw, sh)) * sampleFps * 4;

      const avgResidualNorm = (residualMagSum / validBlocks / Math.max(sw, sh)) * sampleFps;
      foregroundMotion = clamp01(avgResidualNorm * 2.8);

      const flowSpeedNorm = Math.hypot(camDxNorm, camDyNorm);
      const combinedMotion = Math.max(
        flowSpeedNorm * 2.1,
        Math.abs(zoomDivergence) * 0.9,
        foregroundMotion * 0.95,
        meanPixelDiff * 4.5
      );
      motionIntensity = clamp01(combinedMotion);
    } else {
      motionIntensity = clamp01(meanPixelDiff * 5.2);
      foregroundMotion = motionIntensity;
    }
  }

  // Salient foreground regions & visual subject estimation
  const avgBorderR = borderCount > 0 ? borderR / borderCount : 128;
  const avgBorderG = borderCount > 0 ? borderG / borderCount : 128;
  const avgBorderB = borderCount > 0 ? borderB / borderCount : 128;

  const cellSalience = new Float32Array(salCells);
  let maxSal = 0;
  for (let i = 0; i < salCells; i++) {
    const px = Math.max(1, cellPixels[i]);
    const cR = cellColorSumR[i] / px;
    const cG = cellColorSumG[i] / px;
    const cB = cellColorSumB[i] / px;
    const colorDist =
      (Math.abs(cR - avgBorderR) + Math.abs(cG - avgBorderG) + Math.abs(cB - avgBorderB)) /
      (3 * 255);
    const edgeScore = cellEdge[i] / px;
    const diffScore = cellDiff[i] / px;
    const sy = Math.floor(i / salCols);
    const sx = i % salCols;
    const centerBias =
      1 - 0.35 * Math.hypot((sx + 0.5) / salCols - 0.5, (sy + 0.5) / salRows - 0.5);

    const sal = (edgeScore * 2.2 + colorDist * 1.4 + diffScore * 1.8) * centerBias;
    cellSalience[i] = sal;
    if (sal > maxSal) maxSal = sal;
  }

  let salientRegionCount = 0;
  let salWeightSum = 0;
  let salCentroidX = 0;
  let salCentroidY = 0;
  let totalEdgeRatio = 0;

  const salThresh = Math.max(0.14, maxSal * 0.52);
  for (let i = 0; i < salCells; i++) {
    const val = cellSalience[i];
    if (val >= salThresh && !isBlackFrame) {
      salientRegionCount += 1;
      const sx = (i % salCols + 0.5) / salCols;
      const sy = (Math.floor(i / salCols) + 0.5) / salRows;
      salCentroidX += sx * val;
      salCentroidY += sy * val;
      salWeightSum += val;
    }
    totalEdgeRatio += cellEdge[i] / Math.max(1, cellPixels[i]);
  }

  const skinRatio = skinCandidates / pixelCount;
  // Require both plausible skin proportion (1.5%..52%) and structural edge detail so flat warm walls aren't flagged as people
  let personScore = 0;
  if (!isBlackFrame && skinRatio >= 0.015 && skinRatio <= 0.55 && contrast >= 0.06) {
    // Check spatial compactness of skin cells
    let skinCellsWithContent = 0;
    let centerSkinWeight = 0;
    for (let i = 0; i < salCells; i++) {
      const cellSkinRatio = cellSkin[i] / Math.max(1, cellPixels[i]);
      if (cellSkinRatio > 0.08) {
        skinCellsWithContent += 1;
        const sx = (i % salCols + 0.5) / salCols;
        const sy = (Math.floor(i / salCols) + 0.5) / salRows;
        // Heads/subjects usually occupy middle/upper-middle columns
        if (sx >= 0.15 && sx <= 0.85 && sy <= 0.85) {
          centerSkinWeight += cellSkinRatio;
        }
      }
    }
    const spatialFocus = clamp01(1 - Math.abs(skinCellsWithContent - 6) / 18);
    const textureSupport = clamp01(0.42 + sharpness * 0.9 + contrast * 0.55);
    personScore = clamp01(
      (Math.min(1, skinRatio * 7.5) * 0.45 + Math.min(1, centerSkinWeight * 0.6) * 0.35 + spatialFocus * 0.2) *
        textureSupport
    );
  }

  const foregroundObjectLikelihood = isBlackFrame
    ? 0
    : clamp01(
        (salWeightSum / Math.max(1, salCells * 0.25)) * 0.65 +
          clamp01(foregroundMotion * 1.4) * 0.35 +
          clamp01(totalEdgeRatio / salCells * 2.5) * 0.25
      );

  const salientFocusX = salWeightSum > 0 ? round3(salCentroidX / salWeightSum) : 0.5;
  const salientFocusY = salWeightSum > 0 ? round3(salCentroidY / salWeightSum) : 0.5;

  const qualityFactor = isBlackFrame
    ? 0
    : clamp01(sharpness * 0.45 + contrast * 0.35 + (1 - Math.abs(brightness - 0.5) * 1.4) * 0.2);

  const interestScore = isBlackFrame
    ? 0
    : clamp01(
        qualityFactor * 0.36 +
          clamp01(motionIntensity * 0.85) * 0.24 +
          foregroundObjectLikelihood * 0.22 +
          colorfulness * 0.18
      );

  return {
    luma,
    sample: {
      index: frameIndex,
      timeSec: round3(frameIndex / sampleFps),
      brightness: round3(brightness),
      contrast: round3(contrast),
      sharpness: round3(sharpness),
      colorfulness: round3(colorfulness),
      isBlackFrame,
      histogram: hist,
      gridLuma,
      histDistPrev: round3(histDistPrev),
      gridDiffPrev: round3(gridDiffPrev),
      motionIntensity: round3(motionIntensity),
      camDxNorm: round3(camDxNorm),
      camDyNorm: round3(camDyNorm),
      zoomDivergence: round3(zoomDivergence),
      foregroundMotion: round3(foregroundMotion),
      personLikelihood: round3(personScore),
      foregroundObjectLikelihood: round3(foregroundObjectLikelihood),
      salientRegionCount,
      salientFocusX,
      salientFocusY,
      interestScore: round3(interestScore),
    },
  };
}

function classifySceneCameraMovement(
  frames: FrameSample[],
  isFrozen: boolean,
  isBlack: boolean
): {
  movement: CameraMovementType;
  confidence: number;
  panSpeed: number;
  zoomRate: number;
} {
  if (isBlack || isFrozen || frames.length < 2) {
    return {
      movement: 'static',
      confidence: isBlack || isFrozen ? 0.92 : 0.65,
      panSpeed: 0,
      zoomRate: 0,
    };
  }

  // Skip index 0 of global video where prevLuma doesn't exist
  const motionFrames = frames.filter((f) => f.index > 0);
  if (motionFrames.length === 0) {
    return { movement: 'static', confidence: 0.6, panSpeed: 0, zoomRate: 0 };
  }

  let sumDx = 0;
  let sumDy = 0;
  let sumZoom = 0;
  let sumAbsFlow = 0;
  let sumMotion = 0;
  let sumForeground = 0;

  for (const f of motionFrames) {
    sumDx += f.camDxNorm;
    sumDy += f.camDyNorm;
    sumZoom += f.zoomDivergence;
    sumAbsFlow += Math.hypot(f.camDxNorm, f.camDyNorm);
    sumMotion += f.motionIntensity;
    sumForeground += f.foregroundMotion;
  }

  const n = motionFrames.length;
  const meanDx = sumDx / n;
  const meanDy = sumDy / n;
  const meanZoom = sumZoom / n;
  const meanAbsFlow = sumAbsFlow / n;
  const meanMotion = sumMotion / n;
  const meanForeground = sumForeground / n;

  const netFlow = Math.hypot(meanDx, meanDy);
  // Directional consistency: ratio of net displacement to total path length (low = jitter/handheld!)
  const consistency = meanAbsFlow > 0.01 ? clamp01(netFlow / meanAbsFlow) : 1;

  // Check sign reversal frequency for handheld shake
  let dxSignChanges = 0;
  for (let i = 1; i < motionFrames.length; i++) {
    if (motionFrames[i].camDxNorm * motionFrames[i - 1].camDxNorm < -0.001) {
      dxSignChanges += 1;
    }
  }
  const shakeRatio = motionFrames.length > 2 ? dxSignChanges / (motionFrames.length - 1) : 0;

  if (meanMotion < 0.065 && netFlow < 0.025 && Math.abs(meanZoom) < 0.08) {
    return {
      movement: 'static',
      confidence: round3(clamp01(0.7 + (0.065 - meanMotion) * 3)),
      panSpeed: 0,
      zoomRate: 0,
    };
  }

  // Zoom divergence when radial expansion/contraction outweighs net pan/tilt
  if (Math.abs(meanZoom) >= 0.075 && Math.abs(meanZoom) > netFlow * 1.3) {
    const sign = Math.sign(meanZoom);
    const zoomConsistent =
      motionFrames.filter((f) => Math.sign(f.zoomDivergence) === sign && Math.abs(f.zoomDivergence) > 0.02).length /
      n;
    const zoomOpposing =
      motionFrames.filter((f) => f.zoomDivergence * sign < -0.025).length / n;
    if (zoomConsistent >= 0.3 && zoomOpposing <= 0.2) {
      return {
        movement: meanZoom > 0 ? 'zoom-in' : 'zoom-out',
        confidence: round3(clamp01(0.55 + zoomConsistent * 0.35 - zoomOpposing * 0.4)),
        panSpeed: round3(netFlow),
        zoomRate: round3(meanZoom),
      };
    }
  }

  // Coherent pan or tilt
  if (netFlow >= 0.032 && consistency >= 0.58) {
    const absDx = Math.abs(meanDx);
    const absDy = Math.abs(meanDy);
    if (absDx >= absDy * 1.2) {
      // Scenery moves left (dx < 0) => camera panning right
      return {
        movement: meanDx < 0 ? 'pan-right' : 'pan-left',
        confidence: round3(clamp01(0.55 + consistency * 0.35)),
        panSpeed: round3(netFlow),
        zoomRate: round3(meanZoom),
      };
    }
    if (absDy >= absDx * 1.2) {
      // Scenery moves down (dy > 0) => camera tilting up
      return {
        movement: meanDy > 0 ? 'tilt-up' : 'tilt-down',
        confidence: round3(clamp01(0.55 + consistency * 0.35)),
        panSpeed: round3(netFlow),
        zoomRate: round3(meanZoom),
      };
    }
    return {
      movement: 'mixed',
      confidence: round3(clamp01(0.5 + consistency * 0.3)),
      panSpeed: round3(netFlow),
      zoomRate: round3(meanZoom),
    };
  }

  // High motion with low directional consistency or high foreground/handheld variance
  if (meanMotion >= 0.16 && (consistency < 0.55 || shakeRatio >= 0.35 || meanForeground >= 0.2)) {
    return {
      movement: 'handheld-dynamic',
      confidence: round3(clamp01(0.55 + (1 - consistency) * 0.3)),
      panSpeed: round3(meanAbsFlow),
      zoomRate: round3(meanZoom),
    };
  }

  if (meanMotion >= 0.08) {
    return {
      movement: 'mixed',
      confidence: 0.58,
      panSpeed: round3(meanAbsFlow),
      zoomRate: round3(meanZoom),
    };
  }

  return {
    movement: 'static',
    confidence: 0.65,
    panSpeed: round3(netFlow),
    zoomRate: round3(meanZoom),
  };
}

function intervalOverlapSec(aStart: number, aEnd: number, intervals: IntervalWindow[]): number {
  let overlap = 0;
  for (const iv of intervals) {
    const start = Math.max(aStart, iv.startSec);
    const end = Math.min(aEnd, iv.endSec);
    if (end > start) overlap += end - start;
  }
  return overlap;
}

function buildSceneBoundaries(
  durationSec: number,
  sampleFps: number,
  frames: FrameSample[],
  blackIntervals: IntervalWindow[],
  scdEvents: RawScdEvent[]
): Array<{ startSec: number; endSec: number; boundaryType: SceneTransitionBoundary; confidence: number }> {
  interface CandidateCut {
    timeSec: number;
    type: SceneTransitionBoundary;
    confidence: number;
  }

  const candidates: CandidateCut[] = [];

  // 1. Explicit black gap start/end boundaries
  for (const b of blackIntervals) {
    if (b.startSec > 0.25 && b.startSec < durationSec - 0.25) {
      candidates.push({ timeSec: b.startSec, type: 'black-gap', confidence: 0.96 });
    }
    if (b.endSec > 0.25 && b.endSec < durationSec - 0.25) {
      candidates.push({ timeSec: b.endSec, type: 'black-gap', confidence: 0.96 });
    }
  }

  // 2. Native-FPS FFmpeg scdet luma cuts
  for (const sc of scdEvents) {
    if (sc.timeSec > 0.25 && sc.timeSec < durationSec - 0.25) {
      candidates.push({
        timeSec: sc.timeSec,
        type: 'hard-cut',
        confidence: round3(clamp01(0.65 + (sc.score - 8) / 30)),
      });
    }
  }

  // 3. Color histogram + grid-luma cuts (catches iso-luminant color transitions missed by luma-only scdet)
  for (let i = 1; i < frames.length; i++) {
    const f = frames[i];
    const prev = frames[i - 1];
    if (f.timeSec <= 0.25 || f.timeSec >= durationSec - 0.25) continue;
    if (f.isBlackFrame && prev.isBlackFrame) continue;

    // Strong color-histogram divergence
    if (f.histDistPrev >= 0.38 || (f.histDistPrev >= 0.28 && f.gridDiffPrev >= 0.16)) {
      candidates.push({
        timeSec: f.timeSec,
        type: 'hard-cut',
        confidence: round3(clamp01(0.6 + f.histDistPrev * 0.5)),
      });
    } else if (i >= 3) {
      // Gradual transition / dissolve check across a ~0.75s window
      const lookback = Math.max(0, i - Math.max(2, Math.round(sampleFps * 0.75)));
      const base = frames[lookback];
      if (!f.isBlackFrame && !base.isBlackFrame) {
        let winHistDist = 0;
        for (let b = 0; b < 64; b++) {
          winHistDist += Math.abs(f.histogram[b] - base.histogram[b]);
        }
        winHistDist *= 0.5;
        if (winHistDist >= 0.48 && f.histDistPrev < 0.38) {
          candidates.push({
            timeSec: round3((f.timeSec + base.timeSec) / 2),
            type: 'gradual-transition',
            confidence: round3(clamp01(0.45 + winHistDist * 0.45)),
          });
        }
      }
    }
  }

  // Sort by time and merge nearby duplicates within 0.45s (keeping higher-priority black/hard-cut)
  candidates.sort((a, b) => a.timeSec - b.timeSec);
  const merged: CandidateCut[] = [];
  for (const c of candidates) {
    const last = merged[merged.length - 1];
    if (last && Math.abs(c.timeSec - last.timeSec) < 0.45) {
      // Prefer black-gap > hard-cut > gradual-transition
      const rank = (t: SceneTransitionBoundary) =>
        t === 'black-gap' ? 3 : t === 'hard-cut' ? 2 : 1;
      if (rank(c.type) > rank(last.type) || (rank(c.type) === rank(last.type) && c.confidence > last.confidence)) {
        merged[merged.length - 1] = c;
      }
    } else {
      merged.push(c);
    }
  }

  // Remove cuts too close to start or end unless it's a black-gap edge
  const filtered = merged.filter((c) => {
    if (c.type === 'black-gap') return c.timeSec >= 0.08 && c.timeSec <= durationSec - 0.08;
    return c.timeSec >= 0.35 && c.timeSec <= durationSec - 0.35;
  });

  const boundaries: Array<{
    startSec: number;
    endSec: number;
    boundaryType: SceneTransitionBoundary;
    confidence: number;
  }> = [];

  let cursor = 0;
  let prevType: SceneTransitionBoundary = 'start-of-clip';
  let prevConf = 1;

  for (const cut of filtered) {
    if (cut.timeSec - cursor >= 0.1) {
      boundaries.push({
        startSec: round3(cursor),
        endSec: round3(cut.timeSec),
        boundaryType: prevType,
        confidence: prevConf,
      });
      cursor = cut.timeSec;
      prevType = cut.type;
      prevConf = cut.confidence;
    }
  }

  if (durationSec - cursor >= 0.05 || boundaries.length === 0) {
    boundaries.push({
      startSec: round3(cursor),
      endSec: round3(durationSec),
      boundaryType: prevType,
      confidence: prevConf,
    });
  } else if (boundaries.length > 0) {
    boundaries[boundaries.length - 1].endSec = round3(durationSec);
  }

  return boundaries;
}

async function generateSceneThumbnails(
  videoPath: string,
  sceneThumbsDir: string,
  scenes: VideoSceneSegment[]
): Promise<void> {
  const concurrency = 4;
  let nextIdx = 0;

  async function worker() {
    while (nextIdx < scenes.length) {
      const idx = nextIdx;
      nextIdx += 1;
      const scene = scenes[idx];
      const outPath = path.join(sceneThumbsDir, `scene_${scene.sceneIndex}.jpg`);
      const seekSec = Math.max(0, scene.representativeTimestampSec).toFixed(3);
      try {
        await execFileAsync(
          'ffmpeg',
          [
            '-y',
            '-ss',
            seekSec,
            '-i',
            videoPath,
            '-vframes',
            '1',
            '-vf',
            'scale=320:-2',
            '-q:v',
            '5',
            outPath,
          ],
          { timeout: 15000 }
        );
        scene.thumbnailAvailable = fs.existsSync(outPath) && fs.statSync(outPath).size > 0;
      } catch {
        scene.thumbnailAvailable = false;
      }
    }
  }

  await Promise.all(Array.from({ length: Math.min(concurrency, Math.max(1, scenes.length)) }, () => worker()));
}

export async function runVideoIntelligencePipeline(
  videoPath: string,
  assetId: string,
  sceneThumbsDir?: string
): Promise<VideoPipelineAnalysisOutput> {
  const metadata = await probeVideoMetadata(videoPath);
  const sampleFps = chooseSampleFps(metadata.durationSec);
  const { sw, sh } = computeEvenSampleDimensions(metadata.width, metadata.height);
  const frameBytes = sw * sh * 3;

  const filterComplex =
    `[0:v]split=2[vmeta][vsamp];` +
    `[vmeta]scale=320:-2,blackdetect=d=0.08:pix_th=0.10,freezedetect=n=0.002:d=0.35,scdet=t=8.5[vnull];` +
    `[vsamp]fps=${sampleFps},scale=${sw}:${sh}:flags=fast_bilinear,format=rgb24[vrgb]`;

  const frames: FrameSample[] = [];
  let stderrChunks: string[] = [];

  await new Promise<void>((resolve, reject) => {
    const ff = spawn(
      'ffmpeg',
      [
        '-hide_banner',
        '-i',
        videoPath,
        '-filter_complex',
        filterComplex,
        '-map',
        '[vnull]',
        '-an',
        '-f',
        'null',
        '-',
        '-map',
        '[vrgb]',
        '-an',
        '-f',
        'rawvideo',
        'pipe:1',
      ],
      { stdio: ['ignore', 'pipe', 'pipe'] }
    );

    let carry: Buffer = Buffer.alloc(0);
    let prevLuma: Uint8Array | null = null;
    let prevHist: Float32Array | null = null;
    let prevGrid: Float32Array | null = null;
    let frameIndex = 0;

    const killTimer = setTimeout(() => {
      ff.kill('SIGKILL');
      reject(new Error('Video intelligence FFmpeg stream timed out.'));
    }, 180000);

    ff.stdout.on('data', (chunk: Buffer) => {
      carry = carry.length > 0 ? Buffer.concat([carry, chunk]) : chunk;
      while (carry.length >= frameBytes) {
        const frameBuf = carry.subarray(0, frameBytes);
        carry = carry.subarray(frameBytes);

        const res = analyzeFramePixels(
          frameBuf,
          prevLuma,
          prevHist,
          prevGrid,
          sw,
          sh,
          frameIndex,
          sampleFps
        );
        frames.push(res.sample);
        prevLuma = res.luma;
        prevHist = res.sample.histogram;
        prevGrid = res.sample.gridLuma;
        frameIndex += 1;
      }
    });

    ff.stderr.setEncoding('utf8');
    ff.stderr.on('data', (text: string) => {
      stderrChunks.push(text);
    });

    ff.on('error', (err) => {
      clearTimeout(killTimer);
      reject(err);
    });

    ff.on('close', (code) => {
      clearTimeout(killTimer);
      if (code !== 0 && frames.length === 0) {
        reject(new Error(`FFmpeg video analysis failed with exit code ${code}.`));
        return;
      }
      resolve();
    });
  });

  const stderrText = stderrChunks.join('');
  const { blackIntervals, frozenIntervals, scdEvents } = parseFfmpegDiagnostics(
    stderrText,
    metadata.durationSec
  );

  const boundaries = buildSceneBoundaries(
    metadata.durationSec,
    sampleFps,
    frames,
    blackIntervals,
    scdEvents
  );

  const scenes: VideoSceneSegment[] = boundaries.map((b, idx) => {
    const dur = Math.max(0.01, round3(b.endSec - b.startSec));
    const isLastScene = idx === boundaries.length - 1;
    let sceneFrames = frames.filter((f) => {
      if (f.timeSec < b.startSec - 0.01) return false;
      if (isLastScene) return f.timeSec <= b.endSec + 0.01;
      return f.timeSec < b.endSec - 0.02;
    });
    if (sceneFrames.length === 0 && frames.length > 0) {
      const midT = (b.startSec + b.endSec) / 2;
      let nearest = frames[0];
      let bestDist = Infinity;
      for (const f of frames) {
        const d = Math.abs(f.timeSec - midT);
        if (d < bestDist) {
          bestDist = d;
          nearest = f;
        }
      }
      sceneFrames = [nearest];
    }

    const nF = Math.max(1, sceneFrames.length);
    const avgBrightness = sceneFrames.reduce((s, f) => s + f.brightness, 0) / nF;
    const avgContrast = sceneFrames.reduce((s, f) => s + f.contrast, 0) / nF;
    const avgSharpness = sceneFrames.reduce((s, f) => s + f.sharpness, 0) / nF;
    const colorfulness = sceneFrames.reduce((s, f) => s + f.colorfulness, 0) / nF;
    const blackFrac = sceneFrames.filter((f) => f.isBlackFrame).length / nF;

    const motionSamples = sceneFrames.filter((f) => {
      if (f.index === 0) return false;
      // Exclude the shot-entry frame whose diff is computed against the previous scene's last frame
      if (idx > 0 && f.timeSec - b.startSec < 1 / sampleFps - 0.02) return false;
      return true;
    });
    const avgMotion =
      motionSamples.length > 0
        ? motionSamples.reduce((s, f) => s + f.motionIntensity, 0) / motionSamples.length
        : 0;

    const blackOverlap = intervalOverlapSec(b.startSec, b.endSec, blackIntervals);
    const frozenOverlap = intervalOverlapSec(b.startSec, b.endSec, frozenIntervals);
    const blackOverlapRatio = blackOverlap / dur;
    const frozenOverlapRatio = frozenOverlap / dur;

    const issues: SceneUsabilityIssue[] = [];
    const isBlack = blackOverlapRatio >= 0.55 || blackFrac >= 0.65 || (avgBrightness < 0.055 && avgContrast < 0.045);
    if (isBlack) issues.push('black-frames');

    // Only flag frozen when FFmpeg freezedetect sees nearly identical pixels AND sampled motion is near zero
    const isFrozen = !isBlack && frozenOverlapRatio >= 0.72 && avgMotion < 0.025 && dur >= 0.4;
    if (isFrozen) issues.push('frozen-static');

    const isLowDetailBlur = !isBlack && avgSharpness < 0.045 && avgContrast < 0.065;
    if (isLowDetailBlur) issues.push('low-detail-blur');

    if (!isBlack && avgBrightness < 0.14) issues.push('underexposed');
    if (avgBrightness > 0.92 && avgContrast < 0.09) issues.push('overexposed');

    const cam = classifySceneCameraMovement(sceneFrames, isFrozen, isBlack);

    // Visual detections aggregated across middle of scene
    const avgPersonScore = sceneFrames.reduce((s, f) => s + f.personLikelihood, 0) / nF;
    const peakPersonScore = Math.max(...sceneFrames.map((f) => f.personLikelihood));
    const personLikelihood = round3(avgPersonScore * 0.65 + peakPersonScore * 0.35);
    const personLikely = !isBlack && personLikelihood >= 0.42;

    const avgObjScore = sceneFrames.reduce((s, f) => s + f.foregroundObjectLikelihood, 0) / nF;
    const avgSalCount = Math.round(sceneFrames.reduce((s, f) => s + f.salientRegionCount, 0) / nF);
    const avgFocusX = sceneFrames.reduce((s, f) => s + f.salientFocusX, 0) / nF;
    const avgFocusY = sceneFrames.reduce((s, f) => s + f.salientFocusY, 0) / nF;

    let framingBalance: SceneVisualDetections['framingBalance'] = 'minimal';
    if (!isBlack && avgSalCount > 0) {
      if (avgSalCount >= 14) {
        framingBalance = 'distributed';
      } else if (Math.abs(avgFocusX - 0.5) < 0.12 && Math.abs(avgFocusY - 0.5) < 0.12) {
        framingBalance = 'centered';
      } else {
        framingBalance = 'rule-of-thirds';
      }
    }

    // Quality & Interest scores
    let visualQualityScore = clamp01(
      avgSharpness * 0.42 +
        avgContrast * 0.33 +
        (1 - Math.abs(avgBrightness - 0.48) * 1.35) * 0.25
    );
    if (isBlack) visualQualityScore = 0.02;
    else if (isFrozen) visualQualityScore = Math.min(visualQualityScore, 0.32);
    else if (isLowDetailBlur) visualQualityScore = Math.min(visualQualityScore, 0.36);

    const avgInterestRaw = sceneFrames.reduce((s, f) => s + f.interestScore, 0) / nF;
    const interestScore = isBlack
      ? 0.01
      : isFrozen
      ? round3(Math.min(0.24, avgInterestRaw * 0.5))
      : round3(
          clamp01(
            avgInterestRaw * 0.65 +
              visualQualityScore * 0.2 +
              (personLikely ? 0.15 : avgObjScore * 0.1)
          )
        );

    const usable = !isBlack && !isLowDetailBlur && !(isFrozen && avgContrast < 0.08);
    let unusableReason: string | null = null;
    if (isBlack) unusableReason = 'Black or blank frames detected';
    else if (isLowDetailBlur) unusableReason = 'Extremely blurry or textureless frame';
    else if (!usable && isFrozen) unusableReason = 'Static frozen frame with negligible detail';

    // Select sharpest high-interest frame within middle 20%..80% of scene for thumbnail
    const safeStart = b.startSec + dur * 0.18;
    const safeEnd = b.endSec - dur * 0.18;
    const midCandidates = sceneFrames.filter((f) => f.timeSec >= safeStart && f.timeSec <= safeEnd);
    const pool = midCandidates.length > 0 ? midCandidates : sceneFrames;
    let bestFrame = pool[0];
    let bestRepScore = -1;
    for (const f of pool) {
      const repScore = f.sharpness * 0.55 + f.interestScore * 0.45 - (f.isBlackFrame ? 1 : 0);
      if (repScore > bestRepScore) {
        bestRepScore = repScore;
        bestFrame = f;
      }
    }
    const repTime = bestFrame
      ? Math.max(0, Math.min(metadata.durationSec - 0.05, bestFrame.timeSec))
      : round3((b.startSec + b.endSec) / 2);

    const movementLabel = cam.movement.replace('-', ' ');
    const summaryParts: string[] = [];
    if (isBlack) {
      summaryParts.push('Black/blank segment (exclude from auto-edit)');
    } else {
      summaryParts.push(`${movementLabel} framing`);
      if (avgMotion >= 0.45) summaryParts.push('high motion energy');
      else if (avgMotion >= 0.18) summaryParts.push('moderate motion');
      else summaryParts.push('steady motion');

      if (personLikely) summaryParts.push('subject/person saliency');
      else if (avgObjScore >= 0.45) summaryParts.push('prominent foreground detail');

      if (isFrozen) summaryParts.push('near-static/frozen hold');
    }

    return {
      sceneIndex: idx,
      assetId,
      startSec: b.startSec,
      endSec: b.endSec,
      durationSec: dur,
      boundaryType: b.boundaryType,
      boundaryConfidence: round3(b.confidence),
      representativeTimestampSec: round3(repTime),
      thumbnailAvailable: false,
      motionIntensity: round3(avgMotion),
      cameraMovement: cam.movement,
      cameraMovementConfidence: cam.confidence,
      cameraPanSpeed: cam.panSpeed,
      cameraZoomRate: cam.zoomRate,
      visualQualityScore: round3(visualQualityScore),
      interestScore,
      avgBrightness: round3(avgBrightness),
      avgContrast: round3(avgContrast),
      avgSharpness: round3(avgSharpness),
      colorfulness: round3(colorfulness),
      usable,
      unusableReason,
      issues,
      detections: {
        personLikelihood,
        personLikely,
        foregroundObjectLikelihood: round3(avgObjScore),
        salientRegionCount: avgSalCount,
        salientFocusPoint: isBlack ? null : { x: round3(avgFocusX), y: round3(avgFocusY) },
        framingBalance,
      },
      summary: summaryParts.join(' · '),
    };
  });

  if (sceneThumbsDir) {
    await generateSceneThumbnails(videoPath, sceneThumbsDir, scenes);
  }

  // Significant moments across the clip
  const significantMoments: VideoSignificantMoment[] = [];
  for (const sc of scenes) {
    if (sc.sceneIndex > 0 && sc.boundaryType !== 'black-gap') {
      significantMoments.push({
        timestampSec: sc.startSec,
        sceneIndex: sc.sceneIndex,
        type: 'scene-transition',
        score: sc.boundaryConfidence,
        summary: `${sc.boundaryType === 'gradual-transition' ? 'Gradual transition' : 'Shot cut'} into Scene ${sc.sceneIndex + 1}`,
      });
    }
  }

  // Peak motion & subject moments from usable scenes
  const usableScenes = scenes.filter((s) => s.usable);
  if (usableScenes.length > 0) {
    const topMotionScene = [...usableScenes].sort((a, b) => b.motionIntensity - a.motionIntensity)[0];
    if (topMotionScene.motionIntensity >= 0.22) {
      significantMoments.push({
        timestampSec: topMotionScene.representativeTimestampSec,
        sceneIndex: topMotionScene.sceneIndex,
        type: 'peak-motion',
        score: topMotionScene.motionIntensity,
        summary: `Peak motion intensity (${Math.round(topMotionScene.motionIntensity * 100)}%) · ${topMotionScene.cameraMovement}`,
      });
    }

    const topInterestScene = [...usableScenes].sort((a, b) => b.interestScore - a.interestScore)[0];
    significantMoments.push({
      timestampSec: topInterestScene.representativeTimestampSec,
      sceneIndex: topInterestScene.sceneIndex,
      type: 'high-interest-peak',
      score: topInterestScene.interestScore,
      summary: `Highest visual interest clip (Scene ${topInterestScene.sceneIndex + 1} · ${Math.round(topInterestScene.interestScore * 100)}%)`,
    });

    const topSubjectScene = usableScenes
      .filter((s) => s.detections.personLikely)
      .sort((a, b) => b.detections.personLikelihood - a.detections.personLikelihood)[0];
    if (topSubjectScene) {
      significantMoments.push({
        timestampSec: topSubjectScene.representativeTimestampSec,
        sceneIndex: topSubjectScene.sceneIndex,
        type: 'subject-focus',
        score: topSubjectScene.detections.personLikelihood,
        summary: `Strongest subject/skin saliency (Scene ${topSubjectScene.sceneIndex + 1} · ${Math.round(topSubjectScene.detections.personLikelihood * 100)}%)`,
      });
    }
  }

  significantMoments.sort((a, b) => a.timestampSec - b.timestampSec);

  // Compact timeline curve (downsampled to <= 120 points for lightweight JSON transfer)
  const stride = Math.max(1, Math.ceil(frames.length / 120));
  const timelineCurve: VideoTimelineSamplePoint[] = [];
  for (let i = 0; i < frames.length; i += stride) {
    const f = frames[i];
    timelineCurve.push({
      timeSec: f.timeSec,
      motionIntensity: f.motionIntensity,
      brightness: f.brightness,
      interestScore: f.interestScore,
    });
  }

  const usableDurationSec = round3(usableScenes.reduce((s, sc) => s + sc.durationSec, 0));
  const blackDurationSec = round3(blackIntervals.reduce((s, iv) => s + iv.durationSec, 0));
  const frozenDurationSec = round3(frozenIntervals.reduce((s, iv) => s + iv.durationSec, 0));

  const averageMotionIntensity =
    usableScenes.length > 0
      ? round3(
          usableScenes.reduce((s, sc) => s + sc.motionIntensity * sc.durationSec, 0) /
            Math.max(0.01, usableDurationSec)
        )
      : 0;

  const averageQualityScore =
    scenes.length > 0
      ? round3(
          scenes.reduce((s, sc) => s + sc.visualQualityScore * sc.durationSec, 0) /
            Math.max(0.01, metadata.durationSec)
        )
      : 0;

  // Dominant camera movement weighted by usable duration
  const movementDurations = new Map<CameraMovementType, number>();
  for (const sc of usableScenes) {
    movementDurations.set(
      sc.cameraMovement,
      (movementDurations.get(sc.cameraMovement) || 0) + sc.durationSec
    );
  }
  let dominantCameraMovement: CameraMovementType = 'static';
  let maxMoveDur = -1;
  for (const [mv, d] of movementDurations.entries()) {
    if (d > maxMoveDur) {
      maxMoveDur = d;
      dominantCameraMovement = mv;
    }
  }

  const notes: string[] = [];
  if (blackDurationSec > 0.2) {
    notes.push(
      `Detected ${blackDurationSec.toFixed(1)}s of black/blank footage across ${blackIntervals.length} interval(s); flagged for exclusion in Milestone 5 auto-editing.`
    );
  }
  if (frozenDurationSec > 0.5 && scenes.some((s) => s.issues.includes('frozen-static'))) {
    notes.push(
      `Detected static/frozen segments (${frozenDurationSec.toFixed(1)}s) with near-zero frame motion.`
    );
  }
  if (metadata.rotationDeg !== 0) {
    notes.push(
      `Source container carries ${metadata.rotationDeg}° display rotation metadata; effective oriented frame is ${metadata.width}×${metadata.height} (${metadata.orientation}).`
    );
  }
  if (usableScenes.length === 0) {
    notes.push('No usable visual segments detected; footage appears black, blank, or severely degraded.');
  }

  return {
    metadata,
    sampleFpsUsed: sampleFps,
    scenes,
    blackIntervals,
    frozenIntervals,
    significantMoments,
    timelineCurve,
    usableSceneCount: usableScenes.length,
    usableDurationSec,
    blackDurationSec,
    frozenDurationSec,
    averageMotionIntensity,
    averageQualityScore,
    dominantCameraMovement,
    capabilities: {
      sceneDetectionMethod:
        'FFmpeg native-FPS luma scdet + downscaled RGB24 color-histogram & grid-luminance boundary fusion',
      cameraMotionMethod:
        'Multi-block optical-flow translation + radial zoom divergence + residual foreground separation',
      personDetectionMethod:
        'YCbCr skin-chrominance + spatial compactness heuristic (approximate visual saliency, not neural face recognition)',
      objectDetectionMethod:
        '8x5 spatial edge density + perimeter color contrast + residual motion saliency',
      neuralModelsInstalled: false,
      honestyNote:
        'No YOLO, OpenCV, or MediaPipe neural weights are installed on this host; people & object scores represent real pixel-level visual saliency likelihoods rather than named object classification.',
    },
    notes,
  };
}
