import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import type { VideoOrientation, VideoStreamMetadata } from '../contracts.ts';

const execFileAsync = promisify(execFile);

interface FFprobeSideData {
  side_data_type?: string;
  rotation?: number;
}

interface FFprobeStream {
  codec_type?: string;
  codec_name?: string;
  pix_fmt?: string;
  width?: number;
  height?: number;
  avg_frame_rate?: string;
  r_frame_rate?: string;
  duration?: string;
  bit_rate?: string;
  tags?: Record<string, string>;
  side_data_list?: FFprobeSideData[];
}

interface FFprobeOutput {
  streams?: FFprobeStream[];
  format?: {
    duration?: string;
    bit_rate?: string;
  };
}

function parseFrameRate(raw: string | undefined): number {
  if (!raw || raw === '0/0') return 0;
  const parts = raw.split('/');
  if (parts.length === 2) {
    const num = Number(parts[0]);
    const den = Number(parts[1]);
    if (Number.isFinite(num) && Number.isFinite(den) && den > 0) {
      return Number((num / den).toFixed(3));
    }
  }
  const direct = Number(raw);
  return Number.isFinite(direct) && direct > 0 ? Number(direct.toFixed(3)) : 0;
}

function parseRotationDeg(stream: FFprobeStream): number {
  const tagRotate = stream.tags?.rotate ? Number(stream.tags.rotate) : NaN;
  let rot = Number.isFinite(tagRotate) ? tagRotate : 0;

  if (Array.isArray(stream.side_data_list)) {
    for (const sd of stream.side_data_list) {
      if (typeof sd.rotation === 'number' && Number.isFinite(sd.rotation)) {
        rot = sd.rotation;
        break;
      }
    }
  }

  const normalized = ((Math.round(rot / 90) * 90) % 360 + 360) % 360;
  return normalized;
}

function gcd(a: number, b: number): number {
  let x = Math.abs(Math.round(a));
  let y = Math.abs(Math.round(b));
  while (y !== 0) {
    const t = x % y;
    x = y;
    y = t;
  }
  return x || 1;
}

function formatAspectRatioLabel(width: number, height: number): string {
  if (width <= 0 || height <= 0) return 'unknown';
  const ratio = width / height;
  if (Math.abs(ratio - 16 / 9) < 0.04) return '16:9';
  if (Math.abs(ratio - 9 / 16) < 0.04) return '9:16';
  if (Math.abs(ratio - 1) < 0.04) return '1:1';
  if (Math.abs(ratio - 4 / 3) < 0.04) return '4:3';
  if (Math.abs(ratio - 3 / 4) < 0.04) return '3:4';
  if (Math.abs(ratio - 21 / 9) < 0.06) return '21:9';
  const d = gcd(width, height);
  return `${Math.round(width / d)}:${Math.round(height / d)}`;
}

export async function probeVideoMetadata(videoPath: string): Promise<VideoStreamMetadata> {
  const { stdout } = await execFileAsync(
    'ffprobe',
    ['-v', 'quiet', '-print_format', 'json', '-show_format', '-show_streams', videoPath],
    { timeout: 20000, maxBuffer: 4 * 1024 * 1024 }
  );

  const parsed = JSON.parse(stdout) as FFprobeOutput;
  const streams = Array.isArray(parsed.streams) ? parsed.streams : [];
  const videoStream = streams.find((s) => s.codec_type === 'video');
  if (!videoStream) {
    throw new Error('No video stream found in uploaded file.');
  }

  const audioStream = streams.find((s) => s.codec_type === 'audio');
  const encodedWidth = typeof videoStream.width === 'number' && videoStream.width > 0 ? videoStream.width : 0;
  const encodedHeight = typeof videoStream.height === 'number' && videoStream.height > 0 ? videoStream.height : 0;
  if (encodedWidth <= 0 || encodedHeight <= 0) {
    throw new Error('Unable to determine valid video dimensions.');
  }

  const rotationDeg = parseRotationDeg(videoStream);
  const rotated90or270 = rotationDeg === 90 || rotationDeg === 270;
  const width = rotated90or270 ? encodedHeight : encodedWidth;
  const height = rotated90or270 ? encodedWidth : encodedHeight;

  let orientation: VideoOrientation = 'landscape';
  if (Math.abs(width - height) <= 2) {
    orientation = 'square';
  } else if (height > width) {
    orientation = 'portrait';
  }

  const fps =
    parseFrameRate(videoStream.avg_frame_rate) ||
    parseFrameRate(videoStream.r_frame_rate) ||
    30;

  const formatDuration = Number(parsed.format?.duration || 0);
  const streamDuration = Number(videoStream.duration || 0);
  const durationSec =
    Number.isFinite(formatDuration) && formatDuration > 0
      ? formatDuration
      : Number.isFinite(streamDuration) && streamDuration > 0
      ? streamDuration
      : 0;

  if (durationSec <= 0) {
    throw new Error('Video duration could not be verified by FFprobe.');
  }

  const rawBitrate = Number(videoStream.bit_rate || parsed.format?.bit_rate || 0);
  const bitrateKbps =
    Number.isFinite(rawBitrate) && rawBitrate > 0 ? Math.round(rawBitrate / 1000) : null;

  return {
    width,
    height,
    encodedWidth,
    encodedHeight,
    rotationDeg,
    orientation,
    aspectRatioLabel: formatAspectRatioLabel(width, height),
    fps: Number(fps.toFixed(2)),
    durationSec: Number(durationSec.toFixed(3)),
    codecName: videoStream.codec_name || 'unknown',
    pixFmt: videoStream.pix_fmt || 'unknown',
    bitrateKbps,
    hasAudio: Boolean(audioStream),
    audioCodec: audioStream?.codec_name || null,
  };
}
