import crypto from 'node:crypto';
import { Router } from 'express';
import { requireAuth } from '../auth.ts';
import type { AuthenticatedRequest } from '../auth.ts';
import { db } from '../db.ts';
import { resolveSafeStoragePath, safeRmDir, safeUnlink } from '../storage.ts';

const ALLOWED_ASPECT_RATIOS = new Set(['16:9', '9:16', '1:1']);
const ALLOWED_RESOLUTIONS = new Set(['720p', '1080p']);
const ALLOWED_FPS = new Set([24, 30, 60]);
const ALLOWED_STYLES = new Set([
  'beat-synchronized',
  'cinematic',
  'dynamic',
  'slow-motion',
  'music-video',
  'social-media',
  'professional-montage',
]);

interface ProjectRow {
  id: string;
  user_id: string;
  title: string;
  description: string;
  aspect_ratio: string;
  target_resolution: string;
  target_fps: number;
  editing_style: string;
  low_data_mode: number;
  status: string;
  created_at: string;
  updated_at: string;
}

function mapProjectRow(row: ProjectRow) {
  return {
    id: row.id,
    userId: row.user_id,
    title: row.title,
    description: row.description,
    aspectRatio: row.aspect_ratio,
    targetResolution: row.target_resolution,
    targetFps: row.target_fps,
    editingStyle: row.editing_style,
    lowDataMode: row.low_data_mode === 1,
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export const projectsRouter = Router();
projectsRouter.use(requireAuth);

projectsRouter.get('/', (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const aspectFilter = typeof req.query.aspectRatio === 'string' ? req.query.aspectRatio : '';
  const searchQuery = typeof req.query.q === 'string' ? req.query.q.trim().toLowerCase() : '';

  const rows = db
    .prepare(
      `SELECT id, user_id, title, description, aspect_ratio, target_resolution, target_fps,
              editing_style, low_data_mode, status, created_at, updated_at
       FROM projects
       WHERE user_id = ?
       ORDER BY updated_at DESC`
    )
    .all(authUser.id) as unknown as ProjectRow[];

  const projects = rows
    .filter((row) => {
      if (aspectFilter && ALLOWED_ASPECT_RATIOS.has(aspectFilter) && row.aspect_ratio !== aspectFilter) {
        return false;
      }
      if (searchQuery) {
        const matchTitle = row.title.toLowerCase().includes(searchQuery);
        const matchDesc = row.description.toLowerCase().includes(searchQuery);
        if (!matchTitle && !matchDesc) return false;
      }
      return true;
    })
    .map(mapProjectRow);

  res.json({ projects });
});

projectsRouter.post('/', (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const body = req.body as Record<string, unknown>;

  const title = typeof body?.title === 'string' ? body.title.trim() : '';
  const description = typeof body?.description === 'string' ? body.description.trim() : '';
  const aspectRatio = typeof body?.aspectRatio === 'string' ? body.aspectRatio : '16:9';
  const targetResolution = typeof body?.targetResolution === 'string' ? body.targetResolution : '1080p';
  const targetFps = typeof body?.targetFps === 'number' ? body.targetFps : Number(body?.targetFps ?? 30);
  const editingStyle = typeof body?.editingStyle === 'string' ? body.editingStyle : 'beat-synchronized';
  const lowDataMode =
    body?.lowDataMode !== undefined ? Boolean(body.lowDataMode) : authUser.lowDataMode;

  if (title.length < 1 || title.length > 100) {
    res.status(400).json({ error: 'Project title must be between 1 and 100 characters.' });
    return;
  }
  if (description.length > 400) {
    res.status(400).json({ error: 'Project description cannot exceed 400 characters.' });
    return;
  }
  if (!ALLOWED_ASPECT_RATIOS.has(aspectRatio)) {
    res.status(400).json({ error: 'Aspect ratio must be 16:9, 9:16, or 1:1.' });
    return;
  }
  if (!ALLOWED_RESOLUTIONS.has(targetResolution)) {
    res.status(400).json({ error: 'Target resolution must be 720p or 1080p.' });
    return;
  }
  if (!ALLOWED_FPS.has(targetFps)) {
    res.status(400).json({ error: 'Target frame rate must be 24, 30, or 60 fps.' });
    return;
  }
  if (!ALLOWED_STYLES.has(editingStyle)) {
    res.status(400).json({ error: 'Invalid editing style selection.' });
    return;
  }

  const projectId = crypto.randomUUID();
  const nowIso = new Date().toISOString();

  db.prepare(
    `INSERT INTO projects (
       id, user_id, title, description, aspect_ratio, target_resolution, target_fps,
       editing_style, low_data_mode, status, created_at, updated_at
     ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?, ?)`
  ).run(
    projectId,
    authUser.id,
    title,
    description,
    aspectRatio,
    targetResolution,
    targetFps,
    editingStyle,
    lowDataMode ? 1 : 0,
    nowIso,
    nowIso
  );

  const created = db
    .prepare(
      `SELECT id, user_id, title, description, aspect_ratio, target_resolution, target_fps,
              editing_style, low_data_mode, status, created_at, updated_at
       FROM projects WHERE id = ? AND user_id = ?`
    )
    .get(projectId, authUser.id) as unknown as ProjectRow;

  res.status(201).json({ project: mapProjectRow(created) });
});

projectsRouter.get('/:id', (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const projectId = String(req.params.id || '');

  const row = db
    .prepare(
      `SELECT id, user_id, title, description, aspect_ratio, target_resolution, target_fps,
              editing_style, low_data_mode, status, created_at, updated_at
       FROM projects WHERE id = ? AND user_id = ?`
    )
    .get(projectId, authUser.id) as ProjectRow | undefined;

  if (!row) {
    res.status(404).json({ error: 'Project not found.' });
    return;
  }

  res.json({ project: mapProjectRow(row) });
});

projectsRouter.patch('/:id', (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const projectId = String(req.params.id || '');
  const body = req.body as Record<string, unknown>;

  const existing = db
    .prepare(
      `SELECT id, user_id, title, description, aspect_ratio, target_resolution, target_fps,
              editing_style, low_data_mode, status, created_at, updated_at
       FROM projects WHERE id = ? AND user_id = ?`
    )
    .get(projectId, authUser.id) as ProjectRow | undefined;

  if (!existing) {
    res.status(404).json({ error: 'Project not found.' });
    return;
  }

  let nextTitle = existing.title;
  if (body.title !== undefined) {
    if (typeof body.title !== 'string') {
      res.status(400).json({ error: 'Invalid project title.' });
      return;
    }
    const trimmed = body.title.trim();
    if (trimmed.length < 1 || trimmed.length > 100) {
      res.status(400).json({ error: 'Project title must be between 1 and 100 characters.' });
      return;
    }
    nextTitle = trimmed;
  }

  let nextDescription = existing.description;
  if (body.description !== undefined) {
    if (typeof body.description !== 'string' || body.description.trim().length > 400) {
      res.status(400).json({ error: 'Project description cannot exceed 400 characters.' });
      return;
    }
    nextDescription = body.description.trim();
  }

  let nextAspectRatio = existing.aspect_ratio;
  if (body.aspectRatio !== undefined) {
    if (typeof body.aspectRatio !== 'string' || !ALLOWED_ASPECT_RATIOS.has(body.aspectRatio)) {
      res.status(400).json({ error: 'Aspect ratio must be 16:9, 9:16, or 1:1.' });
      return;
    }
    nextAspectRatio = body.aspectRatio;
  }

  let nextResolution = existing.target_resolution;
  if (body.targetResolution !== undefined) {
    if (typeof body.targetResolution !== 'string' || !ALLOWED_RESOLUTIONS.has(body.targetResolution)) {
      res.status(400).json({ error: 'Target resolution must be 720p or 1080p.' });
      return;
    }
    nextResolution = body.targetResolution;
  }

  let nextFps = existing.target_fps;
  if (body.targetFps !== undefined) {
    const parsedFps = typeof body.targetFps === 'number' ? body.targetFps : Number(body.targetFps);
    if (!ALLOWED_FPS.has(parsedFps)) {
      res.status(400).json({ error: 'Target frame rate must be 24, 30, or 60 fps.' });
      return;
    }
    nextFps = parsedFps;
  }

  let nextStyle = existing.editing_style;
  if (body.editingStyle !== undefined) {
    if (typeof body.editingStyle !== 'string' || !ALLOWED_STYLES.has(body.editingStyle)) {
      res.status(400).json({ error: 'Invalid editing style selection.' });
      return;
    }
    nextStyle = body.editingStyle;
  }

  const nextLowDataMode =
    body.lowDataMode !== undefined ? Boolean(body.lowDataMode) : existing.low_data_mode === 1;

  const updatedAt = new Date().toISOString();

  db.prepare(
    `UPDATE projects
     SET title = ?, description = ?, aspect_ratio = ?, target_resolution = ?, target_fps = ?,
         editing_style = ?, low_data_mode = ?, updated_at = ?
     WHERE id = ? AND user_id = ?`
  ).run(
    nextTitle,
    nextDescription,
    nextAspectRatio,
    nextResolution,
    nextFps,
    nextStyle,
    nextLowDataMode ? 1 : 0,
    updatedAt,
    projectId,
    authUser.id
  );

  const updated = db
    .prepare(
      `SELECT id, user_id, title, description, aspect_ratio, target_resolution, target_fps,
              editing_style, low_data_mode, status, created_at, updated_at
       FROM projects WHERE id = ? AND user_id = ?`
    )
    .get(projectId, authUser.id) as unknown as ProjectRow;

  res.json({ project: mapProjectRow(updated) });
});

projectsRouter.delete('/:id', (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const projectId = String(req.params.id || '');

  const existingProject = db
    .prepare(`SELECT id FROM projects WHERE id = ? AND user_id = ?`)
    .get(projectId, authUser.id);
  if (!existingProject) {
    res.status(404).json({ error: 'Project not found.' });
    return;
  }

  const assets = db
    .prepare(
      `SELECT id, stored_filename, proxy_filename, thumbnail_filename
       FROM media_assets WHERE project_id = ? AND user_id = ?`
    )
    .all(projectId, authUser.id) as unknown as Array<{
    id: string;
    stored_filename: string;
    proxy_filename: string | null;
    thumbnail_filename: string | null;
  }>;

  for (const asset of assets) {
    safeUnlink(resolveSafeStoragePath('uploads', authUser.id, asset.stored_filename));
    if (asset.proxy_filename) {
      safeUnlink(resolveSafeStoragePath('uploads', authUser.id, asset.proxy_filename));
    }
    if (asset.thumbnail_filename) {
      safeUnlink(resolveSafeStoragePath('uploads', authUser.id, 'thumbs', asset.thumbnail_filename));
    }
    safeRmDir(resolveSafeStoragePath('uploads', authUser.id, 'thumbs', 'scenes', asset.id));
  }

  const sessions = db
    .prepare(`SELECT id FROM upload_sessions WHERE project_id = ? AND user_id = ?`)
    .all(projectId, authUser.id) as unknown as Array<{ id: string }>;

  for (const s of sessions) {
    safeUnlink(resolveSafeStoragePath('temp', 'uploads', authUser.id, `${s.id}.part`));
  }

  db.prepare(`DELETE FROM projects WHERE id = ? AND user_id = ?`).run(projectId, authUser.id);

  res.json({ ok: true });
});
