import { Router } from 'express';
import { requireAuth } from '../auth.ts';
import { inspectSystemCapabilities } from '../engine/registry.ts';

export const systemRouter = Router();

systemRouter.get('/health', (_req, res) => {
  res.json({ ok: true, milestone: 4 });
});

systemRouter.get('/capabilities', requireAuth, async (_req, res) => {
  const capabilities = await inspectSystemCapabilities();
  res.json(capabilities);
});
