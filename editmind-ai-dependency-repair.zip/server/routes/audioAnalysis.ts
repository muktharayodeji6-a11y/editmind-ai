import { Router } from 'express';
import { requireAuth } from '../auth.ts';
import type { AuthenticatedRequest } from '../auth.ts';
import { db } from '../db.ts';
import { analyzeAudioAsset, getCachedAudioAnalysis } from '../engine/audio/service.ts';

export const audioAnalysisRouter = Router();
audioAnalysisRouter.use(requireAuth);

audioAnalysisRouter.get('/:mediaId', (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const mediaId = String(req.params.mediaId || '');

  const asset = db
    .prepare(`SELECT id, media_kind FROM media_assets WHERE id = ? AND user_id = ?`)
    .get(mediaId, authUser.id) as { id: string; media_kind: string } | undefined;

  if (!asset) {
    res.status(404).json({ error: 'Media asset not found.' });
    return;
  }

  if (asset.media_kind !== 'audio') {
    res.status(400).json({ error: 'Audio intelligence is only available for audio tracks.' });
    return;
  }

  const cachedResult = getCachedAudioAnalysis(mediaId, authUser.id);
  res.json(cachedResult);
});

audioAnalysisRouter.post('/:mediaId/analyze', async (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const mediaId = String(req.params.mediaId || '');
  const force = Boolean((req.body as Record<string, unknown>)?.force);

  const asset = db
    .prepare(`SELECT id, media_kind FROM media_assets WHERE id = ? AND user_id = ?`)
    .get(mediaId, authUser.id) as { id: string; media_kind: string } | undefined;

  if (!asset) {
    res.status(404).json({ error: 'Media asset not found.' });
    return;
  }

  if (asset.media_kind !== 'audio') {
    res.status(400).json({ error: 'Audio intelligence analysis requires an audio asset.' });
    return;
  }

  try {
    const result = await analyzeAudioAsset(mediaId, authUser.id, { force });
    res.json({
      status: 'ready',
      cached: result.cached,
      analysis: result.analysis,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Audio analysis failed.';
    res.status(500).json({ error: message });
  }
});
