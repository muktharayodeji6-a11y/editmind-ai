import crypto from 'node:crypto';
import express, { Router } from 'express';
import fs from 'node:fs';
import { hashToken, requireAuth } from '../auth.ts';
import type { AuthenticatedRequest } from '../auth.ts';
import { db } from '../db.ts';
import {
  analyzeVideoAsset,
  createSceneThumbnailSignature,
  getCachedVideoAnalysis,
} from '../engine/video/service.ts';
import { resolveSafeStoragePath } from '../storage.ts';

function verifySceneThumbnailGrantOrBearer(
  req: express.Request,
  mediaId: string,
  sceneIndex: number
): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const rawToken = authHeader.slice('Bearer '.length).trim();
    if (rawToken.length >= 32) {
      const tokenHash = hashToken(rawToken);
      const row = db
        .prepare(`SELECT user_id, expires_at FROM sessions WHERE token_hash = ?`)
        .get(tokenHash) as { user_id: string; expires_at: string } | undefined;
      if (row && Date.parse(row.expires_at) > Date.now()) {
        return row.user_id;
      }
    }
  }

  const uid = typeof req.query.uid === 'string' ? req.query.uid : '';
  const expStr = typeof req.query.exp === 'string' ? req.query.exp : '';
  const sig = typeof req.query.sig === 'string' ? req.query.sig : '';
  const expMs = Number(expStr);

  if (!uid || !sig || !Number.isFinite(expMs) || expMs <= Date.now()) {
    return null;
  }

  const expected = createSceneThumbnailSignature(mediaId, sceneIndex, uid, expMs);
  const actualBuf = Buffer.from(sig, 'utf8');
  const expectedBuf = Buffer.from(expected, 'utf8');
  if (actualBuf.length !== expectedBuf.length) return null;
  if (!crypto.timingSafeEqual(actualBuf, expectedBuf)) return null;

  return uid;
}

export const videoAnalysisRouter = Router();

videoAnalysisRouter.get('/:mediaId', requireAuth, (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const mediaId = String(req.params.mediaId || '');

  const asset = db
    .prepare(`SELECT id, media_kind FROM media_assets WHERE id = ? AND user_id = ?`)
    .get(mediaId, authUser.id) as { id: string; media_kind: string } | undefined;

  if (!asset) {
    res.status(404).json({ error: 'Media asset not found.' });
    return;
  }

  if (asset.media_kind !== 'video') {
    res.status(400).json({ error: 'Video intelligence is only available for video clips.' });
    return;
  }

  const cachedResult = getCachedVideoAnalysis(mediaId, authUser.id);
  res.json(cachedResult);
});

videoAnalysisRouter.post('/:mediaId/analyze', requireAuth, async (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const mediaId = String(req.params.mediaId || '');
  const force = Boolean((req.body as Record<string, unknown>)?.force);

  const asset = db
    .prepare(`SELECT id, media_kind FROM media_assets WHERE id = ? AND user_id = ?`)
    .get(mediaId, authUser.id) as { id: string; media_kind: string } | undefined;

  if (!asset) {
    res.status(404).json({ error: 'Media asset not found.' });
    return;
  }

  if (asset.media_kind !== 'video') {
    res.status(400).json({ error: 'Video intelligence analysis requires a video asset.' });
    return;
  }

  try {
    const result = await analyzeVideoAsset(mediaId, authUser.id, { force });
    res.json({
      status: 'ready',
      cached: result.cached,
      analysis: result.analysis,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Video analysis failed.';
    res.status(500).json({ error: message });
  }
});

videoAnalysisRouter.get('/:mediaId/scenes/:sceneIndex/thumbnail', (req, res) => {
  const mediaId = String(req.params.mediaId || '');
  const sceneIndex = Number(req.params.sceneIndex);

  if (!Number.isInteger(sceneIndex) || sceneIndex < 0 || sceneIndex > 5000) {
    res.status(400).json({ error: 'Invalid scene index.' });
    return;
  }

  const authorizedUserId = verifySceneThumbnailGrantOrBearer(req, mediaId, sceneIndex);
  if (!authorizedUserId) {
    res.status(401).json({ error: 'Authentication or valid scene thumbnail grant required.' });
    return;
  }

  const asset = db
    .prepare(`SELECT id, media_kind FROM media_assets WHERE id = ? AND user_id = ?`)
    .get(mediaId, authorizedUserId) as { id: string; media_kind: string } | undefined;

  if (!asset || asset.media_kind !== 'video') {
    res.status(404).json({ error: 'Video asset not found.' });
    return;
  }

  const thumbPath = resolveSafeStoragePath(
    'uploads',
    authorizedUserId,
    'thumbs',
    'scenes',
    mediaId,
    `scene_${sceneIndex}.jpg`
  );

  if (!fs.existsSync(thumbPath)) {
    res.status(404).json({ error: 'Scene thumbnail not found.' });
    return;
  }

  res.setHeader('Content-Type', 'image/jpeg');
  res.setHeader('Cache-Control', 'private, max-age=300');
  fs.createReadStream(thumbPath).pipe(res);
});
