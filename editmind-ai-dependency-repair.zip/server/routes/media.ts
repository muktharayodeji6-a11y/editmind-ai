import crypto from 'node:crypto';
import express, { Router } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { hashToken, requireAuth } from '../auth.ts';
import type { AuthenticatedRequest } from '../auth.ts';
import { config } from '../config.ts';
import { db } from '../db.ts';
import {
  EXTENSION_MIME_MAP,
  generateLowDataVideoProxy,
  generateVideoThumbnail,
  getValidatedExtension,
  probeMediaFile,
  sanitizeDisplayFilename,
} from '../mediaProbe.ts';
import { deleteCachedVideoAnalysisArtifacts } from '../engine/video/service.ts';
import {
  ensureUserMediaDirectories,
  resolveSafeStoragePath,
  safeUnlink,
} from '../storage.ts';

interface UploadSessionRow {
  id: string;
  user_id: string;
  project_id: string;
  media_kind: 'audio' | 'video';
  original_name: string;
  mime_type: string;
  total_size: number;
  chunk_size: number;
  total_chunks: number;
  received_chunks: string;
  uploaded_bytes: number;
  client_fingerprint: string;
  replace_media_id: string | null;
  generate_low_data_proxy: number;
  status: string;
  error_message: string | null;
  created_at: string;
  updated_at: string;
}

interface MediaAssetRow {
  id: string;
  user_id: string;
  project_id: string;
  media_kind: 'audio' | 'video';
  original_name: string;
  stored_filename: string;
  proxy_filename: string | null;
  thumbnail_filename: string | null;
  mime_type: string;
  extension: string;
  size_bytes: number;
  duration_sec: number;
  codec_name: string;
  width: number | null;
  height: number | null;
  sample_rate: number | null;
  channels: number | null;
  sha256: string;
  upload_status: string;
  created_at: string;
  updated_at: string;
}

function mapMediaAsset(row: MediaAssetRow) {
  return {
    id: row.id,
    userId: row.user_id,
    projectId: row.project_id,
    mediaKind: row.media_kind,
    originalName: row.original_name,
    mimeType: row.mime_type,
    extension: row.extension,
    sizeBytes: row.size_bytes,
    durationSec: row.duration_sec,
    codecName: row.codec_name,
    width: row.width,
    height: row.height,
    sampleRate: row.sample_rate,
    channels: row.channels,
    hasThumbnail: Boolean(row.thumbnail_filename),
    hasLowDataProxy: Boolean(row.proxy_filename),
    uploadStatus: row.upload_status,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function parseReceivedChunks(raw: string): number[] {
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((n): n is number => Number.isInteger(n) && n >= 0);
  } catch {
    return [];
  }
}

function computeFileSha256(filePath: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
    stream.on('error', reject);
  });
}

function createPlaybackSignature(
  mediaId: string,
  userId: string,
  expMs: number,
  resourceType: 'stream' | 'thumbnail'
): string {
  return crypto
    .createHmac('sha256', config.mediaSigningSecret)
    .update(`${mediaId}:${userId}:${expMs}:${resourceType}`)
    .digest('hex');
}

function verifyPlaybackGrantOrBearer(
  req: express.Request,
  mediaId: string,
  resourceType: 'stream' | 'thumbnail'
): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const rawToken = authHeader.slice('Bearer '.length).trim();
    if (rawToken.length >= 32) {
      const tokenHash = hashToken(rawToken);
      const row = db
        .prepare(`SELECT user_id, expires_at FROM sessions WHERE token_hash = ?`)
        .get(tokenHash) as { user_id: string; expires_at: string } | undefined;
      if (row && Date.parse(row.expires_at) > Date.now()) {
        return row.user_id;
      }
    }
  }

  const uid = typeof req.query.uid === 'string' ? req.query.uid : '';
  const expStr = typeof req.query.exp === 'string' ? req.query.exp : '';
  const sig = typeof req.query.sig === 'string' ? req.query.sig : '';
  const expMs = Number(expStr);

  if (!uid || !sig || !Number.isFinite(expMs) || expMs <= Date.now()) {
    return null;
  }

  const expected = createPlaybackSignature(mediaId, uid, expMs, resourceType);
  const actualBuf = Buffer.from(sig, 'utf8');
  const expectedBuf = Buffer.from(expected, 'utf8');
  if (actualBuf.length !== expectedBuf.length) return null;
  if (!crypto.timingSafeEqual(actualBuf, expectedBuf)) return null;

  return uid;
}

export const mediaRouter = Router();

mediaRouter.post('/uploads/init', requireAuth, (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const body = req.body as Record<string, unknown>;

  const projectId = typeof body?.projectId === 'string' ? body.projectId.trim() : '';
  const mediaKind = body?.mediaKind === 'audio' || body?.mediaKind === 'video' ? body.mediaKind : null;
  const rawName = typeof body?.originalName === 'string' ? body.originalName : '';
  const mimeType = typeof body?.mimeType === 'string' ? body.mimeType.trim() : '';
  const totalSize = Number(body?.totalSize);
  const chunkSize = Number(body?.chunkSize);
  const clientFingerprint =
    typeof body?.clientFingerprint === 'string' ? body.clientFingerprint.trim() : '';
  const replaceMediaId =
    typeof body?.replaceMediaId === 'string' && body.replaceMediaId.trim()
      ? body.replaceMediaId.trim()
      : null;
  const generateLowDataProxy = Boolean(body?.generateLowDataProxy);

  if (!projectId) {
    res.status(400).json({ error: 'Project ID is required.' });
    return;
  }

  const project = db
    .prepare(`SELECT id FROM projects WHERE id = ? AND user_id = ?`)
    .get(projectId, authUser.id);
  if (!project) {
    res.status(404).json({ error: 'Target project not found.' });
    return;
  }

  if (!mediaKind) {
    res.status(400).json({ error: 'Media kind must be audio or video.' });
    return;
  }

  const originalName = sanitizeDisplayFilename(rawName);
  const ext = getValidatedExtension(originalName, mediaKind);
  if (!ext) {
    res.status(400).json({
      error:
        mediaKind === 'audio'
          ? 'Unsupported audio format. Supported formats: MP3, WAV, AAC, FLAC.'
          : 'Unsupported video format. Supported formats: MP4, MOV.',
    });
    return;
  }

  const maxSize = mediaKind === 'audio' ? config.maxAudioBytes : config.maxVideoBytes;
  if (!Number.isInteger(totalSize) || totalSize <= 0 || totalSize > maxSize) {
    const limitMb = Math.round(maxSize / (1024 * 1024));
    res.status(400).json({
      error: `File size must be between 1 byte and ${limitMb} MB for ${mediaKind} files.`,
    });
    return;
  }

  if (
    !Number.isInteger(chunkSize) ||
    chunkSize < 64 * 1024 ||
    chunkSize > config.maxChunkBytes
  ) {
    res.status(400).json({ error: 'Chunk size must be between 64 KB and 4 MB.' });
    return;
  }

  if (!clientFingerprint || clientFingerprint.length > 128) {
    res.status(400).json({ error: 'Valid file fingerprint is required for resumable uploads.' });
    return;
  }

  if (replaceMediaId) {
    const targetAsset = db
      .prepare(
        `SELECT id, media_kind FROM media_assets WHERE id = ? AND user_id = ? AND project_id = ?`
      )
      .get(replaceMediaId, authUser.id, projectId) as { id: string; media_kind: string } | undefined;
    if (!targetAsset) {
      res.status(404).json({ error: 'Media item to replace was not found.' });
      return;
    }
    if (targetAsset.media_kind !== mediaKind) {
      res.status(400).json({ error: 'Replacement file must match the original media type.' });
      return;
    }
  }

  const { userTempDir } = ensureUserMediaDirectories(authUser.id);

  // Resume existing incomplete upload session matching exact fingerprint & target
  const existingSession = db
    .prepare(
      `SELECT * FROM upload_sessions
       WHERE user_id = ? AND project_id = ? AND client_fingerprint = ?
         AND total_size = ? AND chunk_size = ? AND status = 'in_progress'
       ORDER BY created_at DESC LIMIT 1`
    )
    .get(
      authUser.id,
      projectId,
      clientFingerprint,
      totalSize,
      chunkSize
    ) as unknown as UploadSessionRow | undefined;

  if (
    existingSession &&
    (existingSession.replace_media_id || null) === replaceMediaId
  ) {
    const partPath = resolveSafeStoragePath('temp', 'uploads', authUser.id, `${existingSession.id}.part`);
    if (fs.existsSync(partPath)) {
      const receivedChunks = parseReceivedChunks(existingSession.received_chunks);
      res.json({
        resumed: true,
        uploadId: existingSession.id,
        chunkSize: existingSession.chunk_size,
        totalChunks: existingSession.total_chunks,
        totalSize: existingSession.total_size,
        uploadedBytes: existingSession.uploaded_bytes,
        receivedChunks,
      });
      return;
    }
  }

  const uploadId = crypto.randomUUID();
  const totalChunks = Math.ceil(totalSize / chunkSize);
  const normalizedMime = EXTENSION_MIME_MAP[ext] || mimeType || 'application/octet-stream';
  const nowIso = new Date().toISOString();

  const partPath = path.join(userTempDir, `${uploadId}.part`);
  fs.writeFileSync(partPath, Buffer.alloc(0));

  db.prepare(
    `INSERT INTO upload_sessions (
       id, user_id, project_id, media_kind, original_name, mime_type,
       total_size, chunk_size, total_chunks, received_chunks, uploaded_bytes,
       client_fingerprint, replace_media_id, generate_low_data_proxy, status, created_at, updated_at
     ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, '[]', 0, ?, ?, ?, 'in_progress', ?, ?)`
  ).run(
    uploadId,
    authUser.id,
    projectId,
    mediaKind,
    originalName,
    normalizedMime,
    totalSize,
    chunkSize,
    totalChunks,
    clientFingerprint,
    replaceMediaId,
    mediaKind === 'video' && generateLowDataProxy ? 1 : 0,
    nowIso,
    nowIso
  );

  res.status(201).json({
    resumed: false,
    uploadId,
    chunkSize,
    totalChunks,
    totalSize,
    uploadedBytes: 0,
    receivedChunks: [],
  });
});

mediaRouter.get('/uploads/:uploadId/status', requireAuth, (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const uploadId = String(req.params.uploadId || '');

  const session = db
    .prepare(`SELECT * FROM upload_sessions WHERE id = ? AND user_id = ?`)
    .get(uploadId, authUser.id) as unknown as UploadSessionRow | undefined;

  if (!session) {
    res.status(404).json({ error: 'Upload session not found.' });
    return;
  }

  res.json({
    uploadId: session.id,
    projectId: session.project_id,
    mediaKind: session.media_kind,
    originalName: session.original_name,
    status: session.status,
    totalSize: session.total_size,
    chunkSize: session.chunk_size,
    totalChunks: session.total_chunks,
    uploadedBytes: session.uploaded_bytes,
    receivedChunks: parseReceivedChunks(session.received_chunks),
    errorMessage: session.error_message,
  });
});

mediaRouter.put(
  '/uploads/:uploadId/chunk',
  requireAuth,
  express.raw({ type: 'application/octet-stream', limit: '4mb' }),
  async (req: AuthenticatedRequest, res) => {
    const authUser = req.authUser!;
    const uploadId = String(req.params.uploadId || '');
    const chunkIndex = Number(req.query.index);

    const session = db
      .prepare(`SELECT * FROM upload_sessions WHERE id = ? AND user_id = ?`)
      .get(uploadId, authUser.id) as unknown as UploadSessionRow | undefined;

    if (!session) {
      res.status(404).json({ error: 'Upload session not found.' });
      return;
    }

    if (session.status !== 'in_progress') {
      res.status(409).json({ error: `Upload session is already ${session.status}.` });
      return;
    }

    if (!Number.isInteger(chunkIndex) || chunkIndex < 0 || chunkIndex >= session.total_chunks) {
      res.status(400).json({ error: 'Invalid chunk index.' });
      return;
    }

    const chunkBuf = req.body;
    if (!Buffer.isBuffer(chunkBuf) || chunkBuf.length === 0) {
      res.status(400).json({ error: 'Empty binary chunk payload.' });
      return;
    }

    const isLastChunk = chunkIndex === session.total_chunks - 1;
    const expectedSize = isLastChunk
      ? session.total_size - chunkIndex * session.chunk_size
      : session.chunk_size;

    if (chunkBuf.length !== expectedSize) {
      res.status(400).json({
        error: `Unexpected chunk size: expected ${expectedSize} bytes, received ${chunkBuf.length} bytes.`,
      });
      return;
    }

    ensureUserMediaDirectories(authUser.id);
    const partPath = resolveSafeStoragePath('temp', 'uploads', authUser.id, `${session.id}.part`);
    const offset = chunkIndex * session.chunk_size;

    let fileHandle: fs.promises.FileHandle | null = null;
    try {
      const mode = fs.existsSync(partPath) ? 'r+' : 'w+';
      fileHandle = await fs.promises.open(partPath, mode);
      await fileHandle.write(chunkBuf, 0, chunkBuf.length, offset);
    } finally {
      if (fileHandle) {
        await fileHandle.close();
      }
    }

    const receivedSet = new Set(parseReceivedChunks(session.received_chunks));
    receivedSet.add(chunkIndex);
    const sortedChunks = Array.from(receivedSet).sort((a, b) => a - b);

    let uploadedBytes = 0;
    for (const idx of sortedChunks) {
      uploadedBytes +=
        idx === session.total_chunks - 1
          ? session.total_size - idx * session.chunk_size
          : session.chunk_size;
    }

    const nowIso = new Date().toISOString();
    db.prepare(
      `UPDATE upload_sessions
       SET received_chunks = ?, uploaded_bytes = ?, updated_at = ?
       WHERE id = ? AND user_id = ?`
    ).run(JSON.stringify(sortedChunks), uploadedBytes, nowIso, session.id, authUser.id);

    res.json({
      uploadId: session.id,
      chunkIndex,
      uploadedBytes,
      totalSize: session.total_size,
      receivedChunks: sortedChunks,
    });
  }
);

mediaRouter.post('/uploads/:uploadId/complete', requireAuth, async (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const uploadId = String(req.params.uploadId || '');

  const session = db
    .prepare(`SELECT * FROM upload_sessions WHERE id = ? AND user_id = ?`)
    .get(uploadId, authUser.id) as unknown as UploadSessionRow | undefined;

  if (!session) {
    res.status(404).json({ error: 'Upload session not found.' });
    return;
  }

  if (session.status === 'completed') {
    res.status(409).json({ error: 'Upload session was already completed.' });
    return;
  }

  const received = parseReceivedChunks(session.received_chunks);
  if (received.length !== session.total_chunks) {
    res.status(400).json({
      error: `Upload incomplete: received ${received.length} of ${session.total_chunks} chunks.`,
    });
    return;
  }

  const partPath = resolveSafeStoragePath('temp', 'uploads', authUser.id, `${session.id}.part`);
  if (!fs.existsSync(partPath)) {
    res.status(400).json({ error: 'Temporary upload data is missing on server.' });
    return;
  }

  const actualStat = fs.statSync(partPath);
  if (actualStat.size !== session.total_size) {
    safeUnlink(partPath);
    db.prepare(
      `UPDATE upload_sessions SET status = 'failed', error_message = ?, updated_at = ? WHERE id = ?`
    ).run('Uploaded byte count mismatch.', new Date().toISOString(), session.id);
    res.status(400).json({ error: 'Uploaded file size mismatch.' });
    return;
  }

  const sha256 = await computeFileSha256(partPath);

  const duplicate = db
    .prepare(
      `SELECT id, original_name FROM media_assets
       WHERE user_id = ? AND project_id = ? AND sha256 = ?`
    )
    .get(authUser.id, session.project_id, sha256) as
    | { id: string; original_name: string }
    | undefined;

  if (duplicate && duplicate.id !== session.replace_media_id) {
    safeUnlink(partPath);
    db.prepare(
      `UPDATE upload_sessions SET status = 'failed', error_message = ?, updated_at = ? WHERE id = ?`
    ).run('Duplicate file detected in project.', new Date().toISOString(), session.id);
    res.status(409).json({
      error: `Duplicate file prevented: "${duplicate.original_name}" with identical content is already in this project.`,
      duplicateMediaId: duplicate.id,
    });
    return;
  }

  const probe = await probeMediaFile(partPath, session.media_kind);
  if (!probe.valid) {
    safeUnlink(partPath);
    db.prepare(
      `UPDATE upload_sessions SET status = 'failed', error_message = ?, updated_at = ? WHERE id = ?`
    ).run(probe.error || 'Media validation failed.', new Date().toISOString(), session.id);
    res.status(400).json({ error: probe.error || 'Invalid media file.' });
    return;
  }

  const ext = getValidatedExtension(session.original_name, session.media_kind) || '';
  const mediaId = session.replace_media_id || crypto.randomUUID();
  const storedFilename = `${mediaId}${ext}`;
  ensureUserMediaDirectories(authUser.id);
  const finalPath = resolveSafeStoragePath('uploads', authUser.id, storedFilename);

  let oldAsset: MediaAssetRow | undefined;
  if (session.replace_media_id) {
    oldAsset = db
      .prepare(`SELECT * FROM media_assets WHERE id = ? AND user_id = ? AND project_id = ?`)
      .get(session.replace_media_id, authUser.id, session.project_id) as unknown as
      | MediaAssetRow
      | undefined;
  }

  // Move validated file into permanent user-isolated directory
  try {
    fs.renameSync(partPath, finalPath);
  } catch {
    fs.copyFileSync(partPath, finalPath);
    safeUnlink(partPath);
  }

  let thumbnailFilename: string | null = null;
  let proxyFilename: string | null = null;

  if (session.media_kind === 'video') {
    const thumbCandidate = `${mediaId}.jpg`;
    const thumbPath = resolveSafeStoragePath('uploads', authUser.id, 'thumbs', thumbCandidate);
    const thumbCreated = await generateVideoThumbnail(finalPath, thumbPath, probe.durationSec);
    if (thumbCreated) {
      thumbnailFilename = thumbCandidate;
    }

    if (session.generate_low_data_proxy === 1) {
      const proxyCandidate = `${mediaId}.proxy.mp4`;
      const proxyPath = resolveSafeStoragePath('uploads', authUser.id, proxyCandidate);
      const proxyCreated = await generateLowDataVideoProxy(finalPath, proxyPath);
      if (proxyCreated) {
        proxyFilename = proxyCandidate;
      }
    }
  }

  const nowIso = new Date().toISOString();

  if (oldAsset) {
    if (oldAsset.stored_filename && oldAsset.stored_filename !== storedFilename) {
      safeUnlink(resolveSafeStoragePath('uploads', authUser.id, oldAsset.stored_filename));
    }
    if (oldAsset.proxy_filename && oldAsset.proxy_filename !== proxyFilename) {
      safeUnlink(resolveSafeStoragePath('uploads', authUser.id, oldAsset.proxy_filename));
    }
    if (oldAsset.thumbnail_filename && oldAsset.thumbnail_filename !== thumbnailFilename) {
      safeUnlink(
        resolveSafeStoragePath('uploads', authUser.id, 'thumbs', oldAsset.thumbnail_filename)
      );
    }
    deleteCachedVideoAnalysisArtifacts(oldAsset.id, authUser.id);

    db.prepare(
      `UPDATE media_assets
       SET original_name = ?, stored_filename = ?, proxy_filename = ?, thumbnail_filename = ?,
           mime_type = ?, extension = ?, size_bytes = ?, duration_sec = ?, codec_name = ?,
           width = ?, height = ?, sample_rate = ?, channels = ?, sha256 = ?,
           upload_status = 'ready', updated_at = ?
       WHERE id = ? AND user_id = ?`
    ).run(
      session.original_name,
      storedFilename,
      proxyFilename,
      thumbnailFilename,
      session.mime_type,
      ext,
      session.total_size,
      probe.durationSec,
      probe.codecName,
      probe.width,
      probe.height,
      probe.sampleRate,
      probe.channels,
      sha256,
      nowIso,
      oldAsset.id,
      authUser.id
    );
  } else {
    db.prepare(
      `INSERT INTO media_assets (
         id, user_id, project_id, media_kind, original_name, stored_filename,
         proxy_filename, thumbnail_filename, mime_type, extension, size_bytes,
         duration_sec, codec_name, width, height, sample_rate, channels, sha256,
         upload_status, created_at, updated_at
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ready', ?, ?)`
    ).run(
      mediaId,
      authUser.id,
      session.project_id,
      session.media_kind,
      session.original_name,
      storedFilename,
      proxyFilename,
      thumbnailFilename,
      session.mime_type,
      ext,
      session.total_size,
      probe.durationSec,
      probe.codecName,
      probe.width,
      probe.height,
      probe.sampleRate,
      probe.channels,
      sha256,
      nowIso,
      nowIso
    );
  }

  db.prepare(`UPDATE upload_sessions SET status = 'completed', updated_at = ? WHERE id = ?`).run(
    nowIso,
    session.id
  );

  const saved = db
    .prepare(`SELECT * FROM media_assets WHERE id = ? AND user_id = ?`)
    .get(mediaId, authUser.id) as unknown as MediaAssetRow;

  res.status(oldAsset ? 200 : 201).json({ media: mapMediaAsset(saved) });
});

mediaRouter.delete('/uploads/:uploadId', requireAuth, (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const uploadId = String(req.params.uploadId || '');

  const session = db
    .prepare(`SELECT id FROM upload_sessions WHERE id = ? AND user_id = ?`)
    .get(uploadId, authUser.id) as { id: string } | undefined;

  if (!session) {
    res.status(404).json({ error: 'Upload session not found.' });
    return;
  }

  const partPath = resolveSafeStoragePath('temp', 'uploads', authUser.id, `${uploadId}.part`);
  safeUnlink(partPath);
  db.prepare(`UPDATE upload_sessions SET status = 'cancelled', updated_at = ? WHERE id = ?`).run(
    new Date().toISOString(),
    uploadId
  );

  res.json({ ok: true });
});

mediaRouter.get('/', requireAuth, (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const projectId = typeof req.query.projectId === 'string' ? req.query.projectId.trim() : '';
  const kindFilter =
    req.query.kind === 'audio' || req.query.kind === 'video' ? req.query.kind : '';
  const searchQuery = typeof req.query.q === 'string' ? req.query.q.trim().toLowerCase() : '';
  const sortBy = typeof req.query.sort === 'string' ? req.query.sort : 'newest';

  if (!projectId) {
    res.status(400).json({ error: 'projectId query parameter is required.' });
    return;
  }

  const project = db
    .prepare(`SELECT id FROM projects WHERE id = ? AND user_id = ?`)
    .get(projectId, authUser.id);
  if (!project) {
    res.status(404).json({ error: 'Project not found.' });
    return;
  }

  const rows = db
    .prepare(`SELECT * FROM media_assets WHERE user_id = ? AND project_id = ?`)
    .all(authUser.id, projectId) as unknown as MediaAssetRow[];

  const filtered = rows.filter((row) => {
    if (kindFilter && row.media_kind !== kindFilter) return false;
    if (searchQuery && !row.original_name.toLowerCase().includes(searchQuery)) return false;
    return true;
  });

  filtered.sort((a, b) => {
    switch (sortBy) {
      case 'oldest':
        return a.created_at.localeCompare(b.created_at);
      case 'name':
        return a.original_name.localeCompare(b.original_name);
      case 'size':
        return b.size_bytes - a.size_bytes;
      case 'duration':
        return b.duration_sec - a.duration_sec;
      case 'newest':
      default:
        return b.created_at.localeCompare(a.created_at);
    }
  });

  res.json({ media: filtered.map(mapMediaAsset) });
});

mediaRouter.get('/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const mediaId = String(req.params.id || '');

  const row = db
    .prepare(`SELECT * FROM media_assets WHERE id = ? AND user_id = ?`)
    .get(mediaId, authUser.id) as unknown as MediaAssetRow | undefined;

  if (!row) {
    res.status(404).json({ error: 'Media asset not found.' });
    return;
  }

  res.json({ media: mapMediaAsset(row) });
});

mediaRouter.post('/:id/playback-grant', requireAuth, (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const mediaId = String(req.params.id || '');

  const row = db
    .prepare(`SELECT id, thumbnail_filename, proxy_filename FROM media_assets WHERE id = ? AND user_id = ?`)
    .get(mediaId, authUser.id) as
    | { id: string; thumbnail_filename: string | null; proxy_filename: string | null }
    | undefined;

  if (!row) {
    res.status(404).json({ error: 'Media asset not found.' });
    return;
  }

  const expMs = Date.now() + 10 * 60 * 1000;
  const streamSig = createPlaybackSignature(mediaId, authUser.id, expMs, 'stream');
  const thumbSig = createPlaybackSignature(mediaId, authUser.id, expMs, 'thumbnail');

  const qs = `uid=${encodeURIComponent(authUser.id)}&exp=${expMs}`;
  res.json({
    expiresAt: new Date(expMs).toISOString(),
    streamUrl: `/api/media/${encodeURIComponent(mediaId)}/stream?${qs}&sig=${streamSig}`,
    proxyStreamUrl: row.proxy_filename
      ? `/api/media/${encodeURIComponent(mediaId)}/stream?${qs}&sig=${streamSig}&quality=proxy`
      : null,
    thumbnailUrl: row.thumbnail_filename
      ? `/api/media/${encodeURIComponent(mediaId)}/thumbnail?${qs}&sig=${thumbSig}`
      : null,
  });
});

mediaRouter.get('/:id/stream', (req, res) => {
  const mediaId = String(req.params.id || '');
  const authorizedUserId = verifyPlaybackGrantOrBearer(req, mediaId, 'stream');
  if (!authorizedUserId) {
    res.status(401).json({ error: 'Authentication or valid playback grant required.' });
    return;
  }

  const row = db
    .prepare(`SELECT * FROM media_assets WHERE id = ? AND user_id = ?`)
    .get(mediaId, authorizedUserId) as unknown as MediaAssetRow | undefined;

  if (!row) {
    res.status(404).json({ error: 'Media asset not found.' });
    return;
  }

  const useProxy = req.query.quality === 'proxy' && Boolean(row.proxy_filename);
  const filename = useProxy && row.proxy_filename ? row.proxy_filename : row.stored_filename;
  const filePath = resolveSafeStoragePath('uploads', authorizedUserId, filename);

  if (!fs.existsSync(filePath)) {
    res.status(404).json({ error: 'Media file not found on storage.' });
    return;
  }

  const stat = fs.statSync(filePath);
  const fileSize = stat.size;
  const contentType = useProxy ? 'video/mp4' : row.mime_type;

  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Content-Type', contentType);
  res.setHeader('Cache-Control', 'private, max-age=300');

  const rangeHeader = req.headers.range;
  if (rangeHeader) {
    const match = /^bytes=(\d*)-(\d*)$/.exec(rangeHeader.trim());
    if (!match) {
      res.status(416).setHeader('Content-Range', `bytes */${fileSize}`).end();
      return;
    }

    const start = match[1] ? Number(match[1]) : 0;
    const end = match[2] ? Math.min(Number(match[2]), fileSize - 1) : fileSize - 1;

    if (!Number.isInteger(start) || !Number.isInteger(end) || start > end || start >= fileSize) {
      res.status(416).setHeader('Content-Range', `bytes */${fileSize}`).end();
      return;
    }

    res.status(206);
    res.setHeader('Content-Range', `bytes ${start}-${end}/${fileSize}`);
    res.setHeader('Content-Length', String(end - start + 1));

    const stream = fs.createReadStream(filePath, { start, end });
    stream.on('error', () => {
      if (!res.headersSent) res.status(500).end();
    });
    stream.pipe(res);
    return;
  }

  res.status(200);
  res.setHeader('Content-Length', String(fileSize));
  const stream = fs.createReadStream(filePath);
  stream.on('error', () => {
    if (!res.headersSent) res.status(500).end();
  });
  stream.pipe(res);
});

mediaRouter.get('/:id/thumbnail', (req, res) => {
  const mediaId = String(req.params.id || '');
  const authorizedUserId = verifyPlaybackGrantOrBearer(req, mediaId, 'thumbnail');
  if (!authorizedUserId) {
    res.status(401).json({ error: 'Authentication or valid thumbnail grant required.' });
    return;
  }

  const row = db
    .prepare(`SELECT thumbnail_filename FROM media_assets WHERE id = ? AND user_id = ?`)
    .get(mediaId, authorizedUserId) as { thumbnail_filename: string | null } | undefined;

  if (!row || !row.thumbnail_filename) {
    res.status(404).json({ error: 'Thumbnail not available.' });
    return;
  }

  const thumbPath = resolveSafeStoragePath(
    'uploads',
    authorizedUserId,
    'thumbs',
    row.thumbnail_filename
  );
  if (!fs.existsSync(thumbPath)) {
    res.status(404).json({ error: 'Thumbnail file missing.' });
    return;
  }

  res.setHeader('Content-Type', 'image/jpeg');
  res.setHeader('Cache-Control', 'private, max-age=300');
  fs.createReadStream(thumbPath).pipe(res);
});

mediaRouter.delete('/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const mediaId = String(req.params.id || '');

  const row = db
    .prepare(`SELECT * FROM media_assets WHERE id = ? AND user_id = ?`)
    .get(mediaId, authUser.id) as unknown as MediaAssetRow | undefined;

  if (!row) {
    res.status(404).json({ error: 'Media asset not found.' });
    return;
  }

  safeUnlink(resolveSafeStoragePath('uploads', authUser.id, row.stored_filename));
  if (row.proxy_filename) {
    safeUnlink(resolveSafeStoragePath('uploads', authUser.id, row.proxy_filename));
  }
  if (row.thumbnail_filename) {
    safeUnlink(resolveSafeStoragePath('uploads', authUser.id, 'thumbs', row.thumbnail_filename));
  }
  deleteCachedVideoAnalysisArtifacts(mediaId, authUser.id);

  db.prepare(`DELETE FROM media_assets WHERE id = ? AND user_id = ?`).run(mediaId, authUser.id);
  res.json({ ok: true });
});
