import crypto from 'node:crypto';
import { Router } from 'express';
import {
  createSession,
  hashPassword,
  mapUserRow,
  pruneExpiredSessions,
  requireAuth,
  verifyPassword,
} from '../auth.ts';
import type { AuthenticatedRequest } from '../auth.ts';
import { db } from '../db.ts';

interface RawUserRow {
  id: string;
  email: string;
  display_name: string;
  password_hash: string;
  role: string;
  low_data_mode: number;
  created_at: string;
  updated_at: string;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const authRouter = Router();

authRouter.post('/register', (req, res) => {
  pruneExpiredSessions();

  const body = req.body as Record<string, unknown>;
  const email = typeof body?.email === 'string' ? body.email.trim().toLowerCase() : '';
  const displayName = typeof body?.displayName === 'string' ? body.displayName.trim() : '';
  const password = typeof body?.password === 'string' ? body.password : '';
  const lowDataMode = Boolean(body?.lowDataMode);

  if (!EMAIL_RE.test(email) || email.length > 160) {
    res.status(400).json({ error: 'Please enter a valid email address.' });
    return;
  }
  if (displayName.length < 2 || displayName.length > 60) {
    res.status(400).json({ error: 'Display name must be between 2 and 60 characters.' });
    return;
  }
  if (password.length < 8 || password.length > 128) {
    res.status(400).json({ error: 'Password must be between 8 and 128 characters.' });
    return;
  }

  const existing = db.prepare(`SELECT id FROM users WHERE email = ?`).get(email);
  if (existing) {
    res.status(409).json({ error: 'An account with this email already exists.' });
    return;
  }

  const userId = crypto.randomUUID();
  const passwordHash = hashPassword(password);
  const nowIso = new Date().toISOString();

  db.prepare(
    `INSERT INTO users (id, email, display_name, password_hash, role, low_data_mode, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'creator', ?, ?, ?)`
  ).run(userId, email, displayName, passwordHash, lowDataMode ? 1 : 0, nowIso, nowIso);

  const userRow = db
    .prepare(
      `SELECT id, email, display_name, password_hash, role, low_data_mode, created_at, updated_at
       FROM users WHERE id = ?`
    )
    .get(userId) as unknown as RawUserRow;

  const session = createSession(userId);
  res.status(201).json({
    user: mapUserRow(userRow),
    token: session.token,
    expiresAt: session.expiresAt,
  });
});

authRouter.post('/login', (req, res) => {
  pruneExpiredSessions();

  const body = req.body as Record<string, unknown>;
  const email = typeof body?.email === 'string' ? body.email.trim().toLowerCase() : '';
  const password = typeof body?.password === 'string' ? body.password : '';

  if (!EMAIL_RE.test(email) || !password) {
    res.status(400).json({ error: 'Email and password are required.' });
    return;
  }

  const userRow = db
    .prepare(
      `SELECT id, email, display_name, password_hash, role, low_data_mode, created_at, updated_at
       FROM users WHERE email = ?`
    )
    .get(email) as RawUserRow | undefined;

  if (!userRow || !verifyPassword(password, userRow.password_hash)) {
    res.status(401).json({ error: 'Invalid email or password.' });
    return;
  }

  const session = createSession(userRow.id);
  res.json({
    user: mapUserRow(userRow),
    token: session.token,
    expiresAt: session.expiresAt,
  });
});

authRouter.post('/logout', requireAuth, (req: AuthenticatedRequest, res) => {
  if (req.authTokenHash) {
    db.prepare(`DELETE FROM sessions WHERE token_hash = ?`).run(req.authTokenHash);
  }
  res.json({ ok: true });
});

authRouter.get('/me', requireAuth, (req: AuthenticatedRequest, res) => {
  res.json({ user: req.authUser });
});

authRouter.patch('/preferences', requireAuth, (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const body = req.body as Record<string, unknown>;

  let nextDisplayName = authUser.displayName;
  if (body.displayName !== undefined) {
    if (typeof body.displayName !== 'string') {
      res.status(400).json({ error: 'Invalid display name.' });
      return;
    }
    const trimmed = body.displayName.trim();
    if (trimmed.length < 2 || trimmed.length > 60) {
      res.status(400).json({ error: 'Display name must be between 2 and 60 characters.' });
      return;
    }
    nextDisplayName = trimmed;
  }

  const nextLowDataMode =
    body.lowDataMode !== undefined ? Boolean(body.lowDataMode) : authUser.lowDataMode;

  const updatedAt = new Date().toISOString();
  db.prepare(
    `UPDATE users SET display_name = ?, low_data_mode = ?, updated_at = ? WHERE id = ?`
  ).run(nextDisplayName, nextLowDataMode ? 1 : 0, updatedAt, authUser.id);

  const row = db
    .prepare(
      `SELECT id, email, display_name, password_hash, role, low_data_mode, created_at, updated_at
       FROM users WHERE id = ?`
    )
    .get(authUser.id) as unknown as RawUserRow;

  res.json({ user: mapUserRow(row) });
});

authRouter.post('/change-password', requireAuth, (req: AuthenticatedRequest, res) => {
  const authUser = req.authUser!;
  const body = req.body as Record<string, unknown>;
  const currentPassword = typeof body?.currentPassword === 'string' ? body.currentPassword : '';
  const newPassword = typeof body?.newPassword === 'string' ? body.newPassword : '';

  if (!currentPassword || newPassword.length < 8 || newPassword.length > 128) {
    res.status(400).json({ error: 'Provide your current password and a new password (8–128 chars).' });
    return;
  }

  const row = db
    .prepare(`SELECT password_hash FROM users WHERE id = ?`)
    .get(authUser.id) as { password_hash: string } | undefined;

  if (!row || !verifyPassword(currentPassword, row.password_hash)) {
    res.status(401).json({ error: 'Current password is incorrect.' });
    return;
  }

  const newHash = hashPassword(newPassword);
  const nowIso = new Date().toISOString();
  db.prepare(`UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?`).run(
    newHash,
    nowIso,
    authUser.id
  );

  if (req.authTokenHash) {
    db.prepare(`DELETE FROM sessions WHERE user_id = ? AND token_hash != ?`).run(
      authUser.id,
      req.authTokenHash
    );
  }

  res.json({ ok: true });
});
