import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import { config } from './config.ts';
import { db } from './db.ts';

export interface AuthenticatedUser {
  id: string;
  email: string;
  displayName: string;
  role: 'creator' | 'admin';
  lowDataMode: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AuthenticatedRequest extends Request {
  authUser?: AuthenticatedUser;
  authTokenHash?: string;
}

interface UserRow {
  id: string;
  email: string;
  display_name: string;
  password_hash: string;
  role: string;
  low_data_mode: number;
  created_at: string;
  updated_at: string;
}

interface SessionUserRow extends UserRow {
  expires_at: string;
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, expectedHex] = parts;
  if (!salt || !expectedHex) return false;
  const derived = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(expectedHex, 'hex');
  if (derived.length !== expected.length) return false;
  return crypto.timingSafeEqual(derived, expected);
}

export function hashToken(rawToken: string): string {
  return crypto.createHash('sha256').update(rawToken).digest('hex');
}

export function createSession(userId: string): { token: string; expiresAt: string } {
  const rawToken = crypto.randomBytes(32).toString('hex');
  const tokenHash = hashToken(rawToken);
  const sessionId = crypto.randomUUID();
  const now = new Date();
  const expiresAt = new Date(now.getTime() + config.sessionTtlMs).toISOString();

  db.prepare(
    `INSERT INTO sessions (id, token_hash, user_id, expires_at, created_at)
     VALUES (?, ?, ?, ?, ?)`
  ).run(sessionId, tokenHash, userId, expiresAt, now.toISOString());

  return { token: rawToken, expiresAt };
}

export function pruneExpiredSessions(): void {
  const nowIso = new Date().toISOString();
  db.prepare(`DELETE FROM sessions WHERE expires_at <= ?`).run(nowIso);
}

export function mapUserRow(row: UserRow): AuthenticatedUser {
  return {
    id: row.id,
    email: row.email,
    displayName: row.display_name,
    role: row.role === 'admin' ? 'admin' : 'creator',
    lowDataMode: row.low_data_mode === 1,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }

  const rawToken = header.slice('Bearer '.length).trim();
  if (!rawToken || rawToken.length < 32) {
    res.status(401).json({ error: 'Invalid session token.' });
    return;
  }

  const tokenHash = hashToken(rawToken);
  const row = db
    .prepare(
      `SELECT u.id, u.email, u.display_name, u.password_hash, u.role, u.low_data_mode, u.created_at, u.updated_at, s.expires_at
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = ?`
    )
    .get(tokenHash) as SessionUserRow | undefined;

  if (!row) {
    res.status(401).json({ error: 'Session not found or expired.' });
    return;
  }

  if (Date.parse(row.expires_at) <= Date.now()) {
    db.prepare(`DELETE FROM sessions WHERE token_hash = ?`).run(tokenHash);
    res.status(401).json({ error: 'Session expired. Please sign in again.' });
    return;
  }

  req.authUser = mapUserRow(row);
  req.authTokenHash = tokenHash;
  next();
}
