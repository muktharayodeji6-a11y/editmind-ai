import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const rawPort = Number(process.env.PORT || 3000);
const rawSessionTtlHours = Number(process.env.SESSION_TTL_HOURS || 24);
const rawTempTtlHours = Number(process.env.TEMP_FILE_TTL_HOURS || 12);

const baseDataDir = path.resolve(process.cwd(), process.env.EDITMIND_DATA_DIR || './data');

export const config = {
  port: Number.isFinite(rawPort) && rawPort > 0 ? rawPort : 3000,
  isProduction: process.env.NODE_ENV === 'production',
  dataDir: baseDataDir,
  dbPath: path.join(baseDataDir, 'editmind.db'),
  uploadsDir: path.join(baseDataDir, 'uploads'),
  tempDir: path.join(baseDataDir, 'temp'),
  exportsDir: path.join(baseDataDir, 'exports'),
  sessionTtlMs: (Number.isFinite(rawSessionTtlHours) && rawSessionTtlHours > 0 ? rawSessionTtlHours : 24) * 3600 * 1000,
  tempFileTtlMs: (Number.isFinite(rawTempTtlHours) && rawTempTtlHours > 0 ? rawTempTtlHours : 12) * 3600 * 1000,
  maxAudioBytes: 150 * 1024 * 1024,
  maxVideoBytes: 500 * 1024 * 1024,
  maxChunkBytes: 4 * 1024 * 1024,
  mediaSigningSecret: process.env.MEDIA_SIGNING_SECRET || crypto.randomBytes(32).toString('hex'),
};

export function ensureStorageDirectories(): void {
  for (const dir of [config.dataDir, config.uploadsDir, config.tempDir, config.exportsDir]) {
    fs.mkdirSync(dir, { recursive: true });
  }
}
