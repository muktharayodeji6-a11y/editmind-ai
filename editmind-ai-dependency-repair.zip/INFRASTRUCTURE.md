# EDITMIND AI — Infrastructure & Architecture Specification

## 1. Inspected Runtime Environment

Observed inside the active Google AI Studio / Cloud Run container:

- **Runtime**: Node.js `v22.23.2` with native `node:sqlite` (`DatabaseSync`) and native TypeScript type-stripping.
- **Media & Rendering Toolchain**:
  - `ffmpeg` `4.4.2` (`/usr/bin/ffmpeg`) compiled with `libx264`, `libx265`, `libmp3lame`, `libopus`, `libvpx`, `libaom`, `libvidstab`, `chromaprint`, `frei0r`, `ladspa`.
  - `ffprobe` (`/usr/bin/ffprobe`) for media metadata inspection and validation.
- **Python Runtime**: `python3` `3.11.2` (`/usr/bin/python3`) available for future signal-processing / ML workers (no external Python audio/CV packages pre-installed yet).
- **Filesystem**: Container disk currently exposes ~378 GB free space, **but Cloud Run container filesystems are ephemeral across container restarts/redeploys**.

## 2. Architecture Decisions

### Client vs. Server Split
- **Lightweight Client (Web / Android WebView or Mobile Browser)**:
  - Renders the workspace, handles user authentication, project configuration, media selection, Low-Data Mode preferences, playback previews, and explicit export downloads.
  - Performs **zero** heavy AI inference, **zero** video rendering, and **zero** automatic model downloads.
- **Server-Side Backend (Express + Modular Engine)**:
  - Handles authentication (`scrypt` password hashing + SHA-256 hashed Bearer sessions), project persistence (`node:sqlite`), path-confined storage management, temporary file TTL sweeps, and (in Milestones 2–7) resumable uploads, audio/video analysis, automatic cut synthesis, and FFmpeg MP4 rendering.

### Independent Editing Engine Boundaries (`server/engine/`)
All editing intelligence is decoupled behind clean interfaces so models and algorithms remain replaceable without rewriting the platform:
1. `BeatIntelligenceModule` — BPM, beat grid, downbeats, tempo shifts, energy peaks (Milestone 3).
2. `MusicIntelligenceModule` — Intro, verse, chorus, build-up, drop, outro segmentation (Milestone 3).
3. `VideoIntelligenceModule` — Shot/scene boundaries, motion intensity, camera stability, quality scoring (Milestone 4).
4. `EditingIntelligenceModule` — Cut point placement, clip selection, pacing, music sync (Milestone 5).
5. `TransitionIntelligenceModule` — Rhythm-aligned cuts, crossfades, whips, dip-to-black selection (Milestone 5).
6. `QualityIntelligenceModule` — A/V drift verification, frame integrity, MP4 validation prior to export completion (Milestone 7).

Gemini API or other external AI APIs are **strictly optional** and never required for core editing operation.

## 3. Mobile Data Optimization Strategy

1. **Low-Data Mode**: Persisted per user and per project; reduces preview bitrate, disables speculative prefetching, and enables optional pre-upload compression guidance (while clearly warning when compression trades off source quality).
2. **No Automatic Media Uploads / Sync**: Media only transfers when the user explicitly initiates an upload or export download.
3. **Resumable Chunked Uploads (Milestone 2)**: Designed to resume interrupted mobile transfers without re-sending completed byte ranges.
4. **On-Demand Export Downloads (Milestone 7)**: Completed MP4s remain on the server until explicitly requested by the user.

## 4. Honest Infrastructure Limitations & Production Path

In the current AI Studio preview container:
- **Ephemeral Disk**: SQLite (`./data/editmind.db`) and local storage directories (`./data/uploads`, `./data/temp`, `./data/exports`) live on container-local disk. For durable multi-instance production hosting, replace local disk with **S3-compatible object storage** (e.g., self-hosted MinIO or Cloudflare R2) and **PostgreSQL**.
- **Single-Node Concurrency**: Heavy FFmpeg renders and Python audio/CV analysis in future milestones are CPU-bound. Production deployment should offload jobs via a **Redis + BullMQ** worker queue onto dedicated compute nodes rather than running long renders inside the web request container.
- **Bandwidth Reality**: Remote server rendering requires uploading source clips and downloading the finished MP4. Low-Data Mode minimizes overhead and avoids duplicate transfers, but cannot eliminate source/export transfer bytes.

## 5. Milestone Progression

- **Milestone 1 — Implemented**: Project foundation, authentication, project CRUD, capability inspector and infrastructure documentation.
- **Milestone 2 — Implemented in source**: Resumable chunked media uploads, FFprobe validation, media library, playback and low-data proxy support.
- **Milestone 3 — Implemented in source; validation outstanding**: Server-side audio analysis, waveform generation, BPM/beat/downbeat tracking, tempo changes and music-section classification.
- **Milestone 4 — Implemented in source; real-world validation outstanding**: Video metadata, scene/transition detection, motion/quality scoring and scene thumbnails.
- **Milestone 5 — Planned**: Independent automatic editing and transition engine.
- **Milestone 6 — Planned**: Interactive multi-track timeline, waveform sync, clip trimming and undo/redo.
- **Milestone 7 — Planned**: Server-side FFmpeg MP4 rendering pipeline, progress tracking and validated downloads.
- **Milestone 8 — Planned**: End-to-end QA, security hardening, performance tuning and Android client optimization.

**Current source-code checkpoint:** Milestones 1–4 have implementation files in this repository. Their presence is not equivalent to independent verification or production readiness. The build and regression suite must be run in an environment with dependencies installed; M3/M4 accuracy requires representative ground-truth media.
