import { useEffect, useState } from 'react';
import { RefreshCw, Server } from 'lucide-react';
import { fetchSystemCapabilities } from '../lib/api';
import type { SystemCapabilities } from '../types/studio';

function formatBytes(bytes: number | null): string {
  if (bytes === null) return 'Unavailable';
  const gb = bytes / (1024 * 1024 * 1024);
  return `${gb.toFixed(1)} GB`;
}

export function ArchitectureView() {
  const [data, setData] = useState<SystemCapabilities | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function loadCapabilities() {
    setLoading(true);
    setError(null);
    try {
      const caps = await fetchSystemCapabilities();
      setData(caps);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to probe server capabilities.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadCapabilities();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="font-display text-2xl font-bold text-white tracking-tight">
            Server Architecture & Engine Modules
          </h1>
          <p className="text-sm text-slate-400">
            Live probe of backend binaries, storage boundaries, and independent editing modules.
          </p>
        </div>

        <button
          type="button"
          onClick={() => void loadCapabilities()}
          disabled={loading}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg border border-white/10 text-slate-200 hover:bg-white/[0.06] disabled:opacity-60 transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} aria-hidden="true" />
          <span>Refresh Probe</span>
        </button>
      </div>

      {error && (
        <div role="alert" className="p-4 rounded-lg bg-red-500/10 border border-red-500/30 text-sm text-red-200">
          {error}
        </div>
      )}

      {loading && !data ? (
        <div className="space-y-4" aria-busy="true">
          <div className="h-36 rounded-xl bg-[#11141B] border border-white/[0.06] animate-pulse" />
          <div className="h-64 rounded-xl bg-[#11141B] border border-white/[0.06] animate-pulse" />
        </div>
      ) : data ? (
        <div className="space-y-6">
          <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#11141B] border border-white/[0.08] rounded-xl p-4 space-y-1">
              <div className="text-xs text-slate-400">Backend Runtime</div>
              <div className="font-mono-tabular text-sm font-semibold text-white">
                Node {data.runtime.nodeVersion}
              </div>
              <div className="text-xs text-slate-500">
                {data.runtime.platform} · {data.runtime.arch}
              </div>
            </div>

            <div className="bg-[#11141B] border border-white/[0.08] rounded-xl p-4 space-y-1">
              <div className="text-xs text-slate-400">Persistence Engine</div>
              <div className="font-mono-tabular text-sm font-semibold text-white">
                {data.runtime.databaseEngine}
              </div>
              <div className="text-xs text-slate-500">Local parameterized database</div>
            </div>

            <div className="bg-[#11141B] border border-white/[0.08] rounded-xl p-4 space-y-1">
              <div className="text-xs text-slate-400">Available Container Disk</div>
              <div className="font-mono-tabular text-sm font-semibold text-white">
                {formatBytes(data.storage.availableBytes)}
              </div>
              <div className="text-xs text-slate-500">
                of {formatBytes(data.storage.totalBytes)} total
              </div>
            </div>

            <div className="bg-[#11141B] border border-white/[0.08] rounded-xl p-4 space-y-1">
              <div className="text-xs text-slate-400">External AI Requirement</div>
              <div className="font-mono-tabular text-sm font-semibold text-emerald-400">
                Independent Core
              </div>
              <div className="text-xs text-slate-500">Gemini API not mandatory</div>
            </div>
          </section>

          <section className="bg-[#11141B] border border-white/[0.08] rounded-xl p-5 space-y-4">
            <div className="flex items-center gap-2">
              <Server className="w-4 h-4 text-[#E5A93C]" aria-hidden="true" />
              <h2 className="font-display text-base font-semibold text-white">
                Installed Media & Worker Binaries
              </h2>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-white/[0.08] text-slate-400">
                    <th className="py-2.5 pr-4 font-medium">Binary</th>
                    <th className="py-2.5 pr-4 font-medium">Availability</th>
                    <th className="py-2.5 font-medium">Detected Version</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.06]">
                  {data.binaries.map((bin) => (
                    <tr key={bin.name}>
                      <td className="py-3 pr-4 font-mono-tabular font-semibold text-white">
                        {bin.name}
                      </td>
                      <td className="py-3 pr-4 font-mono-tabular">
                        <span className={bin.available ? 'text-emerald-400' : 'text-amber-400'}>
                          {bin.available ? 'Available' : 'Not Found'}
                        </span>
                      </td>
                      <td className="py-3 font-mono-tabular text-slate-300">
                        {bin.version || '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-3.5 rounded-lg bg-[#0A0C10] border border-amber-500/25 text-xs text-amber-200/90 leading-relaxed">
              <strong className="font-semibold text-amber-200 block mb-0.5">
                Infrastructure Transparency Notice
              </strong>
              {data.storage.ephemeralWarning}
            </div>
          </section>

          <section className="bg-[#11141B] border border-white/[0.08] rounded-xl p-5 space-y-4">
            <div className="space-y-1">
              <h2 className="font-display text-base font-semibold text-white">
                Independent Editing Engine Modules
              </h2>
              <p className="text-xs text-slate-400">
                {data.externalAiPolicy.coreEngineIndependence}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {data.engineModules.map((mod) => (
                <div
                  key={mod.id}
                  className="p-4 rounded-lg bg-[#0A0C10] border border-white/[0.06] space-y-2"
                >
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-display text-sm font-semibold text-white">
                      {mod.name}
                    </h3>
                    <span className="font-mono-tabular text-xs text-slate-400">
                      Milestone {mod.milestoneTarget} · {mod.status === 'active' ? 'Active' : 'Planned'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{mod.summary}</p>
                  <div className="text-[11px] text-slate-400">
                    <span className="text-slate-500">Implementation:</span> {mod.provider}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Outputs: {mod.outputs.join(' · ')}
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      ) : null}
    </div>
  );
}
