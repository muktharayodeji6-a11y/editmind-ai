import { useState } from 'react';
import { Film, Lock, Server, Smartphone } from 'lucide-react';
import { loginAccount, registerAccount } from '../lib/api';
import type { User } from '../types/studio';

interface AuthPortalProps {
  onAuthenticated: (user: User) => void;
}

export function AuthPortal({ onAuthenticated }: AuthPortalProps) {
  const [mode, setMode] = useState<'login' | 'register'>('register');
  const [email, setEmail] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');
  const [lowDataMode, setLowDataMode] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      if (mode === 'register') {
        const res = await registerAccount({
          email,
          displayName,
          password,
          lowDataMode,
        });
        onAuthenticated(res.user);
      } else {
        const res = await loginAccount({ email, password });
        onAuthenticated(res.user);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#0A0C10] text-[#F1F5F9] flex flex-col justify-between">
      <header className="border-b border-white/[0.08] px-6 py-4 flex items-center justify-between gap-8 max-w-7xl w-full mx-auto">
        <span className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0">
          EDITMIND AI
        </span>
        <nav className="hidden md:flex items-center gap-6 text-sm text-slate-400">
          <a href="#architecture" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Architecture
          </a>
          <a href="#mobile-budget" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Mobile Data
          </a>
          <a href="#milestone-scope" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Workspace
          </a>
        </nav>
        <button
          type="button"
          onClick={() => {
            setMode(mode === 'login' ? 'register' : 'login');
            setError(null);
          }}
          className="px-4 py-2 text-xs font-medium rounded-md border border-white/15 text-slate-200 hover:bg-white/[0.06] transition-colors whitespace-nowrap shrink-0"
        >
          {mode === 'login' ? 'Create Account' : 'Sign In'}
        </button>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-10 lg:py-16 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-stretch">
        <section className="lg:col-span-7 flex flex-col justify-between space-y-8">
          <div className="space-y-5">
            <p className="text-xs font-medium text-[#E5A93C] tracking-wide">
              Server-Powered Editing Workspace
            </p>
            <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white leading-[1.12] max-w-2xl">
              Independent server-side music video editing infrastructure.
            </h1>
            <p className="text-base text-slate-300 leading-relaxed max-w-xl">
              EDITMIND AI separates lightweight mobile control from server-side analysis and FFmpeg rendering.
              Create an account to manage editing projects, configure export geometry, and inspect active server capabilities.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 pt-4 border-t border-white/[0.08]">
            <div id="architecture" className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-semibold text-white">
                <Server className="w-4 h-4 text-[#E5A93C] shrink-0" aria-hidden="true" />
                <span>Server Execution</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Audio beat tracking, scene detection, and MP4 rendering stay on the backend rather than draining phone battery.
              </p>
            </div>

            <div id="mobile-budget" className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-semibold text-white">
                <Smartphone className="w-4 h-4 text-[#E5A93C] shrink-0" aria-hidden="true" />
                <span>Bandwidth Discipline</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Low-Data Mode prevents automatic uploads, avoids background sync, and downloads finished exports only on request.
              </p>
            </div>

            <div id="milestone-scope" className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-semibold text-white">
                <Film className="w-4 h-4 text-[#E5A93C] shrink-0" aria-hidden="true" />
                <span>Modular Engine</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Independent beat, music, video, editing, transition, and quality modules built without mandatory commercial AI APIs.
              </p>
            </div>
          </div>
        </section>

        <section className="lg:col-span-5 flex flex-col justify-center">
          <div className="bg-[#11141B] border border-white/[0.08] rounded-xl p-6 sm:p-8 space-y-6">
            <div className="flex items-center gap-1 p-1 bg-[#0A0C10] border border-white/[0.06] rounded-lg">
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setError(null);
                }}
                className={`flex-1 py-2.5 px-3 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  mode === 'register'
                    ? 'bg-[#171B24] text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Create Account
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError(null);
                }}
                className={`flex-1 py-2.5 px-3 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  mode === 'login'
                    ? 'bg-[#171B24] text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Sign In
              </button>
            </div>

            <div className="space-y-1">
              <h2 className="font-display text-xl font-semibold text-white">
                {mode === 'register' ? 'Create Studio Account' : 'Sign In to Studio'}
              </h2>
              <p className="text-xs text-slate-400">
                {mode === 'register'
                  ? 'Accounts are stored securely on the server with scrypt password hashing.'
                  : 'Access your persisted editing projects and server workspace.'}
              </p>
            </div>

            {error && (
              <div
                role="alert"
                className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-200"
              >
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'register' && (
                <div className="space-y-1.5">
                  <label htmlFor="auth-display-name" className="block text-xs font-medium text-slate-300">
                    Display Name
                  </label>
                  <input
                    id="auth-display-name"
                    type="text"
                    required
                    minLength={2}
                    maxLength={60}
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="Alex Rivera"
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white placeholder:text-slate-500 focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>
              )}

              <div className="space-y-1.5">
                <label htmlFor="auth-email" className="block text-xs font-medium text-slate-300">
                  Email Address
                </label>
                <input
                  id="auth-email"
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="editor@studio.example"
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white placeholder:text-slate-500 focus:outline-none focus:border-[#E5A93C]"
                />
              </div>

              <div className="space-y-1.5">
                <label htmlFor="auth-password" className="block text-xs font-medium text-slate-300">
                  Password
                </label>
                <input
                  id="auth-password"
                  type="password"
                  required
                  minLength={8}
                  maxLength={128}
                  autoComplete={mode === 'register' ? 'new-password' : 'current-password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 8 characters"
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white placeholder:text-slate-500 focus:outline-none focus:border-[#E5A93C]"
                />
              </div>

              {mode === 'register' && (
                <label className="flex items-start gap-3 p-3 rounded-lg bg-[#0A0C10] border border-white/[0.06] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={lowDataMode}
                    onChange={(e) => setLowDataMode(e.target.checked)}
                    className="mt-0.5 h-4 w-4 rounded border-white/20 accent-[#E5A93C]"
                  />
                  <span className="text-xs text-slate-300 leading-relaxed">
                    <strong className="font-medium text-white block">Enable Low-Data Mode by default</strong>
                    Minimizes preview bandwidth and prompts before large mobile transfers.
                  </span>
                </label>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 px-4 text-sm font-semibold rounded-lg bg-[#E5A93C] text-[#0A0C10] hover:bg-[#eab654] disabled:opacity-60 transition-colors flex items-center justify-center gap-2 min-h-[44px]"
              >
                <Lock className="w-4 h-4" aria-hidden="true" />
                <span>
                  {submitting
                    ? mode === 'register'
                      ? 'Creating Account...'
                      : 'Signing In...'
                    : mode === 'register'
                    ? 'Create Account & Enter Studio'
                    : 'Sign In to Studio'}
                </span>
              </button>
            </form>
          </div>
        </section>
      </main>

      <footer className="border-t border-white/[0.08] px-6 py-4 max-w-7xl w-full mx-auto flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
        <span>EDITMIND AI · Server-Powered Video Editing Foundation</span>
        <span className="font-mono-tabular">EDITMIND AI · Studio Workspace</span>
      </footer>
    </div>
  );
}
