import { useState } from 'react';
import { Check, LogOut, Shield } from 'lucide-react';
import { changePassword, updatePreferences } from '../lib/api';
import type { User } from '../types/studio';

interface AccountViewProps {
  user: User;
  onUserUpdated: (user: User) => void;
  onLogout: () => Promise<void>;
}

export function AccountView({ user, onUserUpdated, onLogout }: AccountViewProps) {
  const [displayName, setDisplayName] = useState(user.displayName);
  const [lowDataMode, setLowDataMode] = useState(user.lowDataMode);
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileMessage, setProfileMessage] = useState<string | null>(null);
  const [profileError, setProfileError] = useState<string | null>(null);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [savingPassword, setSavingPassword] = useState(false);
  const [passwordMessage, setPasswordMessage] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);

  async function handleProfileSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSavingProfile(true);
    setProfileMessage(null);
    setProfileError(null);
    try {
      const updated = await updatePreferences({ displayName, lowDataMode });
      onUserUpdated(updated);
      setProfileMessage('Account preferences saved.');
    } catch (err) {
      setProfileError(err instanceof Error ? err.message : 'Unable to save preferences.');
    } finally {
      setSavingProfile(false);
    }
  }

  async function handlePasswordSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSavingPassword(true);
    setPasswordMessage(null);
    setPasswordError(null);
    try {
      await changePassword({ currentPassword, newPassword });
      setCurrentPassword('');
      setNewPassword('');
      setPasswordMessage('Password updated. Other sessions have been signed out.');
    } catch (err) {
      setPasswordError(err instanceof Error ? err.message : 'Unable to update password.');
    } finally {
      setSavingPassword(false);
    }
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="space-y-1">
        <h1 className="font-display text-2xl font-bold text-white tracking-tight">
          Account & Mobile Data Preferences
        </h1>
        <p className="text-sm text-slate-400">
          Manage your studio profile, default bandwidth policy, and session security.
        </p>
      </div>

      <section className="bg-[#11141B] border border-white/[0.08] rounded-xl p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-white/[0.08]">
          <div>
            <h2 className="font-display text-base font-semibold text-white">Studio Profile</h2>
            <p className="font-mono-tabular text-xs text-slate-400">{user.email}</p>
          </div>
          <span className="font-mono-tabular text-xs text-slate-400">Role: {user.role}</span>
        </div>

        {profileError && (
          <div role="alert" className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-200">
            {profileError}
          </div>
        )}
        {profileMessage && (
          <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-200 flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{profileMessage}</span>
          </div>
        )}

        <form onSubmit={handleProfileSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label htmlFor="acc-display-name" className="block text-xs font-medium text-slate-300">
              Display Name
            </label>
            <input
              id="acc-display-name"
              type="text"
              required
              minLength={2}
              maxLength={60}
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white focus:outline-none focus:border-[#E5A93C]"
            />
          </div>

          <label className="flex items-start gap-3 p-3.5 rounded-lg bg-[#0A0C10] border border-white/[0.06] cursor-pointer">
            <input
              type="checkbox"
              checked={lowDataMode}
              onChange={(e) => setLowDataMode(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-white/20 accent-[#E5A93C]"
            />
            <span className="text-xs text-slate-300 leading-relaxed">
              <strong className="font-medium text-white block">Default Low-Data Mode for New Projects</strong>
              Prioritizes mobile data savings: disables automatic prefetching, defaults previews to lower bitrate, and warns before large uploads or downloads.
            </span>
          </label>

          <button
            type="submit"
            disabled={savingProfile}
            className="px-5 py-2.5 text-xs font-semibold rounded-lg bg-[#E5A93C] text-[#0A0C10] hover:bg-[#eab654] disabled:opacity-60 transition-colors min-h-[40px]"
          >
            {savingProfile ? 'Saving...' : 'Save Preferences'}
          </button>
        </form>
      </section>

      <section className="bg-[#11141B] border border-white/[0.08] rounded-xl p-6 space-y-5">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-[#E5A93C]" aria-hidden="true" />
          <h2 className="font-display text-base font-semibold text-white">Password & Session Security</h2>
        </div>

        {passwordError && (
          <div role="alert" className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-200">
            {passwordError}
          </div>
        )}
        {passwordMessage && (
          <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-200 flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{passwordMessage}</span>
          </div>
        )}

        <form onSubmit={handlePasswordSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label htmlFor="acc-cur-pw" className="block text-xs font-medium text-slate-300">
                Current Password
              </label>
              <input
                id="acc-cur-pw"
                type="password"
                required
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white focus:outline-none focus:border-[#E5A93C]"
              />
            </div>

            <div className="space-y-1.5">
              <label htmlFor="acc-new-pw" className="block text-xs font-medium text-slate-300">
                New Password
              </label>
              <input
                id="acc-new-pw"
                type="password"
                required
                minLength={8}
                maxLength={128}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Minimum 8 characters"
                className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white focus:outline-none focus:border-[#E5A93C]"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <button
              type="submit"
              disabled={savingPassword}
              className="px-4 py-2.5 text-xs font-semibold rounded-lg bg-[#171B24] text-white hover:bg-[#202633] disabled:opacity-60 transition-colors min-h-[40px]"
            >
              {savingPassword ? 'Updating...' : 'Update Password'}
            </button>

            <button
              type="button"
              onClick={() => void onLogout()}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg border border-red-500/30 text-red-200 hover:bg-red-500/10 transition-colors min-h-[40px]"
            >
              <LogOut className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Sign Out</span>
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}
