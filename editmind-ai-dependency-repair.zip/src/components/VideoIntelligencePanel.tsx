import { useEffect, useRef, useState } from 'react';
import { Eye, Film, Play, RefreshCw, Sparkles } from 'lucide-react';
import { getVideoAnalysisCache, runVideoAnalysis } from '../lib/api';
import { formatDuration } from '../lib/format';
import type {
  CameraMovementType,
  MediaAsset,
  StructuredVideoAnalysis,
  VideoSceneSegment,
} from '../types/studio';

interface VideoIntelligencePanelProps {
  videoAsset: MediaAsset | null;
  currentTimeSec: number;
  activeSceneIndex: number | null;
  onPreviewScene: (scene: VideoSceneSegment) => void;
  onSeekToTime: (timeSec: number) => void;
}

type SceneFilterMode = 'all' | 'usable' | 'highlights' | 'flagged';

const CAMERA_MOVEMENT_LABELS: Record<CameraMovementType, string> = {
  static: 'Static Hold',
  'pan-left': 'Pan Left',
  'pan-right': 'Pan Right',
  'tilt-up': 'Tilt Up',
  'tilt-down': 'Tilt Down',
  'zoom-in': 'Zoom In',
  'zoom-out': 'Zoom Out',
  'handheld-dynamic': 'Handheld Dynamic',
  mixed: 'Mixed Motion',
};

function VideoTimelineCanvas({
  analysis,
  currentTimeSec,
  activeSceneIndex,
  onSeekToTime,
}: {
  analysis: StructuredVideoAnalysis;
  currentTimeSec: number;
  activeSceneIndex: number | null;
  onSeekToTime: (timeSec: number) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const width = Math.max(300, Math.floor(rect.width));
    const height = 112;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.scale(dpr, dpr);

    ctx.fillStyle = '#07090D';
    ctx.fillRect(0, 0, width, height);

    const dur = Math.max(0.1, analysis.durationSec);

    // Top track (0..44px): detected scene blocks
    for (const scene of analysis.scenes) {
      const x1 = (scene.startSec / dur) * width;
      const x2 = (scene.endSec / dur) * width;
      const w = Math.max(2, x2 - x1);

      if (!scene.usable) {
        ctx.fillStyle = 'rgba(239, 68, 68, 0.28)';
      } else if (scene.interestScore >= 0.55) {
        ctx.fillStyle = 'rgba(229, 169, 60, 0.36)';
      } else {
        ctx.fillStyle = 'rgba(56, 189, 248, 0.22)';
      }
      ctx.fillRect(x1, 4, w - 1, 38);

      // Top status bar indicator
      ctx.fillStyle = !scene.usable
        ? '#EF4444'
        : scene.interestScore >= 0.55
        ? '#E5A93C'
        : '#38BDF8';
      ctx.fillRect(x1, 4, w - 1, 3);

      if (activeSceneIndex === scene.sceneIndex) {
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(x1 + 0.5, 4.5, Math.max(1, w - 2), 37);
      }
    }

    // Bottom track (52..104px): Motion intensity (amber) & Interest score (sky)
    const curve = analysis.timelineCurve;
    if (curve.length > 1) {
      const top = 54;
      const bandH = 48;

      ctx.beginPath();
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 1.5;
      for (let i = 0; i < curve.length; i++) {
        const x = (curve[i].timeSec / dur) * width;
        const y = top + bandH - curve[i].interestScore * bandH;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      ctx.beginPath();
      ctx.strokeStyle = '#E5A93C';
      ctx.lineWidth = 1.5;
      for (let i = 0; i < curve.length; i++) {
        const x = (curve[i].timeSec / dur) * width;
        const y = top + bandH - curve[i].motionIntensity * bandH;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }

    // Significant moment markers along divider line
    for (const m of analysis.significantMoments) {
      const x = (m.timestampSec / dur) * width;
      ctx.fillStyle = m.type === 'peak-motion' ? '#E5A93C' : '#F8FAFC';
      ctx.fillRect(x - 1, 44, 2, 6);
    }

    // Current preview playhead
    const playX = Math.max(0, Math.min(width, (currentTimeSec / dur) * width));
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(playX, 0);
    ctx.lineTo(playX, height);
    ctx.stroke();
  }, [analysis, currentTimeSec, activeSceneIndex]);

  function handleClick(e: React.MouseEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / Math.max(1, rect.width)));
    onSeekToTime(ratio * analysis.durationSec);
  }

  return (
    <canvas
      ref={canvasRef}
      onClick={handleClick}
      aria-label="Video scene timeline, motion intensity, and visual interest curve. Click to seek."
      className="w-full h-28 rounded-lg border border-white/[0.08] cursor-pointer block"
    />
  );
}

function SceneThumbFrame({
  scene,
  assetName,
}: {
  scene: VideoSceneSegment;
  assetName: string;
}) {
  const [failed, setFailed] = useState(false);

  if (scene.thumbnailAvailable && scene.thumbnailUrl && !failed) {
    return (
      <img
        src={scene.thumbnailUrl}
        alt={`Representative frame for ${assetName} scene ${scene.sceneIndex + 1}`}
        referrerPolicy="no-referrer"
        onError={() => setFailed(true)}
        className="w-full h-full object-cover"
      />
    );
  }

  return (
    <div className="w-full h-full bg-gradient-to-br from-[#0A0C10] via-[#131722] to-[#07090D] flex flex-col items-center justify-center gap-1 text-slate-500 p-2 text-center">
      <Film className="w-5 h-5" aria-hidden="true" />
      <span className="font-mono-tabular text-[10px]">
        Scene {scene.sceneIndex + 1} · {formatDuration(scene.representativeTimestampSec)}
      </span>
    </div>
  );
}

export function VideoIntelligencePanel({
  videoAsset,
  currentTimeSec,
  activeSceneIndex,
  onPreviewScene,
  onSeekToTime,
}: VideoIntelligencePanelProps) {
  const [analysis, setAnalysis] = useState<StructuredVideoAnalysis | null>(null);
  const [cached, setCached] = useState(false);
  const [loadingCache, setLoadingCache] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filterMode, setFilterMode] = useState<SceneFilterMode>('all');

  useEffect(() => {
    setAnalysis(null);
    setCached(false);
    setError(null);
    setFilterMode('all');

    if (!videoAsset) return;

    let cancelled = false;
    setLoadingCache(true);
    getVideoAnalysisCache(videoAsset.id)
      .then((res) => {
        if (cancelled) return;
        setAnalysis(res.analysis);
        setCached(res.cached);
      })
      .catch((err) => {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Unable to check video analysis cache.');
        }
      })
      .finally(() => {
        if (!cancelled) setLoadingCache(false);
      });

    return () => {
      cancelled = true;
    };
  }, [videoAsset?.id, videoAsset?.updatedAt]);

  async function handleAnalyze(force = false) {
    if (!videoAsset) return;
    setAnalyzing(true);
    setError(null);
    try {
      const res = await runVideoAnalysis(videoAsset.id, force);
      setAnalysis(res.analysis);
      setCached(res.cached);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Video analysis failed.');
    } finally {
      setAnalyzing(false);
    }
  }

  if (!videoAsset) {
    return (
      <section className="bg-[#11141B] border border-white/[0.08] rounded-xl p-5 sm:p-6 space-y-2">
        <div className="flex items-center gap-2">
          <Eye className="w-4 h-4 text-[#E5A93C]" aria-hidden="true" />
          <h2 className="font-display text-base font-semibold text-white">Video Intelligence</h2>
        </div>
        <p className="text-xs text-slate-400">
          Select Preview Clip on any uploaded MP4 or MOV file in the Media Library to run server-side scene detection, camera movement analysis, black-frame screening, and scene previews.
        </p>
      </section>
    );
  }

  const filteredScenes = analysis
    ? analysis.scenes.filter((scene) => {
        if (filterMode === 'usable') return scene.usable;
        if (filterMode === 'highlights') return scene.usable && scene.interestScore >= 0.45;
        if (filterMode === 'flagged') return !scene.usable || scene.issues.length > 0;
        return true;
      })
    : [];

  return (
    <section className="bg-[#11141B] border border-white/[0.08] rounded-xl p-5 sm:p-6 space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1 min-w-0">
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-[#E5A93C] shrink-0" aria-hidden="true" />
            <h2 className="font-display text-base font-semibold text-white truncate">
              Video Intelligence · {videoAsset.originalName}
            </h2>
          </div>
          <p className="font-mono-tabular text-xs text-slate-400">
            {analysis
              ? `${cached ? 'Cached on server' : 'Analyzed on server'} · ${analysis.processingMs} ms · ${analysis.sampleFpsUsed} fps CV pass`
              : 'Server-side shot boundaries, camera motion, black/frozen screening & saliency (manual trigger)'}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {!analysis ? (
            <button
              type="button"
              disabled={analyzing || loadingCache}
              onClick={() => void handleAnalyze(false)}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-lg bg-[#E5A93C] text-[#0A0C10] hover:bg-[#eab654] disabled:opacity-60 transition-colors whitespace-nowrap shrink-0 min-h-[42px]"
            >
              <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{analyzing ? 'Analyzing on Server...' : 'Analyze Video'}</span>
            </button>
          ) : (
            <button
              type="button"
              disabled={analyzing}
              onClick={() => void handleAnalyze(true)}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg border border-white/15 text-slate-200 hover:bg-white/[0.06] disabled:opacity-60 transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 ${analyzing ? 'animate-spin' : ''}`}
                aria-hidden="true"
              />
              <span>{analyzing ? 'Re-analyzing...' : 'Re-analyze'}</span>
            </button>
          )}
        </div>
      </div>

      {error && (
        <div
          role="alert"
          className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-200"
        >
          {error}
        </div>
      )}

      {analyzing && (
        <div
          className="p-4 rounded-lg bg-[#0A0C10] border border-white/[0.08] space-y-2"
          aria-busy="true"
        >
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-200 font-medium">
              Extracting metadata, scanning shot boundaries, estimating optical flow, and generating scene thumbnails on server...
            </span>
            <span className="font-mono-tabular text-[#E5A93C] shrink-0">Server Processing</span>
          </div>
          <div className="h-1.5 w-full bg-[#171B24] rounded-full overflow-hidden">
            <div className="h-full w-2/3 bg-[#E5A93C] animate-pulse" />
          </div>
        </div>
      )}

      {!loadingCache && !analyzing && !analysis && (
        <div className="p-6 rounded-lg bg-[#0A0C10] border border-white/[0.06] text-xs text-slate-300 space-y-1.5">
          <p className="font-medium text-white">Ready for server-side video analysis</p>
          <p className="text-slate-400 leading-relaxed">
            In Low-Data Mode, original clips are never downloaded to your device for analysis. All decoding, shot detection, motion analysis, and JPEG scene thumbnail extraction run strictly on the server and are cached by file checksum.
          </p>
        </div>
      )}

      {analysis && (
        <div className="space-y-5">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-lg bg-[#0A0C10] border border-white/[0.06] space-y-1">
              <div className="text-[11px] text-slate-400">Format & Geometry</div>
              <div className="font-mono-tabular text-base font-bold text-white">
                {analysis.metadata.width}×{analysis.metadata.height}
              </div>
              <div className="font-mono-tabular text-[11px] text-slate-400 capitalize">
                {analysis.metadata.orientation} · {analysis.metadata.aspectRatioLabel} ·{' '}
                {analysis.metadata.fps} fps
              </div>
            </div>

            <div className="p-3.5 rounded-lg bg-[#0A0C10] border border-white/[0.06] space-y-1">
              <div className="text-[11px] text-slate-400">Detected Scenes</div>
              <div className="font-mono-tabular text-base font-bold text-white">
                {analysis.sceneCount} scenes
              </div>
              <div className="font-mono-tabular text-[11px] text-slate-400">
                {analysis.usableSceneCount} usable · {formatDuration(analysis.usableDurationSec)} clean
              </div>
            </div>

            <div className="p-3.5 rounded-lg bg-[#0A0C10] border border-white/[0.06] space-y-1">
              <div className="text-[11px] text-slate-400">Camera & Motion</div>
              <div className="text-sm font-semibold text-white truncate">
                {CAMERA_MOVEMENT_LABELS[analysis.dominantCameraMovement] ||
                  analysis.dominantCameraMovement}
              </div>
              <div className="font-mono-tabular text-[11px] text-slate-400">
                Mean intensity {Math.round(analysis.averageMotionIntensity * 100)}% · Quality{' '}
                {Math.round(analysis.averageQualityScore * 100)}%
              </div>
            </div>

            <div className="p-3.5 rounded-lg bg-[#0A0C10] border border-white/[0.06] space-y-1">
              <div className="text-[11px] text-slate-400">Unusable Footage</div>
              <div className="font-mono-tabular text-base font-bold text-white">
                {(analysis.blackDurationSec + analysis.frozenDurationSec).toFixed(1)}s flagged
              </div>
              <div className="font-mono-tabular text-[11px] text-slate-400">
                {analysis.blackDurationSec.toFixed(1)}s black · {analysis.frozenDurationSec.toFixed(1)}s frozen
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
              <span>Scene Timeline, Motion Intensity & Visual Interest (click to jump)</span>
              <span className="font-mono-tabular">
                Amber: Motion / Highlights · Blue: Interest · Red: Unusable
              </span>
            </div>
            <VideoTimelineCanvas
              analysis={analysis}
              currentTimeSec={currentTimeSec}
              activeSceneIndex={activeSceneIndex}
              onSeekToTime={onSeekToTime}
            />
          </div>

          {analysis.notes.length > 0 && (
            <div className="p-3.5 rounded-lg bg-[#0A0C10] border border-amber-500/25 text-xs text-amber-200/90 space-y-1">
              {analysis.notes.map((note, idx) => (
                <p key={idx}>{note}</p>
              ))}
            </div>
          )}

          <div className="p-3.5 rounded-lg bg-[#0A0C10] border border-white/[0.06] text-xs text-slate-400 leading-relaxed">
            <span className="font-medium text-slate-200">Detector Scope: </span>
            {analysis.capabilities.honestyNote}
          </div>

          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h3 className="font-display text-xs font-semibold text-slate-300">
                Timestamped Scenes ({filteredScenes.length})
              </h3>

              <div className="flex flex-wrap items-center gap-1 p-1 bg-[#0A0C10] border border-white/[0.08] rounded-lg">
                {(
                  [
                    { id: 'all', label: `All (${analysis.scenes.length})` },
                    { id: 'usable', label: `Usable (${analysis.usableSceneCount})` },
                    {
                      id: 'highlights',
                      label: `Highlights (${
                        analysis.scenes.filter((s) => s.usable && s.interestScore >= 0.45).length
                      })`,
                    },
                    {
                      id: 'flagged',
                      label: `Flagged (${
                        analysis.scenes.filter((s) => !s.usable || s.issues.length > 0).length
                      })`,
                    },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setFilterMode(tab.id)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                      filterMode === tab.id
                        ? 'bg-[#171B24] text-white'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {filteredScenes.length === 0 ? (
              <div className="p-6 rounded-lg bg-[#0A0C10] border border-white/[0.06] text-xs text-slate-400 text-center">
                No scenes match the current filter.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredScenes.map((scene) => {
                  const isActive = activeSceneIndex === scene.sceneIndex;
                  return (
                    <article
                      key={scene.sceneIndex}
                      className={`rounded-lg bg-[#0A0C10] border overflow-hidden flex flex-col transition-colors ${
                        isActive ? 'border-[#E5A93C]' : 'border-white/[0.08]'
                      }`}
                    >
                      <div className="relative aspect-video bg-black overflow-hidden">
                        <SceneThumbFrame scene={scene} assetName={videoAsset.originalName} />
                        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent px-3 py-2 flex items-center justify-between gap-2">
                          <span className="font-mono-tabular text-xs font-semibold text-white">
                            Scene {scene.sceneIndex + 1}
                          </span>
                          <span className="font-mono-tabular text-[11px] text-slate-200">
                            {formatDuration(scene.startSec)} – {formatDuration(scene.endSec)}
                          </span>
                        </div>
                      </div>

                      <div className="p-3.5 space-y-2.5 flex-1 flex flex-col justify-between">
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between gap-2 text-xs">
                            <span className="font-medium text-white">
                              {CAMERA_MOVEMENT_LABELS[scene.cameraMovement] || scene.cameraMovement}
                            </span>
                            <span
                              className={`font-mono-tabular text-[11px] font-medium ${
                                scene.usable ? 'text-emerald-400' : 'text-red-400'
                              }`}
                            >
                              {scene.usable ? 'Usable' : 'Unusable'}
                            </span>
                          </div>

                          <div className="font-mono-tabular text-[11px] text-slate-400 flex flex-wrap items-center gap-x-2 gap-y-0.5">
                            <span>{scene.durationSec.toFixed(1)}s</span>
                            <span aria-hidden="true">·</span>
                            <span>Motion {Math.round(scene.motionIntensity * 100)}%</span>
                            <span aria-hidden="true">·</span>
                            <span>Interest {Math.round(scene.interestScore * 100)}%</span>
                            <span aria-hidden="true">·</span>
                            <span>Quality {Math.round(scene.visualQualityScore * 100)}%</span>
                          </div>

                          <div className="font-mono-tabular text-[11px] text-slate-400">
                            {scene.detections.personLikely
                              ? `Subject saliency ${Math.round(scene.detections.personLikelihood * 100)}%`
                              : 'No primary person saliency'}{' '}
                            · {scene.detections.salientRegionCount} salient zones
                          </div>

                          {scene.unusableReason && (
                            <p className="text-[11px] text-red-300">{scene.unusableReason}</p>
                          )}
                        </div>

                        <button
                          type="button"
                          onClick={() => onPreviewScene(scene)}
                          className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-md bg-[#171B24] text-white hover:bg-[#222836] transition-colors whitespace-nowrap shrink-0 min-h-[38px]"
                        >
                          <Play className="w-3.5 h-3.5 text-[#E5A93C]" aria-hidden="true" />
                          <span>
                            {isActive ? 'Replay Scene' : `Preview Scene ${scene.sceneIndex + 1}`}
                          </span>
                        </button>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </div>

          {analysis.significantMoments.length > 0 && (
            <div className="space-y-2">
              <h3 className="font-display text-xs font-semibold text-slate-300">
                Visually Significant Moments
              </h3>
              <div className="divide-y divide-white/[0.06] border border-white/[0.08] rounded-lg bg-[#0A0C10] max-h-56 overflow-y-auto">
                {analysis.significantMoments.map((moment, idx) => (
                  <button
                    key={`${moment.type}-${moment.timestampSec}-${idx}`}
                    type="button"
                    onClick={() => onSeekToTime(moment.timestampSec)}
                    className="w-full text-left px-3.5 py-2.5 hover:bg-white/[0.04] transition-colors flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-medium text-white truncate">
                        {moment.summary}
                      </div>
                      <div className="text-[11px] text-slate-500 capitalize">
                        {moment.type.replace(/-/g, ' ')} · Score {Math.round(moment.score * 100)}%
                      </div>
                    </div>
                    <span className="font-mono-tabular text-xs text-[#E5A93C] shrink-0">
                      {formatDuration(moment.timestampSec)}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </section>
  );
}
