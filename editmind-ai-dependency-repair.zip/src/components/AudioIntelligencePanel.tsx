import { useEffect, useRef, useState } from 'react';
import { Activity, RefreshCw, Sparkles } from 'lucide-react';
import { getAudioAnalysisCache, runAudioAnalysis } from '../lib/api';
import { formatDuration } from '../lib/format';
import type { MediaAsset, MusicSectionSegment, StructuredAudioAnalysis } from '../types/studio';

interface AudioIntelligencePanelProps {
  audioAsset: MediaAsset | null;
  currentTimeSec: number;
  onSeekTo: (timeSec: number) => void;
}

const SECTION_COLORS: Record<MusicSectionSegment['label'], string> = {
  intro: '#38BDF8',
  verse: '#64748B',
  'build-up': '#F59E0B',
  drop: '#EF4444',
  break: '#8B5CF6',
  chorus: '#E5A93C',
  outro: '#6366F1',
  uncertain: '#475569',
};

const RHYTHM_LABELS: Record<string, string> = {
  'steady-4/4': 'Steady 4/4',
  'steady-3/4': 'Steady 3/4',
  syncopated: 'Syncopated',
  'tempo-shifting': 'Tempo Shifting',
  'weak-or-irregular': 'Weak / Irregular',
};

function WaveformBeatCanvas({
  analysis,
  currentTimeSec,
  onSeekTo,
}: {
  analysis: StructuredAudioAnalysis;
  currentTimeSec: number;
  onSeekTo: (timeSec: number) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const width = Math.max(300, Math.floor(rect.width));
    const height = 160;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.scale(dpr, dpr);

    // Background
    ctx.fillStyle = '#07090D';
    ctx.fillRect(0, 0, width, height);

    const dur = Math.max(0.1, analysis.durationSec);
    const waveTop = 22;
    const waveHeight = 100;
    const waveMidY = waveTop + waveHeight / 2;

    // 1. Section bands along top strip (0..18px)
    for (const sec of analysis.sections) {
      const x1 = (sec.startSec / dur) * width;
      const x2 = (sec.endSec / dur) * width;
      ctx.fillStyle = SECTION_COLORS[sec.label] || '#64748B';
      ctx.globalAlpha = 0.28;
      ctx.fillRect(x1, 0, Math.max(1, x2 - x1), 18);
      ctx.globalAlpha = 0.9;
      ctx.fillRect(x1, 16, Math.max(1, x2 - x1), 2);
      ctx.globalAlpha = 1;
    }

    // 2. Beat & Downbeat vertical markers
    for (const beat of analysis.beatIntelligence.beats) {
      const x = (beat.timestampSec / dur) * width;
      if (beat.isDownbeat) {
        ctx.strokeStyle = 'rgba(229, 169, 60, 0.72)';
        ctx.lineWidth = 1.5;
      } else if (beat.isStrong) {
        ctx.strokeStyle = 'rgba(241, 245, 249, 0.28)';
        ctx.lineWidth = 1;
      } else {
        ctx.strokeStyle = 'rgba(148, 163, 184, 0.14)';
        ctx.lineWidth = 1;
      }
      ctx.beginPath();
      ctx.moveTo(x, waveTop);
      ctx.lineTo(x, waveTop + waveHeight);
      ctx.stroke();
    }

    // 3. Waveform bars
    const wave = analysis.waveform;
    if (wave.length > 0) {
      const barW = Math.max(1.5, width / wave.length - 0.8);
      for (let i = 0; i < wave.length; i++) {
        const pt = wave[i];
        const x = (pt.timeSec / dur) * width;
        const amp = Math.max(2, pt.peak * (waveHeight * 0.44));
        const played = pt.timeSec <= currentTimeSec;
        ctx.fillStyle = played ? 'rgba(229, 169, 60, 0.85)' : 'rgba(148, 163, 184, 0.55)';
        ctx.fillRect(x, waveMidY - amp, barW, amp * 2);
      }
    }

    // 4. Energy curve strip along bottom (126..156px)
    const curve = analysis.energyCurve;
    if (curve.length > 1) {
      const energyTop = 128;
      const energyH = 26;
      const maxCurveRms = Math.max(0.01, ...curve.map((c) => c.rms));
      ctx.beginPath();
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 1.5;
      for (let i = 0; i < curve.length; i++) {
        const x = (curve[i].timeSec / dur) * width;
        const y = energyTop + energyH - (curve[i].rms / maxCurveRms) * energyH;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }

    // 5. Playhead
    const playX = Math.max(0, Math.min(width, (currentTimeSec / dur) * width));
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(playX, 0);
    ctx.lineTo(playX, height);
    ctx.stroke();
  }, [analysis, currentTimeSec]);

  function handleCanvasClick(e: React.MouseEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / Math.max(1, rect.width)));
    onSeekTo(ratio * analysis.durationSec);
  }

  return (
    <canvas
      ref={canvasRef}
      onClick={handleCanvasClick}
      aria-label="Audio waveform, beat markers, musical sections, and energy curve. Click to seek."
      className="w-full h-40 rounded-lg border border-white/[0.08] cursor-pointer block"
    />
  );
}

export function AudioIntelligencePanel({
  audioAsset,
  currentTimeSec,
  onSeekTo,
}: AudioIntelligencePanelProps) {
  const [analysis, setAnalysis] = useState<StructuredAudioAnalysis | null>(null);
  const [cached, setCached] = useState(false);
  const [loadingCache, setLoadingCache] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setAnalysis(null);
    setCached(false);
    setError(null);

    if (!audioAsset) return;

    let cancelled = false;
    setLoadingCache(true);
    getAudioAnalysisCache(audioAsset.id)
      .then((res) => {
        if (cancelled) return;
        setAnalysis(res.analysis);
        setCached(res.cached);
      })
      .catch((err) => {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Unable to check audio analysis cache.');
        }
      })
      .finally(() => {
        if (!cancelled) setLoadingCache(false);
      });

    return () => {
      cancelled = true;
    };
  }, [audioAsset?.id, audioAsset?.updatedAt]);

  async function handleAnalyze(force = false) {
    if (!audioAsset) return;
    setAnalyzing(true);
    setError(null);
    try {
      const res = await runAudioAnalysis(audioAsset.id, force);
      setAnalysis(res.analysis);
      setCached(res.cached);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Audio analysis failed.');
    } finally {
      setAnalyzing(false);
    }
  }

  if (!audioAsset) {
    return (
      <section className="bg-[#11141B] border border-white/[0.08] rounded-xl p-5 sm:p-6 space-y-2">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-[#E5A93C]" aria-hidden="true" />
          <h2 className="font-display text-base font-semibold text-white">Audio Intelligence</h2>
        </div>
        <p className="text-xs text-slate-400">
          Load an uploaded audio track in the Media Library to run server-side beat detection, tempo tracking, and musical structure analysis.
        </p>
      </section>
    );
  }

  const bpmPct = analysis ? Math.round(analysis.beatIntelligence.bpmConfidence * 100) : 0;
  const structPct = analysis ? Math.round(analysis.overallStructureConfidence * 100) : 0;

  return (
    <section className="bg-[#11141B] border border-white/[0.08] rounded-xl p-5 sm:p-6 space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1 min-w-0">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#E5A93C] shrink-0" aria-hidden="true" />
            <h2 className="font-display text-base font-semibold text-white truncate">
              Audio Intelligence · {audioAsset.originalName}
            </h2>
          </div>
          <p className="font-mono-tabular text-xs text-slate-400">
            {analysis
              ? `${cached ? 'Cached on server' : 'Analyzed on server'} · ${analysis.processingMs} ms · ${analysis.sampleRateAnalyzed} Hz mono DSP`
              : 'Server-side beat, downbeat, energy, and structure detection (manual trigger)'}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {!analysis ? (
            <button
              type="button"
              disabled={analyzing || loadingCache}
              onClick={() => void handleAnalyze(false)}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-lg bg-[#E5A93C] text-[#0A0C10] hover:bg-[#eab654] disabled:opacity-60 transition-colors min-h-[42px]"
            >
              <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{analyzing ? 'Analyzing on Server...' : 'Analyze Audio'}</span>
            </button>
          ) : (
            <button
              type="button"
              disabled={analyzing}
              onClick={() => void handleAnalyze(true)}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg border border-white/15 text-slate-200 hover:bg-white/[0.06] disabled:opacity-60 transition-colors min-h-[40px]"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${analyzing ? 'animate-spin' : ''}`} aria-hidden="true" />
              <span>{analyzing ? 'Re-analyzing...' : 'Re-analyze'}</span>
            </button>
          )}
        </div>
      </div>

      {error && (
        <div role="alert" className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-200">
          {error}
        </div>
      )}

      {analyzing && (
        <div className="p-4 rounded-lg bg-[#0A0C10] border border-white/[0.08] space-y-2" aria-busy="true">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-200 font-medium">
              Decoding PCM stream, extracting spectral onset flux, and tracking beats on server...
            </span>
            <span className="font-mono-tabular text-[#E5A93C]">Server Processing</span>
          </div>
          <div className="h-1.5 w-full bg-[#171B24] rounded-full overflow-hidden">
            <div className="h-full w-2/3 bg-[#E5A93C] animate-pulse" />
          </div>
        </div>
      )}

      {!loadingCache && !analyzing && !analysis && (
        <div className="p-6 rounded-lg bg-[#0A0C10] border border-white/[0.06] text-xs text-slate-300 space-y-1.5">
          <p className="font-medium text-white">Ready for server-side analysis</p>
          <p className="text-slate-400 leading-relaxed">
            To save mobile bandwidth and server compute, analysis only runs when you request it. Results are cached on the server against the file checksum.
          </p>
        </div>
      )}

      {analysis && (
        <div className="space-y-5">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-lg bg-[#0A0C10] border border-white/[0.06] space-y-1">
              <div className="text-[11px] text-slate-400">Detected BPM</div>
              <div className="font-mono-tabular text-lg font-bold text-white">
                {analysis.beatIntelligence.bpm > 0 ? analysis.beatIntelligence.bpm.toFixed(1) : '—'}
              </div>
              <div className="font-mono-tabular text-[11px] text-slate-400">
                Confidence {bpmPct}%
              </div>
            </div>

            <div className="p-3.5 rounded-lg bg-[#0A0C10] border border-white/[0.06] space-y-1">
              <div className="text-[11px] text-slate-400">Rhythm Pattern</div>
              <div className="text-sm font-semibold text-white">
                {RHYTHM_LABELS[analysis.beatIntelligence.rhythmPattern] ||
                  analysis.beatIntelligence.rhythmPattern}
              </div>
              <div className="font-mono-tabular text-[11px] text-slate-400">
                Regularity {Math.round(analysis.beatIntelligence.rhythmRegularity * 100)}%
              </div>
            </div>

            <div className="p-3.5 rounded-lg bg-[#0A0C10] border border-white/[0.06] space-y-1">
              <div className="text-[11px] text-slate-400">Beats & Downbeats</div>
              <div className="font-mono-tabular text-lg font-bold text-white">
                {analysis.beatIntelligence.beatTimestampsSec.length}
              </div>
              <div className="font-mono-tabular text-[11px] text-slate-400">
                {analysis.beatIntelligence.downbeatTimestampsSec.length} downbeats ·{' '}
                {analysis.beatIntelligence.tempoChanges.length} tempo shifts
              </div>
            </div>

            <div className="p-3.5 rounded-lg bg-[#0A0C10] border border-white/[0.06] space-y-1">
              <div className="text-[11px] text-slate-400">Structure & Dynamics</div>
              <div className="font-mono-tabular text-lg font-bold text-white">
                {analysis.sections.length} sections
              </div>
              <div className="font-mono-tabular text-[11px] text-slate-400">
                Confidence {structPct}% · {analysis.energySummary.dynamicRangeDb.toFixed(1)} dB
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
              <span>Waveform, Beat Grid & Energy Curve (click to seek)</span>
              <span className="font-mono-tabular">
                Amber lines: Downbeats · Blue line: RMS energy
              </span>
            </div>
            <WaveformBeatCanvas
              analysis={analysis}
              currentTimeSec={currentTimeSec}
              onSeekTo={onSeekTo}
            />
            <div className="flex flex-wrap items-center gap-1.5">
              {analysis.sections.map((sec, idx) => {
                const widthPct = Math.max(
                  4,
                  ((sec.endSec - sec.startSec) / Math.max(0.1, analysis.durationSec)) * 100
                );
                return (
                  <button
                    key={`${sec.label}-${idx}`}
                    type="button"
                    onClick={() => onSeekTo(sec.startSec)}
                    style={{
                      width: `${widthPct}%`,
                      borderColor: SECTION_COLORS[sec.label],
                    }}
                    title={`${sec.label} (${formatDuration(sec.startSec)} - ${formatDuration(sec.endSec)})`}
                    className="min-w-[68px] flex-1 px-2 py-1.5 text-left rounded-md bg-[#0A0C10] border-t-2 hover:bg-[#171B24] transition-colors"
                  >
                    <div className="text-[11px] font-semibold text-white capitalize truncate">
                      {sec.label}
                    </div>
                    <div className="font-mono-tabular text-[10px] text-slate-400">
                      {formatDuration(sec.startSec)}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {analysis.notes.length > 0 && (
            <div className="p-3.5 rounded-lg bg-[#0A0C10] border border-amber-500/25 text-xs text-amber-200/90 space-y-1">
              {analysis.notes.map((note, idx) => (
                <p key={idx}>{note}</p>
              ))}
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h3 className="font-display text-xs font-semibold text-slate-300">
                Musical Sections
              </h3>
              <div className="divide-y divide-white/[0.06] border border-white/[0.08] rounded-lg bg-[#0A0C10] max-h-64 overflow-y-auto">
                {analysis.sections.map((sec, idx) => (
                  <button
                    key={`${sec.label}-${sec.startSec}-${idx}`}
                    type="button"
                    onClick={() => onSeekTo(sec.startSec)}
                    className="w-full text-left px-3.5 py-2.5 hover:bg-white/[0.04] transition-colors space-y-0.5"
                  >
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="font-semibold text-white capitalize">{sec.label}</span>
                      <span className="font-mono-tabular text-slate-400">
                        {formatDuration(sec.startSec)} – {formatDuration(sec.endSec)} · Energy{' '}
                        {Math.round(sec.energyScore * 100)}% · Conf{' '}
                        {Math.round(sec.confidence * 100)}%
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">{sec.rationale}</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="font-display text-xs font-semibold text-slate-300">
                Events, Silence & Tempo Shifts
              </h3>
              <div className="divide-y divide-white/[0.06] border border-white/[0.08] rounded-lg bg-[#0A0C10] max-h-64 overflow-y-auto">
                {analysis.beatIntelligence.events.length === 0 ? (
                  <div className="p-4 text-xs text-slate-500">
                    No extended silence gaps, abrupt surges, or tempo shifts detected.
                  </div>
                ) : (
                  analysis.beatIntelligence.events.map((ev, idx) => (
                    <button
                      key={`${ev.type}-${ev.startSec}-${idx}`}
                      type="button"
                      onClick={() => onSeekTo(ev.startSec)}
                      className="w-full text-left px-3.5 py-2.5 hover:bg-white/[0.04] transition-colors flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-white truncate">
                          {ev.summary}
                        </div>
                        <div className="text-[11px] text-slate-500 capitalize">
                          {ev.type.replace('-', ' ')}
                        </div>
                      </div>
                      <span className="font-mono-tabular text-xs text-[#E5A93C] shrink-0">
                        {formatDuration(ev.startSec)}
                      </span>
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
