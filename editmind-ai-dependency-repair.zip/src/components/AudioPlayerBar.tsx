import { useEffect, useRef, useState } from 'react';
import { Music, Pause, Play, Volume2, VolumeX } from 'lucide-react';
import { getPlaybackGrant } from '../lib/api';
import { formatDuration } from '../lib/format';
import type { MediaAsset } from '../types/studio';

interface AudioPlayerBarProps {
  asset: MediaAsset | null;
  playSignal: number;
  seekRequest?: { timeSec: number; nonce: number } | null;
  onTimeUpdate?: (timeSec: number) => void;
}

export function AudioPlayerBar({
  asset,
  playSignal,
  seekRequest,
  onTimeUpdate,
}: AudioPlayerBarProps) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [streamUrl, setStreamUrl] = useState<string | null>(null);
  const [loadingStream, setLoadingStream] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.9);
  const [muted, setMuted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const audioEl = audioRef.current;
    if (audioEl) {
      audioEl.pause();
    }
    setIsPlaying(false);
    setCurrentTime(0);
    onTimeUpdate?.(0);
    setError(null);

    if (!asset) {
      setStreamUrl(null);
      setDuration(0);
      return;
    }

    setDuration(asset.durationSec || 0);
    let cancelled = false;
    setLoadingStream(true);

    getPlaybackGrant(asset.id)
      .then((grant) => {
        if (cancelled) return;
        setStreamUrl(grant.streamUrl);
      })
      .catch((err) => {
        if (cancelled) return;
        setError(err instanceof Error ? err.message : 'Unable to initialize audio playback.');
      })
      .finally(() => {
        if (!cancelled) setLoadingStream(false);
      });

    return () => {
      cancelled = true;
    };
  }, [asset?.id, asset?.updatedAt, playSignal]);

  useEffect(() => {
    const audioEl = audioRef.current;
    if (!audioEl || !streamUrl) return;
    audioEl.volume = muted ? 0 : volume;
    if (playSignal > 0) {
      audioEl
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => setIsPlaying(false));
    }
  }, [streamUrl, playSignal]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = muted ? 0 : volume;
    }
  }, [volume, muted]);

  useEffect(() => {
    if (!seekRequest || !audioRef.current || !streamUrl) return;
    const clamped = Math.max(0, Math.min(seekRequest.timeSec, duration || asset?.durationSec || seekRequest.timeSec));
    audioRef.current.currentTime = clamped;
    setCurrentTime(clamped);
    onTimeUpdate?.(clamped);
  }, [seekRequest?.nonce]);

  if (!asset) {
    return (
      <div className="bg-[#11141B] border border-white/[0.08] rounded-xl p-4 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-lg bg-[#0A0C10] border border-white/[0.06] flex items-center justify-center shrink-0">
            <Music className="w-4 h-4 text-slate-500" aria-hidden="true" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-semibold text-slate-300">Audio Player Ready</div>
            <p className="text-xs text-slate-500 truncate">
              Upload or select an audio track in the Media Library to play, seek, and run beat analysis.
            </p>
          </div>
        </div>
      </div>
    );
  }

  function togglePlayPause() {
    const audioEl = audioRef.current;
    if (!audioEl || !streamUrl) return;
    if (audioEl.paused) {
      audioEl
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => setError('Browser blocked audio playback. Tap Play again.'));
    } else {
      audioEl.pause();
      setIsPlaying(false);
    }
  }

  function handleSeek(nextTime: number) {
    const audioEl = audioRef.current;
    if (!audioEl) return;
    audioEl.currentTime = nextTime;
    setCurrentTime(nextTime);
    onTimeUpdate?.(nextTime);
  }

  const effectiveDuration = duration > 0 ? duration : asset.durationSec || 1;
  const progressPct = Math.min(100, Math.max(0, (currentTime / effectiveDuration) * 100));

  return (
    <div className="bg-[#11141B] border border-white/[0.08] rounded-xl p-4 space-y-3">
      <audio
        ref={audioRef}
        src={streamUrl || undefined}
        preload="metadata"
        onTimeUpdate={(e) => {
          const t = e.currentTarget.currentTime;
          setCurrentTime(t);
          onTimeUpdate?.(t);
        }}
        onLoadedMetadata={(e) => {
          const d = e.currentTarget.duration;
          if (Number.isFinite(d) && d > 0) setDuration(d);
        }}
        onEnded={() => setIsPlaying(false)}
        onPause={() => setIsPlaying(false)}
        onPlay={() => setIsPlaying(true)}
        onError={() => setError('Unable to stream audio track.')}
      />

      {error && (
        <div role="alert" className="p-2.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-200">
          {error}
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            disabled={loadingStream || !streamUrl}
            onClick={togglePlayPause}
            aria-label={isPlaying ? 'Pause audio' : 'Play audio'}
            className="w-11 h-11 rounded-lg bg-[#E5A93C] text-[#0A0C10] hover:bg-[#eab654] disabled:opacity-50 flex items-center justify-center shrink-0 transition-colors"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
          </button>

          <div className="min-w-0 space-y-0.5">
            <div className="text-sm font-semibold text-white truncate">{asset.originalName}</div>
            <div className="font-mono-tabular text-xs text-slate-400">
              {asset.codecName.toUpperCase()}
              {asset.sampleRate ? ` · ${(asset.sampleRate / 1000).toFixed(1)} kHz` : ''}
              {asset.channels ? ` · ${asset.channels}ch` : ''}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setMuted((m) => !m)}
            aria-label={muted ? 'Unmute audio' : 'Mute audio'}
            className="p-2 rounded-md text-slate-300 hover:bg-white/[0.06] min-h-[40px] min-w-[40px] flex items-center justify-center"
          >
            {muted || volume === 0 ? (
              <VolumeX className="w-4 h-4 text-slate-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-slate-300" />
            )}
          </button>
          <input
            type="range"
            min={0}
            max={1}
            step={0.02}
            value={muted ? 0 : volume}
            onChange={(e) => {
              const v = Number(e.target.value);
              setVolume(v);
              if (v > 0 && muted) setMuted(false);
            }}
            aria-label="Audio volume"
            className="w-24 accent-[#E5A93C] cursor-pointer"
          />
        </div>
      </div>

      <div className="space-y-1.5">
        <div className="flex items-center gap-3">
          <span className="font-mono-tabular text-xs text-slate-300 w-12">
            {formatDuration(currentTime)}
          </span>
          <input
            type="range"
            min={0}
            max={effectiveDuration}
            step={0.1}
            value={Math.min(currentTime, effectiveDuration)}
            disabled={!streamUrl}
            onChange={(e) => handleSeek(Number(e.target.value))}
            aria-label="Seek audio playback"
            className="flex-1 accent-[#E5A93C] cursor-pointer"
          />
          <span className="font-mono-tabular text-xs text-slate-400 w-12 text-right">
            {formatDuration(effectiveDuration)}
          </span>
        </div>
        <div className="h-1 w-full bg-[#0A0C10] rounded-full overflow-hidden">
          <div
            className="h-full bg-[#E5A93C] transition-[width] duration-100"
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </div>
    </div>
  );
}
