import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Film,
  Music,
  Pause,
  Play,
  RefreshCw,
  RotateCcw,
  Search,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {
  cancelResumableUpload,
  completeResumableUpload,
  deleteMediaAsset,
  getPlaybackGrant,
  initResumableUpload,
  listMediaAssets,
  uploadChunkBinary,
} from '../lib/api';
import { formatBytes, formatDuration } from '../lib/format';
import type {
  MediaAsset,
  MediaKind,
  MediaSortOption,
  UploadTask,
} from '../types/studio';

interface MediaLibraryPanelProps {
  projectId: string;
  lowDataMode: boolean;
  activeAudioId: string | null;
  activeVideoId: string | null;
  onSelectAudio: (asset: MediaAsset) => void;
  onSelectVideo: (asset: MediaAsset) => void;
  onMediaChanged: (assets: MediaAsset[]) => void;
}

const AUDIO_EXT_RE = /\.(mp3|wav|aac|flac)$/i;
const VIDEO_EXT_RE = /\.(mp4|mov)$/i;
const MAX_AUDIO_BYTES = 150 * 1024 * 1024;
const MAX_VIDEO_BYTES = 500 * 1024 * 1024;

function buildFingerprint(file: File, kind: MediaKind): string {
  return `${kind}:${file.name}:${file.size}:${file.lastModified}`;
}

function MediaThumbnail({ asset }: { asset: MediaAsset }) {
  const [thumbSrc, setThumbSrc] = useState<string | null>(null);

  useEffect(() => {
    if (!asset.hasThumbnail) {
      setThumbSrc(null);
      return;
    }
    let cancelled = false;
    getPlaybackGrant(asset.id)
      .then((grant) => {
        if (!cancelled && grant.thumbnailUrl) {
          setThumbSrc(grant.thumbnailUrl);
        }
      })
      .catch(() => {
        if (!cancelled) setThumbSrc(null);
      });
    return () => {
      cancelled = true;
    };
  }, [asset.id, asset.hasThumbnail, asset.updatedAt]);

  if (thumbSrc) {
    return (
      <img
        src={thumbSrc}
        alt={`Thumbnail for ${asset.originalName}`}
        referrerPolicy="no-referrer"
        className="w-20 h-12 object-cover rounded-md border border-white/10 bg-[#0A0C10] shrink-0"
      />
    );
  }

  return (
    <div className="w-20 h-12 rounded-md border border-white/10 bg-[#0A0C10] flex items-center justify-center shrink-0">
      <Film className="w-4 h-4 text-slate-500" aria-hidden="true" />
    </div>
  );
}

export function MediaLibraryPanel({
  projectId,
  lowDataMode,
  activeAudioId,
  activeVideoId,
  onSelectAudio,
  onSelectVideo,
  onMediaChanged,
}: MediaLibraryPanelProps) {
  const [assets, setAssets] = useState<MediaAsset[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [kindFilter, setKindFilter] = useState<MediaKind | ''>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<MediaSortOption>('newest');

  const [uploadTasks, setUploadTasks] = useState<UploadTask[]>([]);
  const [generateProxyOnUpload, setGenerateProxyOnUpload] = useState(false);
  const [stagingWarning, setStagingWarning] = useState<string | null>(null);

  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [replaceTarget, setReplaceTarget] = useState<MediaAsset | null>(null);

  const audioInputRef = useRef<HTMLInputElement | null>(null);
  const videoInputRef = useRef<HTMLInputElement | null>(null);
  const replaceInputRef = useRef<HTMLInputElement | null>(null);
  const abortControllersRef = useRef<Map<string, AbortController>>(new Map());
  const pausedFlagsRef = useRef<Set<string>>(new Set());

  const loadMedia = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const items = await listMediaAssets({
        projectId,
        kind: kindFilter,
        q: searchQuery,
        sort: sortBy,
      });
      setAssets(items);
      onMediaChanged(items);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load media library.');
    } finally {
      setLoading(false);
    }
  }, [projectId, kindFilter, searchQuery, sortBy, onMediaChanged]);

  useEffect(() => {
    void loadMedia();
  }, [loadMedia]);

  function stageFiles(fileList: FileList | null, mediaKind: MediaKind, replaceMedia: MediaAsset | null) {
    if (!fileList || fileList.length === 0) return;
    setStagingWarning(null);

    const chunkSize = lowDataMode ? 1024 * 1024 : 2 * 1024 * 1024;
    const nextTasks: UploadTask[] = [];
    const rejectedMessages: string[] = [];

    for (const file of Array.from(fileList)) {
      const validExt =
        mediaKind === 'audio' ? AUDIO_EXT_RE.test(file.name) : VIDEO_EXT_RE.test(file.name);
      if (!validExt) {
        rejectedMessages.push(
          `"${file.name}": unsupported ${mediaKind} format (${mediaKind === 'audio' ? 'MP3, WAV, AAC, FLAC' : 'MP4, MOV'} only).`
        );
        continue;
      }

      const maxBytes = mediaKind === 'audio' ? MAX_AUDIO_BYTES : MAX_VIDEO_BYTES;
      if (file.size <= 0 || file.size > maxBytes) {
        rejectedMessages.push(
          `"${file.name}": size must be between 1 B and ${Math.round(maxBytes / (1024 * 1024))} MB.`
        );
        continue;
      }

      const duplicateInQueue = uploadTasks.some(
        (t) =>
          t.state !== 'completed' &&
          buildFingerprint(t.file, t.mediaKind) === buildFingerprint(file, mediaKind) &&
          t.replaceMediaId === (replaceMedia?.id ?? null)
      );
      if (duplicateInQueue) {
        rejectedMessages.push(`"${file.name}" is already queued.`);
        continue;
      }

      nextTasks.push({
        localId: crypto.randomUUID(),
        file,
        projectId,
        mediaKind,
        replaceMediaId: replaceMedia?.id ?? null,
        generateLowDataProxy: mediaKind === 'video' && generateProxyOnUpload,
        uploadId: null,
        chunkSize,
        totalChunks: Math.ceil(file.size / chunkSize),
        uploadedBytes: 0,
        receivedChunks: [],
        state: 'staged',
        errorMessage: null,
      });
    }

    if (rejectedMessages.length > 0) {
      setStagingWarning(rejectedMessages.join(' '));
    }

    if (nextTasks.length > 0) {
      setUploadTasks((prev) => [...prev, ...nextTasks]);
    }
  }

  function updateTask(localId: string, updater: (task: UploadTask) => UploadTask) {
    setUploadTasks((prev) => prev.map((t) => (t.localId === localId ? updater(t) : t)));
  }

  async function runUploadTask(task: UploadTask) {
    pausedFlagsRef.current.delete(task.localId);
    const controller = new AbortController();
    abortControllersRef.current.set(task.localId, controller);

    updateTask(task.localId, (t) => ({
      ...t,
      state: 'uploading',
      errorMessage: null,
    }));

    try {
      const initRes = await initResumableUpload({
        projectId: task.projectId,
        mediaKind: task.mediaKind,
        originalName: task.file.name,
        mimeType: task.file.type || 'application/octet-stream',
        totalSize: task.file.size,
        chunkSize: task.chunkSize,
        clientFingerprint: buildFingerprint(task.file, task.mediaKind),
        replaceMediaId: task.replaceMediaId,
        generateLowDataProxy: task.generateLowDataProxy,
      });

      const receivedSet = new Set<number>(initRes.receivedChunks);

      updateTask(task.localId, (t) => ({
        ...t,
        uploadId: initRes.uploadId,
        chunkSize: initRes.chunkSize,
        totalChunks: initRes.totalChunks,
        uploadedBytes: initRes.uploadedBytes,
        receivedChunks: initRes.receivedChunks,
      }));

      for (let idx = 0; idx < initRes.totalChunks; idx++) {
        if (pausedFlagsRef.current.has(task.localId) || controller.signal.aborted) {
          updateTask(task.localId, (t) => ({ ...t, state: 'paused' }));
          return;
        }
        if (receivedSet.has(idx)) {
          continue;
        }

        const start = idx * initRes.chunkSize;
        const end = Math.min(task.file.size, start + initRes.chunkSize);
        const chunkBlob = task.file.slice(start, end);

        let chunkUploaded = false;
        let lastErr: unknown = null;

        for (let attempt = 0; attempt < 3; attempt++) {
          if (pausedFlagsRef.current.has(task.localId) || controller.signal.aborted) {
            updateTask(task.localId, (t) => ({ ...t, state: 'paused' }));
            return;
          }
          try {
            const chunkRes = await uploadChunkBinary(
              initRes.uploadId,
              idx,
              chunkBlob,
              controller.signal
            );
            updateTask(task.localId, (t) => ({
              ...t,
              uploadedBytes: chunkRes.uploadedBytes,
              receivedChunks: chunkRes.receivedChunks,
            }));
            chunkUploaded = true;
            break;
          } catch (err) {
            lastErr = err;
            if (controller.signal.aborted || pausedFlagsRef.current.has(task.localId)) {
              updateTask(task.localId, (t) => ({ ...t, state: 'paused' }));
              return;
            }
            if (attempt < 2) {
              await new Promise((r) => setTimeout(r, 500 * (attempt + 1)));
            }
          }
        }

        if (!chunkUploaded) {
          throw lastErr instanceof Error ? lastErr : new Error('Chunk transfer failed.');
        }
      }

      updateTask(task.localId, (t) => ({ ...t, state: 'finalizing' }));
      await completeResumableUpload(initRes.uploadId);

      updateTask(task.localId, (t) => ({
        ...t,
        state: 'completed',
        uploadedBytes: t.file.size,
      }));

      await loadMedia();
    } catch (err) {
      if (pausedFlagsRef.current.has(task.localId) || controller.signal.aborted) {
        updateTask(task.localId, (t) => ({ ...t, state: 'paused' }));
        return;
      }
      updateTask(task.localId, (t) => ({
        ...t,
        state: 'error',
        errorMessage: err instanceof Error ? err.message : 'Upload failed.',
      }));
    } finally {
      abortControllersRef.current.delete(task.localId);
    }
  }

  function handlePauseTask(localId: string) {
    pausedFlagsRef.current.add(localId);
    const ctrl = abortControllersRef.current.get(localId);
    if (ctrl) ctrl.abort();
    updateTask(localId, (t) => ({ ...t, state: 'paused' }));
  }

  async function handleCancelTask(task: UploadTask) {
    pausedFlagsRef.current.add(task.localId);
    const ctrl = abortControllersRef.current.get(task.localId);
    if (ctrl) ctrl.abort();
    if (task.uploadId && task.state !== 'completed') {
      await cancelResumableUpload(task.uploadId).catch(() => {});
    }
    setUploadTasks((prev) => prev.filter((t) => t.localId !== task.localId));
  }

  async function handleDeleteAsset(mediaId: string) {
    setDeletingId(mediaId);
    try {
      await deleteMediaAsset(mediaId);
      setConfirmDeleteId(null);
      await loadMedia();
    } finally {
      setDeletingId(null);
    }
  }

  const stagedTasks = uploadTasks.filter((t) => t.state === 'staged');

  return (
    <section className="bg-[#11141B] border border-white/[0.08] rounded-xl p-5 sm:p-6 space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <h2 className="font-display text-base font-semibold text-white">
            Project Media Library
          </h2>
          <p className="text-xs text-slate-400">
            Audio (MP3, WAV, AAC, FLAC) and Video (MP4, MOV). Files remain staged until you start upload.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <input
            ref={audioInputRef}
            type="file"
            accept=".mp3,.wav,.aac,.flac,audio/*"
            multiple
            className="hidden"
            onChange={(e) => {
              stageFiles(e.target.files, 'audio', null);
              e.target.value = '';
            }}
          />
          <input
            ref={videoInputRef}
            type="file"
            accept=".mp4,.mov,video/mp4,video/quicktime"
            multiple
            className="hidden"
            onChange={(e) => {
              stageFiles(e.target.files, 'video', null);
              e.target.value = '';
            }}
          />
          <input
            ref={replaceInputRef}
            type="file"
            accept={
              replaceTarget?.mediaKind === 'audio'
                ? '.mp3,.wav,.aac,.flac,audio/*'
                : '.mp4,.mov,video/mp4,video/quicktime'
            }
            className="hidden"
            onChange={(e) => {
              if (replaceTarget) {
                stageFiles(e.target.files, replaceTarget.mediaKind, replaceTarget);
              }
              setReplaceTarget(null);
              e.target.value = '';
            }}
          />

          <button
            type="button"
            onClick={() => audioInputRef.current?.click()}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg border border-white/15 text-slate-200 hover:bg-white/[0.06] transition-colors min-h-[40px]"
          >
            <Music className="w-3.5 h-3.5 text-[#E5A93C]" aria-hidden="true" />
            <span>Import Audio</span>
          </button>

          <button
            type="button"
            onClick={() => videoInputRef.current?.click()}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg border border-white/15 text-slate-200 hover:bg-white/[0.06] transition-colors min-h-[40px]"
          >
            <Film className="w-3.5 h-3.5 text-[#E5A93C]" aria-hidden="true" />
            <span>Import Video</span>
          </button>
        </div>
      </div>

      {stagingWarning && (
        <div role="alert" className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200">
          {stagingWarning}
        </div>
      )}

      {uploadTasks.length > 0 && (
        <div className="bg-[#0A0C10] border border-white/[0.08] rounded-xl p-4 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-0.5">
              <div className="text-xs font-semibold text-white">
                Resumable Upload Queue ({uploadTasks.length})
              </div>
              <div className="text-[11px] text-slate-400">
                Chunk size: {lowDataMode ? '1 MB (Low-Data Mode)' : '2 MB (Standard)'} · Original files preserved
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {stagedTasks.some((t) => t.mediaKind === 'video') && (
                <label className="inline-flex items-center gap-2 text-xs text-slate-300 cursor-pointer mr-2">
                  <input
                    type="checkbox"
                    checked={generateProxyOnUpload}
                    onChange={(e) => {
                      const next = e.target.checked;
                      setGenerateProxyOnUpload(next);
                      setUploadTasks((prev) =>
                        prev.map((t) =>
                          t.state === 'staged' && t.mediaKind === 'video'
                            ? { ...t, generateLowDataProxy: next }
                            : t
                        )
                      );
                    }}
                    className="h-3.5 w-3.5 accent-[#E5A93C]"
                  />
                  <span>Server 480p preview proxy (saves preview data)</span>
                </label>
              )}

              {stagedTasks.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    for (const t of stagedTasks) {
                      void runUploadTask(t);
                    }
                  }}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#E5A93C] text-[#0A0C10] hover:bg-[#eab654] transition-colors min-h-[38px]"
                >
                  <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Start Upload ({stagedTasks.length})</span>
                </button>
              )}

              {uploadTasks.some((t) => t.state === 'completed') && (
                <button
                  type="button"
                  onClick={() =>
                    setUploadTasks((prev) => prev.filter((t) => t.state !== 'completed'))
                  }
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white transition-colors"
                >
                  Clear Completed
                </button>
              )}
            </div>
          </div>

          <div className="divide-y divide-white/[0.06] border-t border-white/[0.06]">
            {uploadTasks.map((task) => {
              const pct =
                task.file.size > 0
                  ? Math.min(100, Math.round((task.uploadedBytes / task.file.size) * 100))
                  : 0;

              return (
                <div key={task.localId} className="py-3 space-y-2">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="min-w-0 space-y-0.5">
                      <div className="text-xs font-medium text-white truncate">
                        {task.replaceMediaId ? `Replace: ${task.file.name}` : task.file.name}
                      </div>
                      <div className="font-mono-tabular text-[11px] text-slate-400">
                        {task.mediaKind.toUpperCase()} · {formatBytes(task.uploadedBytes)} /{' '}
                        {formatBytes(task.file.size)} · {task.receivedChunks.length}/
                        {task.totalChunks} chunks · {pct}%
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {task.state === 'staged' && (
                        <button
                          type="button"
                          onClick={() => void runUploadTask(task)}
                          className="px-3 py-1.5 text-xs font-semibold rounded-md bg-[#E5A93C] text-[#0A0C10] hover:bg-[#eab654]"
                        >
                          Upload
                        </button>
                      )}
                      {task.state === 'uploading' && (
                        <button
                          type="button"
                          onClick={() => handlePauseTask(task.localId)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 text-xs rounded-md border border-white/15 text-slate-200 hover:bg-white/[0.06]"
                        >
                          <Pause className="w-3 h-3" aria-hidden="true" />
                          <span>Pause</span>
                        </button>
                      )}
                      {(task.state === 'paused' || task.state === 'error') && (
                        <button
                          type="button"
                          onClick={() => void runUploadTask(task)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold rounded-md bg-[#171B24] text-white hover:bg-[#222836]"
                        >
                          <RotateCcw className="w-3 h-3" aria-hidden="true" />
                          <span>{task.state === 'error' ? 'Retry' : 'Resume'}</span>
                        </button>
                      )}
                      {task.state === 'finalizing' && (
                        <span className="font-mono-tabular text-xs text-amber-300">
                          Validating via FFprobe...
                        </span>
                      )}
                      {task.state === 'completed' && (
                        <span className="font-mono-tabular text-xs text-emerald-400">
                          Verified
                        </span>
                      )}
                      {task.state !== 'finalizing' && (
                        <button
                          type="button"
                          aria-label={`Remove ${task.file.name} from upload queue`}
                          onClick={() => void handleCancelTask(task)}
                          className="p-1.5 rounded-md text-slate-400 hover:text-red-300 hover:bg-red-500/10"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="h-1.5 w-full bg-[#171B24] rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-[width] duration-150 ${
                        task.state === 'error'
                          ? 'bg-red-500'
                          : task.state === 'completed'
                          ? 'bg-emerald-500'
                          : 'bg-[#E5A93C]'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>

                  {task.errorMessage && (
                    <p className="text-xs text-red-300">{task.errorMessage}</p>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pt-2 border-t border-white/[0.08]">
        <div className="flex items-center gap-2 flex-1 max-w-md">
          <div className="relative flex-1">
            <Search
              className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search uploaded audio or video..."
              aria-label="Search project media"
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg bg-[#0A0C10] border border-white/10 text-white placeholder:text-slate-500 focus:outline-none focus:border-[#E5A93C]"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 p-1 bg-[#0A0C10] border border-white/[0.08] rounded-lg">
            {(
              [
                { value: '', label: 'All' },
                { value: 'audio', label: 'Audio' },
                { value: 'video', label: 'Video' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.label}
                type="button"
                onClick={() => setKindFilter(tab.value)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  kindFilter === tab.value
                    ? 'bg-[#171B24] text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <select
            aria-label="Sort media"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as MediaSortOption)}
            className="px-3 py-2 text-xs rounded-lg bg-[#0A0C10] border border-white/10 text-slate-200 focus:outline-none focus:border-[#E5A93C]"
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="name">Filename (A–Z)</option>
            <option value="size">File Size</option>
            <option value="duration">Duration</option>
          </select>

          <button
            type="button"
            onClick={() => void loadMedia()}
            aria-label="Refresh media library"
            className="p-2 rounded-lg border border-white/10 text-slate-300 hover:bg-white/[0.06] min-h-[36px] min-w-[36px] flex items-center justify-center"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {error && (
        <div role="alert" className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-200">
          {error}
        </div>
      )}

      {loading && assets.length === 0 ? (
        <div className="space-y-3" aria-busy="true">
          {[1, 2].map((n) => (
            <div key={n} className="h-16 rounded-lg bg-[#0A0C10] border border-white/[0.06] animate-pulse" />
          ))}
        </div>
      ) : assets.length === 0 ? (
        <div className="p-8 rounded-lg bg-[#0A0C10] border border-white/[0.06] text-center space-y-2">
          <p className="text-sm font-medium text-white">No media imported in this project yet</p>
          <p className="text-xs text-slate-400">
            Import an audio soundtrack (MP3, WAV, AAC, FLAC) and video clips (MP4, MOV) to inspect and preview them.
          </p>
        </div>
      ) : (
        <div className="divide-y divide-white/[0.06] border border-white/[0.08] rounded-xl bg-[#0A0C10]">
          {assets.map((asset) => {
            const isSelected =
              (asset.mediaKind === 'audio' && activeAudioId === asset.id) ||
              (asset.mediaKind === 'video' && activeVideoId === asset.id);

            return (
              <div
                key={asset.id}
                className={`p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-colors ${
                  isSelected ? 'bg-[#171B24]/70' : 'hover:bg-white/[0.02]'
                }`}
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  {asset.mediaKind === 'video' ? (
                    <MediaThumbnail asset={asset} />
                  ) : (
                    <div className="w-12 h-12 rounded-md border border-white/10 bg-[#11141B] flex items-center justify-center shrink-0">
                      <Music className="w-4 h-4 text-[#E5A93C]" aria-hidden="true" />
                    </div>
                  )}

                  <div className="min-w-0 space-y-1">
                    <div className="text-sm font-semibold text-white truncate">
                      {asset.originalName}
                    </div>
                    <div className="font-mono-tabular text-xs text-slate-400 flex flex-wrap items-center gap-x-2 gap-y-0.5">
                      <span>{asset.mediaKind === 'audio' ? 'Audio' : 'Video'}</span>
                      <span aria-hidden="true">·</span>
                      <span>{formatDuration(asset.durationSec)}</span>
                      <span aria-hidden="true">·</span>
                      <span>{formatBytes(asset.sizeBytes)}</span>
                      {asset.width && asset.height ? (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>
                            {asset.width}×{asset.height}
                          </span>
                        </>
                      ) : null}
                      <span aria-hidden="true">·</span>
                      <span>{asset.codecName}</span>
                      {asset.hasLowDataProxy && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-[#E5A93C]">480p Proxy Ready</span>
                        </>
                      )}
                      <span aria-hidden="true">·</span>
                      <span className="text-emerald-400 capitalize">{asset.uploadStatus}</span>
                    </div>
                  </div>
                </div>

                {confirmDeleteId === asset.id ? (
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs text-red-300">Remove file?</span>
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteId(null)}
                      className="px-3 py-1.5 text-xs text-slate-300 rounded-md hover:bg-white/[0.06]"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      disabled={deletingId === asset.id}
                      onClick={() => void handleDeleteAsset(asset.id)}
                      className="px-3 py-1.5 text-xs font-semibold rounded-md bg-red-600 text-white hover:bg-red-500 disabled:opacity-60"
                    >
                      {deletingId === asset.id ? 'Removing...' : 'Confirm'}
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() =>
                        asset.mediaKind === 'audio'
                          ? onSelectAudio(asset)
                          : onSelectVideo(asset)
                      }
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-md bg-[#171B24] text-white hover:bg-[#222836] transition-colors min-h-[38px]"
                    >
                      <Play className="w-3.5 h-3.5 text-[#E5A93C]" aria-hidden="true" />
                      <span>{asset.mediaKind === 'audio' ? 'Load Audio' : 'Preview Clip'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setReplaceTarget(asset);
                        replaceInputRef.current?.click();
                      }}
                      className="px-3 py-2 text-xs font-medium rounded-md border border-white/10 text-slate-300 hover:text-white hover:bg-white/[0.06] transition-colors min-h-[38px]"
                    >
                      Replace
                    </button>

                    <button
                      type="button"
                      onClick={() => setConfirmDeleteId(asset.id)}
                      aria-label={`Delete ${asset.originalName}`}
                      className="p-2 rounded-md text-slate-400 hover:text-red-300 hover:bg-red-500/10 transition-colors min-h-[38px] min-w-[38px] flex items-center justify-center"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
