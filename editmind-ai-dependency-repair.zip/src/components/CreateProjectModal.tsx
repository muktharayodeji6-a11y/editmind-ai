import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { EDITING_STYLE_LABELS } from '../types/studio';
import type {
  AspectRatio,
  EditingStyle,
  Project,
  TargetFps,
  TargetResolution,
} from '../types/studio';

interface ProjectFormValues {
  title: string;
  description: string;
  aspectRatio: AspectRatio;
  targetResolution: TargetResolution;
  targetFps: TargetFps;
  editingStyle: EditingStyle;
  lowDataMode: boolean;
}

interface CreateProjectModalProps {
  open: boolean;
  editingProject: Project | null;
  defaultLowDataMode: boolean;
  onClose: () => void;
  onSave: (values: ProjectFormValues) => Promise<void>;
}

const ASPECT_OPTIONS: { value: AspectRatio; label: string; hint: string }[] = [
  { value: '16:9', label: '16:9', hint: 'Widescreen' },
  { value: '9:16', label: '9:16', hint: 'Vertical' },
  { value: '1:1', label: '1:1', hint: 'Square' },
];

export function CreateProjectModal({
  open,
  editingProject,
  defaultLowDataMode,
  onClose,
  onSave,
}: CreateProjectModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [targetResolution, setTargetResolution] = useState<TargetResolution>('1080p');
  const [targetFps, setTargetFps] = useState<TargetFps>(30);
  const [editingStyle, setEditingStyle] = useState<EditingStyle>('beat-synchronized');
  const [lowDataMode, setLowDataMode] = useState(defaultLowDataMode);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    if (editingProject) {
      setTitle(editingProject.title);
      setDescription(editingProject.description);
      setAspectRatio(editingProject.aspectRatio);
      setTargetResolution(editingProject.targetResolution);
      setTargetFps(editingProject.targetFps);
      setEditingStyle(editingProject.editingStyle);
      setLowDataMode(editingProject.lowDataMode);
    } else {
      setTitle('');
      setDescription('');
      setAspectRatio('16:9');
      setTargetResolution('1080p');
      setTargetFps(30);
      setEditingStyle('beat-synchronized');
      setLowDataMode(defaultLowDataMode);
    }
    setError(null);
  }, [open, editingProject, defaultLowDataMode]);

  if (!open) return null;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      await onSave({
        title,
        description,
        aspectRatio,
        targetResolution,
        targetFps,
        editingStyle,
        lowDataMode,
      });
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save project.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="project-modal-title"
    >
      <div className="w-full max-w-xl bg-[#11141B] border border-white/10 rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.08]">
          <h2 id="project-modal-title" className="font-display text-lg font-semibold text-white">
            {editingProject ? 'Edit Project Settings' : 'Create Editing Project'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="p-2 rounded-md text-slate-400 hover:text-white hover:bg-white/[0.06] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[82vh] overflow-y-auto">
          {error && (
            <div role="alert" className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-200">
              {error}
            </div>
          )}

          <div className="space-y-1.5">
            <label htmlFor="proj-title" className="block text-xs font-medium text-slate-300">
              Project Title
            </label>
            <input
              id="proj-title"
              type="text"
              required
              maxLength={100}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Summer Tour Live Cut"
              className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white placeholder:text-slate-500 focus:outline-none focus:border-[#E5A93C]"
            />
          </div>

          <div className="space-y-1.5">
            <label htmlFor="proj-desc" className="block text-xs font-medium text-slate-300">
              Notes / Creative Brief (Optional)
            </label>
            <textarea
              id="proj-desc"
              rows={2}
              maxLength={400}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="High-energy chorus cuts with handheld performance clips."
              className="w-full px-3.5 py-2 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white placeholder:text-slate-500 focus:outline-none focus:border-[#E5A93C] resize-none"
            />
          </div>

          <div className="space-y-2">
            <span className="block text-xs font-medium text-slate-300">Aspect Ratio</span>
            <div className="grid grid-cols-3 gap-2.5">
              {ASPECT_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setAspectRatio(opt.value)}
                  className={`py-2.5 px-3 rounded-lg border text-left transition-colors ${
                    aspectRatio === opt.value
                      ? 'bg-[#E5A93C]/15 border-[#E5A93C] text-white'
                      : 'bg-[#0A0C10] border-white/10 text-slate-300 hover:border-white/25'
                  }`}
                >
                  <div className="font-mono-tabular text-sm font-semibold">{opt.label}</div>
                  <div className="text-[11px] text-slate-400">{opt.hint}</div>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label htmlFor="proj-res" className="block text-xs font-medium text-slate-300">
                Export Resolution
              </label>
              <select
                id="proj-res"
                value={targetResolution}
                onChange={(e) => setTargetResolution(e.target.value as TargetResolution)}
                className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white focus:outline-none focus:border-[#E5A93C]"
              >
                <option value="1080p">1080p Full HD</option>
                <option value="720p">720p HD (Lower Data)</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="proj-fps" className="block text-xs font-medium text-slate-300">
                Frame Rate
              </label>
              <select
                id="proj-fps"
                value={targetFps}
                onChange={(e) => setTargetFps(Number(e.target.value) as TargetFps)}
                className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white focus:outline-none focus:border-[#E5A93C]"
              >
                <option value={24}>24 fps (Cinema)</option>
                <option value={30}>30 fps (Standard)</option>
                <option value={60}>60 fps (High Motion)</option>
              </select>
            </div>
          </div>

          <div className="space-y-1.5">
            <label htmlFor="proj-style" className="block text-xs font-medium text-slate-300">
              Target Editing Style
            </label>
            <select
              id="proj-style"
              value={editingStyle}
              onChange={(e) => setEditingStyle(e.target.value as EditingStyle)}
              className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white focus:outline-none focus:border-[#E5A93C]"
            >
              {(Object.keys(EDITING_STYLE_LABELS) as EditingStyle[]).map((styleKey) => (
                <option key={styleKey} value={styleKey}>
                  {EDITING_STYLE_LABELS[styleKey].label}
                </option>
              ))}
            </select>
            <p className="text-xs text-slate-400">
              {EDITING_STYLE_LABELS[editingStyle].summary} Automated style execution activates in Milestone 5.
            </p>
          </div>

          <label className="flex items-start gap-3 p-3 rounded-lg bg-[#0A0C10] border border-white/[0.06] cursor-pointer">
            <input
              type="checkbox"
              checked={lowDataMode}
              onChange={(e) => setLowDataMode(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-white/20 accent-[#E5A93C]"
            />
            <span className="text-xs text-slate-300 leading-relaxed">
              <strong className="font-medium text-white block">Project Low-Data Mode</strong>
              Uses lower-bitrate preview streams and prompts before compressed or full-quality uploads.
            </span>
          </label>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/[0.08]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium rounded-lg border border-white/10 text-slate-300 hover:bg-white/[0.06] transition-colors min-h-[40px]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 text-xs font-semibold rounded-lg bg-[#E5A93C] text-[#0A0C10] hover:bg-[#eab654] disabled:opacity-60 transition-colors min-h-[40px]"
            >
              {saving ? 'Saving...' : editingProject ? 'Save Settings' : 'Create Project'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
