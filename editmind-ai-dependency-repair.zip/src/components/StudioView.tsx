import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeft, Check, Film, Sliders, X } from 'lucide-react';
import { getPlaybackGrant } from '../lib/api';
import { formatBytes, formatDuration } from '../lib/format';
import { EDITING_STYLE_LABELS } from '../types/studio';
import type {
  AspectRatio,
  EditingStyle,
  MediaAsset,
  PlaybackGrant,
  Project,
  TargetFps,
  TargetResolution,
  VideoSceneSegment,
} from '../types/studio';
import { AudioIntelligencePanel } from './AudioIntelligencePanel';
import { AudioPlayerBar } from './AudioPlayerBar';
import { MediaLibraryPanel } from './MediaLibraryPanel';
import { VideoIntelligencePanel } from './VideoIntelligencePanel';

interface StudioViewProps {
  project: Project | null;
  onBackToProjects: () => void;
  onUpdateProject: (
    projectId: string,
    patch: Partial<{
      title: string;
      description: string;
      aspectRatio: AspectRatio;
      targetResolution: TargetResolution;
      targetFps: TargetFps;
      editingStyle: EditingStyle;
      lowDataMode: boolean;
    }>
  ) => Promise<Project>;
}

const PIPELINE_MILESTONES = [
  {
    milestone: 'Milestone 1',
    title: 'Project Workspace & Configuration',
    state: 'Active',
    detail: 'Aspect ratio geometry, export resolution, FPS, editing style target, and data-saver profile persisted on server.',
  },
  {
    milestone: 'Milestone 2',
    title: 'Resumable Media Upload & Audio/Video Preview',
    state: 'Active',
    detail: 'Chunked MP3/WAV/AAC/FLAC & MP4/MOV ingest with FFprobe validation, range streaming, and audio player.',
  },
  {
    milestone: 'Milestone 3',
    title: 'Server-Side Beat & Music Structure Analysis',
    state: 'Active',
    detail: 'BPM detection, beat grid extraction, and intro/verse/chorus/drop segmentation.',
  },
  {
    milestone: 'Milestone 4',
    title: 'Video Scene & Motion Intelligence',
    state: 'Active',
    detail: 'Shot boundary detection, camera movement analysis, black-frame screening, and scene previews.',
  },
  {
    milestone: 'Milestone 5',
    title: 'Independent Auto-Editing & Transition Engine',
    state: 'Upcoming',
    detail: 'Synchronizes cuts and transitions to musical structure using your selected editing style.',
  },
  {
    milestone: 'Milestone 6',
    title: 'Multi-Track Timeline & Clip Trimming',
    state: 'Upcoming',
    detail: 'Interactive waveform, video/audio tracks, clip trimming, and undo/redo.',
  },
  {
    milestone: 'Milestone 7',
    title: 'Server-Side FFmpeg MP4 Export',
    state: 'Upcoming',
    detail: 'Validated H.264/AAC MP4 rendering with explicit on-demand mobile download.',
  },
];

function getDimensionsLabel(ratio: AspectRatio, res: TargetResolution): string {
  if (ratio === '16:9') return res === '1080p' ? '1920 × 1080' : '1280 × 720';
  if (ratio === '9:16') return res === '1080p' ? '1080 × 1920' : '720 × 1280';
  return res === '1080p' ? '1080 × 1080' : '720 × 720';
}

export function StudioView({ project, onBackToProjects, onUpdateProject }: StudioViewProps) {
  const [title, setTitle] = useState('');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [targetResolution, setTargetResolution] = useState<TargetResolution>('1080p');
  const [targetFps, setTargetFps] = useState<TargetFps>(30);
  const [editingStyle, setEditingStyle] = useState<EditingStyle>('beat-synchronized');
  const [lowDataMode, setLowDataMode] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [activeAudio, setActiveAudio] = useState<MediaAsset | null>(null);
  const [audioPlaySignal, setAudioPlaySignal] = useState(0);
  const [audioCurrentTime, setAudioCurrentTime] = useState(0);
  const [audioSeekRequest, setAudioSeekRequest] = useState<{
    timeSec: number;
    nonce: number;
  } | null>(null);

  const [activeVideo, setActiveVideo] = useState<MediaAsset | null>(null);
  const [videoGrant, setVideoGrant] = useState<PlaybackGrant | null>(null);
  const [preferProxyStream, setPreferProxyStream] = useState(false);
  const [videoError, setVideoError] = useState<string | null>(null);
  const [videoCurrentTimeSec, setVideoCurrentTimeSec] = useState(0);
  const [activeScenePreview, setActiveScenePreview] = useState<{
    sceneIndex: number;
    startSec: number;
    endSec: number;
  } | null>(null);
  const videoElementRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    if (!project) return;
    setTitle(project.title);
    setAspectRatio(project.aspectRatio);
    setTargetResolution(project.targetResolution);
    setTargetFps(project.targetFps);
    setEditingStyle(project.editingStyle);
    setLowDataMode(project.lowDataMode);
    setPreferProxyStream(project.lowDataMode);
    setSaveMessage(null);
    setError(null);
    setActiveAudio(null);
    setAudioCurrentTime(0);
    setAudioSeekRequest(null);
    setActiveVideo(null);
    setVideoGrant(null);
    setVideoError(null);
    setVideoCurrentTimeSec(0);
    setActiveScenePreview(null);
  }, [project?.id]);

  useEffect(() => {
    if (!activeVideo) {
      setVideoGrant(null);
      setVideoError(null);
      return;
    }

    let cancelled = false;
    setVideoError(null);

    getPlaybackGrant(activeVideo.id)
      .then((grant) => {
        if (!cancelled) setVideoGrant(grant);
      })
      .catch((err) => {
        if (!cancelled) {
          setVideoError(err instanceof Error ? err.message : 'Unable to load video preview.');
        }
      });

    return () => {
      cancelled = true;
    };
  }, [activeVideo?.id, activeVideo?.updatedAt]);

  const handleMediaChanged = useCallback((assets: MediaAsset[]) => {
    setActiveAudio((prev) => {
      if (!prev) return null;
      return assets.find((a) => a.id === prev.id) ?? null;
    });
    setActiveVideo((prev) => {
      if (!prev) return null;
      return assets.find((a) => a.id === prev.id) ?? null;
    });
  }, []);

  const handlePreviewVideoScene = useCallback((scene: VideoSceneSegment) => {
    setActiveScenePreview({
      sceneIndex: scene.sceneIndex,
      startSec: scene.startSec,
      endSec: scene.endSec,
    });
    const el = videoElementRef.current;
    if (el) {
      el.currentTime = scene.startSec;
      setVideoCurrentTimeSec(scene.startSec);
      void el.play().catch(() => {});
    }
  }, []);

  const handleSeekVideoTime = useCallback((timeSec: number) => {
    setActiveScenePreview(null);
    const el = videoElementRef.current;
    if (el) {
      el.currentTime = timeSec;
      setVideoCurrentTimeSec(timeSec);
      void el.play().catch(() => {});
    }
  }, []);

  if (!project) {
    return (
      <div className="bg-[#11141B] border border-white/[0.08] rounded-xl p-10 text-center space-y-4">
        <Film className="w-8 h-8 text-slate-500 mx-auto" aria-hidden="true" />
        <div className="space-y-1">
          <h1 className="font-display text-xl font-semibold text-white">No project selected</h1>
          <p className="text-sm text-slate-400">
            Select an existing project or create a new one to configure its studio canvas.
          </p>
        </div>
        <button
          type="button"
          onClick={onBackToProjects}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-lg bg-[#E5A93C] text-[#0A0C10] hover:bg-[#eab654] transition-colors min-h-[44px]"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          <span>Go to Projects</span>
        </button>
      </div>
    );
  }

  async function handleSaveConfig(e: React.FormEvent) {
    e.preventDefault();
    if (!project) return;
    setSaving(true);
    setSaveMessage(null);
    setError(null);
    try {
      await onUpdateProject(project.id, {
        title,
        aspectRatio,
        targetResolution,
        targetFps,
        editingStyle,
        lowDataMode,
      });
      setSaveMessage('Project configuration saved to server.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save configuration.');
    } finally {
      setSaving(false);
    }
  }

  const pixelDimensions = getDimensionsLabel(aspectRatio, targetResolution);
  const frameBoxClass =
    aspectRatio === '16:9'
      ? 'w-full max-w-xl aspect-video'
      : aspectRatio === '9:16'
      ? 'h-80 sm:h-96 aspect-[9/16]'
      : 'h-72 sm:h-80 aspect-square';

  const activeVideoSrc =
    videoGrant && preferProxyStream && videoGrant.proxyStreamUrl
      ? videoGrant.proxyStreamUrl
      : videoGrant?.streamUrl ?? undefined;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <button
            type="button"
            onClick={onBackToProjects}
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Back to Projects</span>
          </button>
          <h1 className="font-display text-2xl font-bold text-white tracking-tight">
            {project.title}
          </h1>
          <p className="font-mono-tabular text-xs text-slate-400">
            {aspectRatio} · {pixelDimensions} · {targetFps} fps ·{' '}
            {lowDataMode ? 'Low-Data Mode' : 'Full-Quality Mode'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        <section className="xl:col-span-7 space-y-5">
          <div className="bg-[#11141B] border border-white/[0.08] rounded-xl p-5 sm:p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-display text-sm font-semibold text-white">
                {activeVideo ? `Clip Preview · ${activeVideo.originalName}` : 'Output Frame Monitor'}
              </h2>
              <div className="flex items-center gap-3">
                {activeVideo && videoGrant?.proxyStreamUrl && (
                  <button
                    type="button"
                    onClick={() => setPreferProxyStream((v) => !v)}
                    className="px-2.5 py-1 text-[11px] font-medium rounded-md border border-white/15 text-slate-200 hover:bg-white/[0.06]"
                  >
                    {preferProxyStream ? 'Stream: 480p Proxy' : 'Stream: Original'}
                  </button>
                )}
                {activeVideo && activeScenePreview && (
                  <button
                    type="button"
                    onClick={() => setActiveScenePreview(null)}
                    className="px-2.5 py-1 text-[11px] font-medium rounded-md border border-[#E5A93C]/50 text-[#E5A93C] hover:bg-[#E5A93C]/10 whitespace-nowrap shrink-0"
                  >
                    Scene {activeScenePreview.sceneIndex + 1} · Clear Bounds
                  </button>
                )}
                {activeVideo && (
                  <button
                    type="button"
                    onClick={() => {
                      setActiveVideo(null);
                      setActiveScenePreview(null);
                      setVideoCurrentTimeSec(0);
                    }}
                    aria-label="Close video preview"
                    className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-white/[0.06]"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
                <span className="font-mono-tabular text-xs text-slate-400">
                  {activeVideo
                    ? `${formatDuration(activeVideo.durationSec)} · ${formatBytes(activeVideo.sizeBytes)}`
                    : pixelDimensions}
                </span>
              </div>
            </div>

            {videoError && (
              <div role="alert" className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-200">
                {videoError}
              </div>
            )}

            <div className="bg-[#07090D] border border-white/[0.06] rounded-lg min-h-[320px] flex items-center justify-center p-4 sm:p-6">
              {activeVideo && activeVideoSrc ? (
                <video
                  ref={videoElementRef}
                  key={activeVideoSrc}
                  src={activeVideoSrc}
                  poster={videoGrant?.thumbnailUrl || undefined}
                  controls
                  playsInline
                  preload="metadata"
                  className="max-h-[380px] w-full rounded-md bg-black object-contain"
                  onTimeUpdate={(e) => {
                    const t = e.currentTarget.currentTime;
                    setVideoCurrentTimeSec(t);
                    if (activeScenePreview && t >= activeScenePreview.endSec) {
                      e.currentTarget.pause();
                    }
                  }}
                  onError={() => setVideoError('Unable to stream selected video clip.')}
                />
              ) : (
                <div
                  className={`${frameBoxClass} border border-[#E5A93C]/60 bg-[#0D1017] relative flex flex-col items-center justify-center p-5 text-center transition-all`}
                >
                  <div className="absolute inset-3 border border-dashed border-white/10 pointer-events-none" />
                  <p className="font-mono-tabular text-sm font-semibold text-white">
                    {aspectRatio} Canvas Frame
                  </p>
                  <p className="font-mono-tabular text-xs text-slate-400 mt-1">
                    {pixelDimensions} at {targetFps} fps
                  </p>
                  <p className="text-xs text-slate-400 max-w-xs mt-3 leading-relaxed">
                    Import video clips in the Media Library below and select Preview Clip to stream via HTTP range requests.
                  </p>
                </div>
              )}
            </div>
          </div>

          <AudioPlayerBar
            asset={activeAudio}
            playSignal={audioPlaySignal}
            seekRequest={audioSeekRequest}
            onTimeUpdate={setAudioCurrentTime}
          />
        </section>

        <section className="xl:col-span-5 bg-[#11141B] border border-white/[0.08] rounded-xl p-5 sm:p-6 space-y-5">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#E5A93C]" aria-hidden="true" />
            <h2 className="font-display text-sm font-semibold text-white">
              Project Parameters
            </h2>
          </div>

          {error && (
            <div role="alert" className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-200">
              {error}
            </div>
          )}

          {saveMessage && (
            <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-200 flex items-center gap-2">
              <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{saveMessage}</span>
            </div>
          )}

          <form onSubmit={handleSaveConfig} className="space-y-4">
            <div className="space-y-1.5">
              <label htmlFor="studio-title" className="block text-xs font-medium text-slate-300">
                Title
              </label>
              <input
                id="studio-title"
                type="text"
                required
                maxLength={100}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white focus:outline-none focus:border-[#E5A93C]"
              />
            </div>

            <div className="space-y-1.5">
              <span className="block text-xs font-medium text-slate-300">Aspect Ratio</span>
              <div className="grid grid-cols-3 gap-2">
                {(['16:9', '9:16', '1:1'] as AspectRatio[]).map((ratio) => (
                  <button
                    key={ratio}
                    type="button"
                    onClick={() => setAspectRatio(ratio)}
                    className={`py-2 px-3 font-mono-tabular text-xs font-semibold rounded-lg border transition-colors ${
                      aspectRatio === ratio
                        ? 'bg-[#E5A93C]/15 border-[#E5A93C] text-white'
                        : 'bg-[#0A0C10] border-white/10 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    {ratio}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label htmlFor="studio-res" className="block text-xs font-medium text-slate-300">
                  Resolution
                </label>
                <select
                  id="studio-res"
                  value={targetResolution}
                  onChange={(e) => setTargetResolution(e.target.value as TargetResolution)}
                  className="w-full px-3 py-2.5 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white focus:outline-none focus:border-[#E5A93C]"
                >
                  <option value="1080p">1080p</option>
                  <option value="720p">720p</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label htmlFor="studio-fps" className="block text-xs font-medium text-slate-300">
                  Frame Rate
                </label>
                <select
                  id="studio-fps"
                  value={targetFps}
                  onChange={(e) => setTargetFps(Number(e.target.value) as TargetFps)}
                  className="w-full px-3 py-2.5 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white focus:outline-none focus:border-[#E5A93C]"
                >
                  <option value={24}>24 fps</option>
                  <option value={30}>30 fps</option>
                  <option value={60}>60 fps</option>
                </select>
              </div>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="studio-style" className="block text-xs font-medium text-slate-300">
                Editing Style Target
              </label>
              <select
                id="studio-style"
                value={editingStyle}
                onChange={(e) => setEditingStyle(e.target.value as EditingStyle)}
                className="w-full px-3 py-2.5 text-sm rounded-lg bg-[#0A0C10] border border-white/10 text-white focus:outline-none focus:border-[#E5A93C]"
              >
                {(Object.keys(EDITING_STYLE_LABELS) as EditingStyle[]).map((styleKey) => (
                  <option key={styleKey} value={styleKey}>
                    {EDITING_STYLE_LABELS[styleKey].label}
                  </option>
                ))}
              </select>
              <p className="text-xs text-slate-400">
                {EDITING_STYLE_LABELS[editingStyle].summary}
              </p>
            </div>

            <label className="flex items-start gap-3 p-3 rounded-lg bg-[#0A0C10] border border-white/[0.06] cursor-pointer">
              <input
                type="checkbox"
                checked={lowDataMode}
                onChange={(e) => setLowDataMode(e.target.checked)}
                className="mt-0.5 h-4 w-4 rounded border-white/20 accent-[#E5A93C]"
              />
              <span className="text-xs text-slate-300 leading-relaxed">
                <strong className="font-medium text-white block">Low-Data Mode</strong>
                Uses 1 MB upload chunks and prefers 480p preview proxies when available.
              </span>
            </label>

            <button
              type="submit"
              disabled={saving}
              className="w-full py-2.5 px-4 text-xs font-semibold rounded-lg bg-[#E5A93C] text-[#0A0C10] hover:bg-[#eab654] disabled:opacity-60 transition-colors min-h-[44px]"
            >
              {saving ? 'Saving Configuration...' : 'Save Configuration'}
            </button>
          </form>
        </section>
      </div>

      <AudioIntelligencePanel
        audioAsset={activeAudio}
        currentTimeSec={audioCurrentTime}
        onSeekTo={(timeSec) =>
          setAudioSeekRequest((prev) => ({
            timeSec,
            nonce: (prev?.nonce ?? 0) + 1,
          }))
        }
      />

      <VideoIntelligencePanel
        videoAsset={activeVideo}
        currentTimeSec={videoCurrentTimeSec}
        activeSceneIndex={activeScenePreview?.sceneIndex ?? null}
        onPreviewScene={handlePreviewVideoScene}
        onSeekToTime={handleSeekVideoTime}
      />

      <MediaLibraryPanel
        projectId={project.id}
        lowDataMode={lowDataMode}
        activeAudioId={activeAudio?.id ?? null}
        activeVideoId={activeVideo?.id ?? null}
        onSelectAudio={(asset) => {
          setActiveAudio(asset);
          setAudioPlaySignal((n) => n + 1);
        }}
        onSelectVideo={(asset) => {
          setActiveVideo(asset);
          setActiveScenePreview(null);
          setVideoCurrentTimeSec(0);
        }}
        onMediaChanged={handleMediaChanged}
      />

      <section className="bg-[#11141B] border border-white/[0.08] rounded-xl p-5 sm:p-6 space-y-3">
        <h2 className="font-display text-sm font-semibold text-white">Pipeline Readiness</h2>
        <div className="divide-y divide-white/[0.06] border border-white/[0.08] rounded-lg bg-[#0A0C10]">
          {PIPELINE_MILESTONES.map((step) => (
            <div
              key={step.milestone}
              className="px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
            >
              <div className="space-y-0.5">
                <div className="text-xs font-semibold text-white">
                  {step.milestone} · {step.title}
                </div>
                <p className="text-xs text-slate-400">{step.detail}</p>
              </div>
              <span
                className={`font-mono-tabular text-xs font-medium shrink-0 ${
                  step.state === 'Active' ? 'text-emerald-400' : 'text-slate-500'
                }`}
              >
                {step.state}
              </span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
