import { useState } from 'react';
import { ArrowRight, FolderPlus, Pencil, Search, Trash2 } from 'lucide-react';
import { EDITING_STYLE_LABELS } from '../types/studio';
import type { AspectRatio, Project } from '../types/studio';

interface ProjectsViewProps {
  projects: Project[];
  loading: boolean;
  error: string | null;
  searchQuery: string;
  aspectFilter: AspectRatio | '';
  onSearchChange: (value: string) => void;
  onAspectFilterChange: (value: AspectRatio | '') => void;
  onCreateNew: () => void;
  onOpenProject: (project: Project) => void;
  onEditProject: (project: Project) => void;
  onDeleteProject: (projectId: string) => Promise<void>;
}

const FILTER_TABS: { value: AspectRatio | ''; label: string }[] = [
  { value: '', label: 'All Ratios' },
  { value: '16:9', label: '16:9' },
  { value: '9:16', label: '9:16' },
  { value: '1:1', label: '1:1' },
];

export function ProjectsView({
  projects,
  loading,
  error,
  searchQuery,
  aspectFilter,
  onSearchChange,
  onAspectFilterChange,
  onCreateNew,
  onOpenProject,
  onEditProject,
  onDeleteProject,
}: ProjectsViewProps) {
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  async function handleConfirmDelete(id: string) {
    setDeletingId(id);
    try {
      await onDeleteProject(id);
      setConfirmDeleteId(null);
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="font-display text-2xl font-bold text-white tracking-tight">
            Editing Projects
          </h1>
          <p className="text-sm text-slate-400">
            Configure target export geometry, editing style, and bandwidth preferences per project.
          </p>
        </div>

        <button
          type="button"
          onClick={onCreateNew}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-lg bg-[#E5A93C] text-[#0A0C10] hover:bg-[#eab654] transition-colors whitespace-nowrap shrink-0 min-h-[44px]"
        >
          <FolderPlus className="w-4 h-4" aria-hidden="true" />
          <span>New Project</span>
        </button>
      </div>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-white/[0.08]">
        <div className="relative flex-1 max-w-md">
          <Search
            className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
            aria-hidden="true"
          />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search projects by title or brief..."
            aria-label="Search projects"
            className="w-full pl-10 pr-4 py-2 text-sm rounded-lg bg-[#11141B] border border-white/[0.08] text-white placeholder:text-slate-500 focus:outline-none focus:border-[#E5A93C]"
          />
        </div>

        <div className="flex items-center gap-1 p-1 bg-[#11141B] border border-white/[0.08] rounded-lg self-start">
          {FILTER_TABS.map((tab) => (
            <button
              key={tab.label}
              type="button"
              onClick={() => onAspectFilterChange(tab.value)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                aspectFilter === tab.value
                  ? 'bg-[#171B24] text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div role="alert" className="p-4 rounded-lg bg-red-500/10 border border-red-500/30 text-sm text-red-200">
          {error}
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4" aria-busy="true">
          {[1, 2, 3].map((idx) => (
            <div
              key={idx}
              className="h-44 rounded-xl bg-[#11141B] border border-white/[0.06] animate-pulse"
            />
          ))}
        </div>
      ) : projects.length === 0 ? (
        <div className="bg-[#11141B] border border-white/[0.08] rounded-xl p-10 text-center space-y-4">
          <div className="space-y-1.5 max-w-md mx-auto">
            <h2 className="font-display text-lg font-semibold text-white">
              {searchQuery || aspectFilter ? 'No matching projects' : 'Create your first project'}
            </h2>
            <p className="text-sm text-slate-400">
              {searchQuery || aspectFilter
                ? 'Try clearing your search query or selecting another aspect ratio filter.'
                : 'Projects store your target aspect ratio, export settings, editing style, and bandwidth preferences on the server.'}
            </p>
          </div>
          {!searchQuery && !aspectFilter && (
            <button
              type="button"
              onClick={onCreateNew}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold rounded-lg bg-[#E5A93C] text-[#0A0C10] hover:bg-[#eab654] transition-colors min-h-[44px]"
            >
              <FolderPlus className="w-4 h-4" aria-hidden="true" />
              <span>Create First Project</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {projects.map((project) => {
            const styleLabel = EDITING_STYLE_LABELS[project.editingStyle]?.label ?? project.editingStyle;
            const formattedDate = new Date(project.updatedAt).toLocaleDateString(undefined, {
              month: 'short',
              day: 'numeric',
              year: 'numeric',
            });

            return (
              <article
                key={project.id}
                className="bg-[#11141B] border border-white/[0.08] rounded-xl p-5 flex flex-col justify-between gap-5 hover:border-white/20 transition-colors"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 space-y-1">
                      <h2 className="font-display text-base font-semibold text-white truncate">
                        {project.title}
                      </h2>
                      <p className="font-mono-tabular text-xs text-slate-400">
                        {project.aspectRatio} · {project.targetResolution} · {project.targetFps} fps
                      </p>
                    </div>
                  </div>

                  {project.description ? (
                    <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                      {project.description}
                    </p>
                  ) : (
                    <p className="text-xs text-slate-500 italic">No creative brief added.</p>
                  )}

                  <div className="text-xs text-slate-400 flex flex-wrap items-center gap-x-2 gap-y-1">
                    <span>{styleLabel}</span>
                    <span aria-hidden="true">·</span>
                    <span>{project.lowDataMode ? 'Low-Data On' : 'Original Quality'}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-tabular">Updated {formattedDate}</span>
                  </div>
                </div>

                {confirmDeleteId === project.id ? (
                  <div className="pt-3 border-t border-white/[0.08] flex items-center justify-between gap-2">
                    <span className="text-xs text-red-300">Delete this project?</span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(null)}
                        className="px-3 py-1.5 text-xs text-slate-300 rounded-md hover:bg-white/[0.06] transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        disabled={deletingId === project.id}
                        onClick={() => handleConfirmDelete(project.id)}
                        className="px-3 py-1.5 text-xs font-semibold rounded-md bg-red-600 text-white hover:bg-red-500 disabled:opacity-60 transition-colors"
                      >
                        {deletingId === project.id ? 'Deleting...' : 'Confirm'}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="pt-3 border-t border-white/[0.08] flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => onEditProject(project)}
                        aria-label={`Edit settings for ${project.title}`}
                        className="p-2 rounded-md text-slate-400 hover:text-white hover:bg-white/[0.06] transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(project.id)}
                        aria-label={`Delete ${project.title}`}
                        className="p-2 rounded-md text-slate-400 hover:text-red-300 hover:bg-red-500/10 transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => onOpenProject(project)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-md bg-[#171B24] text-white hover:bg-[#202633] transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
                    >
                      <span>Open Studio</span>
                      <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                    </button>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
