export type AspectRatio = '16:9' | '9:16' | '1:1';
export type TargetResolution = '720p' | '1080p';
export type TargetFps = 24 | 30 | 60;
export type EditingStyle =
  | 'beat-synchronized'
  | 'cinematic'
  | 'dynamic'
  | 'slow-motion'
  | 'music-video'
  | 'social-media'
  | 'professional-montage';

export interface User {
  id: string;
  email: string;
  displayName: string;
  role: 'creator' | 'admin';
  lowDataMode: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Project {
  id: string;
  userId: string;
  title: string;
  description: string;
  aspectRatio: AspectRatio;
  targetResolution: TargetResolution;
  targetFps: TargetFps;
  editingStyle: EditingStyle;
  lowDataMode: boolean;
  status: string;
  createdAt: string;
  updatedAt: string;
}

export interface BinaryProbe {
  name: string;
  available: boolean;
  version: string | null;
}

export interface EngineModuleDescriptor {
  id: string;
  name: string;
  milestoneTarget: number;
  status: 'planned' | 'active';
  provider: string;
  summary: string;
  outputs: string[];
  externalDependencyPolicy: string;
}

export interface SystemCapabilities {
  milestone: number;
  runtime: {
    nodeVersion: string;
    platform: string;
    arch: string;
    databaseEngine: string;
  };
  binaries: BinaryProbe[];
  storage: {
    dataDir: string;
    availableBytes: number | null;
    totalBytes: number | null;
    ephemeralWarning: string;
  };
  engineModules: EngineModuleDescriptor[];
  mobileOptimizationPolicy: {
    heavyProcessingLocation: string;
    autoModelDownloadsOnClient: boolean;
    autoMediaUploads: boolean;
    backgroundSync: boolean;
    resumableUploadsTargetMilestone: number;
  };
  externalAiPolicy: {
    geminiMandatory: boolean;
    geminiConfigured: boolean;
    coreEngineIndependence: string;
  };
}

export const EDITING_STYLE_LABELS: Record<EditingStyle, { label: string; summary: string }> = {
  'beat-synchronized': {
    label: 'Beat-Synchronized',
    summary: 'Hard cuts and transitions locked tightly to rhythmic transients and downbeats.',
  },
  cinematic: {
    label: 'Cinematic',
    summary: 'Longer shot holds, restrained crossfades, and emotional pacing aligned to song phrases.',
  },
  dynamic: {
    label: 'Dynamic',
    summary: 'High-motion shot selection with accelerating cut cadence during chorus drops.',
  },
  'slow-motion': {
    label: 'Slow Motion',
    summary: 'Time-remapped sustained framing suited for atmospheric verses and vocal swells.',
  },
  'music-video': {
    label: 'Music Video',
    summary: 'Balanced narrative and performance pacing anchored to verse/chorus structure.',
  },
  'social-media': {
    label: 'Social Media',
    summary: 'Fast opening hook and compact beat-driven framing for vertical or square feeds.',
  },
  'professional-montage': {
    label: 'Professional Montage',
    summary: 'Clean editorial continuity across multi-clip event, travel, or commercial footage.',
  },
};

export type MediaKind = 'audio' | 'video';
export type MediaSortOption = 'newest' | 'oldest' | 'name' | 'size' | 'duration';

export interface MediaAsset {
  id: string;
  userId: string;
  projectId: string;
  mediaKind: MediaKind;
  originalName: string;
  mimeType: string;
  extension: string;
  sizeBytes: number;
  durationSec: number;
  codecName: string;
  width: number | null;
  height: number | null;
  sampleRate: number | null;
  channels: number | null;
  hasThumbnail: boolean;
  hasLowDataProxy: boolean;
  uploadStatus: string;
  createdAt: string;
  updatedAt: string;
}

export interface PlaybackGrant {
  expiresAt: string;
  streamUrl: string;
  proxyStreamUrl: string | null;
  thumbnailUrl: string | null;
}

export type UploadTaskState =
  | 'staged'
  | 'uploading'
  | 'paused'
  | 'finalizing'
  | 'completed'
  | 'error';

export interface UploadTask {
  localId: string;
  file: File;
  projectId: string;
  mediaKind: MediaKind;
  replaceMediaId: string | null;
  generateLowDataProxy: boolean;
  uploadId: string | null;
  chunkSize: number;
  totalChunks: number;
  uploadedBytes: number;
  receivedChunks: number[];
  state: UploadTaskState;
  errorMessage: string | null;
}

export interface TempoSegment {
  startSec: number;
  endSec: number;
  bpm: number;
}

export interface TempoChangeEvent {
  timestampSec: number;
  fromBpm: number;
  toBpm: number;
  deltaPercent: number;
}

export interface AudioSignificantEvent {
  type: 'silence' | 'energy-surge' | 'energy-drop' | 'tempo-shift';
  startSec: number;
  endSec: number;
  intensity: number;
  summary: string;
}

export interface BeatMarker {
  timestampSec: number;
  strength: number;
  isDownbeat: boolean;
  isStrong: boolean;
  intervalSec: number;
}

export interface BeatAnalysisResult {
  bpm: number;
  bpmConfidence: number;
  rhythmPattern: 'steady-4/4' | 'steady-3/4' | 'syncopated' | 'tempo-shifting' | 'weak-or-irregular';
  rhythmRegularity: number;
  averageBeatIntervalSec: number;
  beatTimestampsSec: number[];
  downbeatTimestampsSec: number[];
  strongBeatTimestampsSec: number[];
  beats: BeatMarker[];
  downbeatConfidence: number;
  energyPeaksSec: number[];
  tempoSegments: TempoSegment[];
  tempoChanges: TempoChangeEvent[];
  events: AudioSignificantEvent[];
}

export type MusicSectionLabel =
  | 'intro'
  | 'verse'
  | 'chorus'
  | 'build-up'
  | 'drop'
  | 'break'
  | 'outro'
  | 'uncertain';

export interface MusicSectionSegment {
  label: MusicSectionLabel;
  startSec: number;
  endSec: number;
  energyScore: number;
  confidence: number;
  rationale: string;
  uncertain?: boolean;
  secondaryLabel?: MusicSectionLabel;
}

export interface AudioWaveformPoint {
  timeSec: number;
  peak: number;
  rms: number;
}

export interface EnergyFramePoint {
  timeSec: number;
  rms: number;
  lowEnergy: number;
  midHighEnergy: number;
}

export interface StructuredAudioAnalysis {
  version: string;
  mediaId: string;
  durationSec: number;
  sampleRateAnalyzed: number;
  processingMs: number;
  analyzedAt: string;
  beatIntelligence: BeatAnalysisResult;
  sections: MusicSectionSegment[];
  overallStructureConfidence: number;
  energySummary: {
    meanRms: number;
    peakRms: number;
    dynamicRangeDb: number;
  };
  waveform: AudioWaveformPoint[];
  energyCurve: EnergyFramePoint[];
  notes: string[];
}

export type VideoOrientation = 'landscape' | 'portrait' | 'square';

export type CameraMovementType =
  | 'static'
  | 'pan-left'
  | 'pan-right'
  | 'tilt-up'
  | 'tilt-down'
  | 'zoom-in'
  | 'zoom-out'
  | 'handheld-dynamic'
  | 'mixed';

export type SceneTransitionBoundary = 'start-of-clip' | 'hard-cut' | 'gradual-transition' | 'black-gap';

export type SceneUsabilityIssue =
  | 'black-frames'
  | 'frozen-static'
  | 'low-detail-blur'
  | 'underexposed'
  | 'overexposed';

export interface VideoStreamMetadata {
  width: number;
  height: number;
  encodedWidth: number;
  encodedHeight: number;
  rotationDeg: number;
  orientation: VideoOrientation;
  aspectRatioLabel: string;
  fps: number;
  durationSec: number;
  codecName: string;
  pixFmt: string;
  bitrateKbps: number | null;
  hasAudio: boolean;
  audioCodec: string | null;
}

export interface SceneVisualDetections {
  personLikelihood: number;
  personLikely: boolean;
  foregroundObjectLikelihood: number;
  salientRegionCount: number;
  salientFocusPoint: { x: number; y: number } | null;
  framingBalance: 'centered' | 'rule-of-thirds' | 'distributed' | 'minimal';
}

export interface VideoSceneSegment {
  sceneIndex: number;
  assetId: string;
  startSec: number;
  endSec: number;
  durationSec: number;
  boundaryType: SceneTransitionBoundary;
  boundaryConfidence: number;
  representativeTimestampSec: number;
  thumbnailAvailable: boolean;
  thumbnailUrl?: string | null;
  motionIntensity: number;
  cameraMovement: CameraMovementType;
  cameraMovementConfidence: number;
  cameraPanSpeed: number;
  cameraZoomRate: number;
  visualQualityScore: number;
  interestScore: number;
  avgBrightness: number;
  avgContrast: number;
  avgSharpness: number;
  colorfulness: number;
  usable: boolean;
  unusableReason: string | null;
  issues: SceneUsabilityIssue[];
  detections: SceneVisualDetections;
  summary: string;
}

export interface VideoSignificantMoment {
  timestampSec: number;
  sceneIndex: number;
  type: 'peak-motion' | 'subject-focus' | 'high-interest-peak' | 'scene-transition';
  score: number;
  summary: string;
}

export interface VideoTimelineSamplePoint {
  timeSec: number;
  motionIntensity: number;
  brightness: number;
  interestScore: number;
}

export interface VideoDetectionCapabilities {
  sceneDetectionMethod: string;
  cameraMotionMethod: string;
  personDetectionMethod: string;
  objectDetectionMethod: string;
  neuralModelsInstalled: boolean;
  honestyNote: string;
}

export interface StructuredVideoAnalysis {
  version: string;
  mediaId: string;
  durationSec: number;
  processingMs: number;
  analyzedAt: string;
  sampleFpsUsed: number;
  metadata: VideoStreamMetadata;
  sceneCount: number;
  usableSceneCount: number;
  usableDurationSec: number;
  blackDurationSec: number;
  frozenDurationSec: number;
  averageMotionIntensity: number;
  averageQualityScore: number;
  dominantCameraMovement: CameraMovementType;
  scenes: VideoSceneSegment[];
  blackIntervals: Array<{ startSec: number; endSec: number; durationSec: number }>;
  frozenIntervals: Array<{ startSec: number; endSec: number; durationSec: number }>;
  significantMoments: VideoSignificantMoment[];
  timelineCurve: VideoTimelineSamplePoint[];
  capabilities: VideoDetectionCapabilities;
  notes: string[];
}


