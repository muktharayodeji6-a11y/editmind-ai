import type {
  AspectRatio,
  EditingStyle,
  MediaAsset,
  MediaKind,
  MediaSortOption,
  PlaybackGrant,
  Project,
  StructuredAudioAnalysis,
  StructuredVideoAnalysis,
  SystemCapabilities,
  TargetFps,
  TargetResolution,
  User,
} from '../types/studio';

let memoryAuthToken: string | null = null;

export function setAuthToken(token: string | null): void {
  memoryAuthToken = token;
}

export function getAuthToken(): string | null {
  return memoryAuthToken;
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (init.body && typeof init.body === 'string' && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }
  if (memoryAuthToken) {
    headers.set('Authorization', `Bearer ${memoryAuthToken}`);
  }

  const response = await fetch(path, {
    ...init,
    headers,
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message =
      typeof payload?.error === 'string'
        ? payload.error
        : `Request failed with status ${response.status}`;
    throw new Error(message);
  }
  return payload as T;
}

export interface AuthResponse {
  user: User;
  token: string;
  expiresAt: string;
}

export async function registerAccount(input: {
  email: string;
  displayName: string;
  password: string;
  lowDataMode: boolean;
}): Promise<AuthResponse> {
  const result = await request<AuthResponse>('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify(input),
  });
  setAuthToken(result.token);
  return result;
}

export async function loginAccount(input: {
  email: string;
  password: string;
}): Promise<AuthResponse> {
  const result = await request<AuthResponse>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify(input),
  });
  setAuthToken(result.token);
  return result;
}

export async function logoutAccount(): Promise<void> {
  try {
    if (memoryAuthToken) {
      await request<{ ok: boolean }>('/api/auth/logout', { method: 'POST' });
    }
  } finally {
    setAuthToken(null);
  }
}

export async function fetchCurrentUser(): Promise<User> {
  const result = await request<{ user: User }>('/api/auth/me');
  return result.user;
}

export async function updatePreferences(input: {
  displayName?: string;
  lowDataMode?: boolean;
}): Promise<User> {
  const result = await request<{ user: User }>('/api/auth/preferences', {
    method: 'PATCH',
    body: JSON.stringify(input),
  });
  return result.user;
}

export async function changePassword(input: {
  currentPassword: string;
  newPassword: string;
}): Promise<void> {
  await request<{ ok: boolean }>('/api/auth/change-password', {
    method: 'POST',
    body: JSON.stringify(input),
  });
}

export async function listProjects(params?: {
  q?: string;
  aspectRatio?: AspectRatio | '';
}): Promise<Project[]> {
  const search = new URLSearchParams();
  if (params?.q) search.set('q', params.q);
  if (params?.aspectRatio) search.set('aspectRatio', params.aspectRatio);
  const query = search.toString();
  const result = await request<{ projects: Project[] }>(
    query ? `/api/projects?${query}` : '/api/projects'
  );
  return result.projects;
}

export async function createProject(input: {
  title: string;
  description: string;
  aspectRatio: AspectRatio;
  targetResolution: TargetResolution;
  targetFps: TargetFps;
  editingStyle: EditingStyle;
  lowDataMode: boolean;
}): Promise<Project> {
  const result = await request<{ project: Project }>('/api/projects', {
    method: 'POST',
    body: JSON.stringify(input),
  });
  return result.project;
}

export async function updateProject(
  projectId: string,
  input: Partial<{
    title: string;
    description: string;
    aspectRatio: AspectRatio;
    targetResolution: TargetResolution;
    targetFps: TargetFps;
    editingStyle: EditingStyle;
    lowDataMode: boolean;
  }>
): Promise<Project> {
  const result = await request<{ project: Project }>(`/api/projects/${encodeURIComponent(projectId)}`, {
    method: 'PATCH',
    body: JSON.stringify(input),
  });
  return result.project;
}

export async function deleteProject(projectId: string): Promise<void> {
  await request<{ ok: boolean }>(`/api/projects/${encodeURIComponent(projectId)}`, {
    method: 'DELETE',
  });
}

export async function fetchSystemCapabilities(): Promise<SystemCapabilities> {
  return request<SystemCapabilities>('/api/system/capabilities');
}

export async function listMediaAssets(params: {
  projectId: string;
  kind?: MediaKind | '';
  q?: string;
  sort?: MediaSortOption;
}): Promise<MediaAsset[]> {
  const search = new URLSearchParams();
  search.set('projectId', params.projectId);
  if (params.kind) search.set('kind', params.kind);
  if (params.q) search.set('q', params.q);
  if (params.sort) search.set('sort', params.sort);
  const result = await request<{ media: MediaAsset[] }>(`/api/media?${search.toString()}`);
  return result.media;
}

export async function getMediaDetails(mediaId: string): Promise<MediaAsset> {
  const result = await request<{ media: MediaAsset }>(`/api/media/${encodeURIComponent(mediaId)}`);
  return result.media;
}

export async function getPlaybackGrant(mediaId: string): Promise<PlaybackGrant> {
  return request<PlaybackGrant>(`/api/media/${encodeURIComponent(mediaId)}/playback-grant`, {
    method: 'POST',
  });
}

export async function deleteMediaAsset(mediaId: string): Promise<void> {
  await request<{ ok: boolean }>(`/api/media/${encodeURIComponent(mediaId)}`, {
    method: 'DELETE',
  });
}

export async function initResumableUpload(input: {
  projectId: string;
  mediaKind: MediaKind;
  originalName: string;
  mimeType: string;
  totalSize: number;
  chunkSize: number;
  clientFingerprint: string;
  replaceMediaId?: string | null;
  generateLowDataProxy?: boolean;
}): Promise<{
  resumed: boolean;
  uploadId: string;
  chunkSize: number;
  totalChunks: number;
  totalSize: number;
  uploadedBytes: number;
  receivedChunks: number[];
}> {
  return request('/api/media/uploads/init', {
    method: 'POST',
    body: JSON.stringify(input),
  });
}

export async function getUploadStatus(uploadId: string): Promise<{
  uploadId: string;
  status: string;
  totalSize: number;
  chunkSize: number;
  totalChunks: number;
  uploadedBytes: number;
  receivedChunks: number[];
}> {
  return request(`/api/media/uploads/${encodeURIComponent(uploadId)}/status`);
}

export async function uploadChunkBinary(
  uploadId: string,
  chunkIndex: number,
  chunkBlob: Blob,
  signal?: AbortSignal
): Promise<{
  uploadId: string;
  chunkIndex: number;
  uploadedBytes: number;
  totalSize: number;
  receivedChunks: number[];
}> {
  return request(
    `/api/media/uploads/${encodeURIComponent(uploadId)}/chunk?index=${chunkIndex}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/octet-stream',
      },
      body: chunkBlob,
      signal,
    }
  );
}

export async function completeResumableUpload(uploadId: string): Promise<MediaAsset> {
  const result = await request<{ media: MediaAsset }>(
    `/api/media/uploads/${encodeURIComponent(uploadId)}/complete`,
    { method: 'POST' }
  );
  return result.media;
}

export async function cancelResumableUpload(uploadId: string): Promise<void> {
  await request<{ ok: boolean }>(`/api/media/uploads/${encodeURIComponent(uploadId)}`, {
    method: 'DELETE',
  });
}

export async function getAudioAnalysisCache(mediaId: string): Promise<{
  status: 'ready' | 'not_analyzed';
  cached: boolean;
  analysis: StructuredAudioAnalysis | null;
}> {
  return request(`/api/audio-analysis/${encodeURIComponent(mediaId)}`);
}

export async function runAudioAnalysis(
  mediaId: string,
  force = false
): Promise<{
  status: 'ready';
  cached: boolean;
  analysis: StructuredAudioAnalysis;
}> {
  return request(`/api/audio-analysis/${encodeURIComponent(mediaId)}/analyze`, {
    method: 'POST',
    body: JSON.stringify({ force }),
  });
}

export async function getVideoAnalysisCache(mediaId: string): Promise<{
  status: 'ready' | 'not_analyzed';
  cached: boolean;
  analysis: StructuredVideoAnalysis | null;
}> {
  return request(`/api/video-analysis/${encodeURIComponent(mediaId)}`);
}

export async function runVideoAnalysis(
  mediaId: string,
  force = false
): Promise<{
  status: 'ready';
  cached: boolean;
  analysis: StructuredVideoAnalysis;
}> {
  return request(`/api/video-analysis/${encodeURIComponent(mediaId)}/analyze`, {
    method: 'POST',
    body: JSON.stringify({ force }),
  });
}


