import { useCallback, useEffect, useState } from 'react';
import { FolderKanban, Film, LogOut, Menu, Server, User as UserIcon, X } from 'lucide-react';
import { AccountView } from './components/AccountView';
import { ArchitectureView } from './components/ArchitectureView';
import { AuthPortal } from './components/AuthPortal';
import { CreateProjectModal } from './components/CreateProjectModal';
import { ProjectsView } from './components/ProjectsView';
import { StudioView } from './components/StudioView';
import {
  createProject,
  deleteProject,
  listProjects,
  logoutAccount,
  updateProject,
} from './lib/api';
import type {
  AspectRatio,
  EditingStyle,
  Project,
  TargetFps,
  TargetResolution,
  User,
} from './types/studio';

type WorkspaceTab = 'projects' | 'studio' | 'architecture' | 'account';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('projects');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [projects, setProjects] = useState<Project[]>([]);
  const [projectsLoading, setProjectsLoading] = useState(false);
  const [projectsError, setProjectsError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [aspectFilter, setAspectFilter] = useState<AspectRatio | ''>('');

  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);

  const loadProjects = useCallback(async (q: string, ratio: AspectRatio | '') => {
    setProjectsLoading(true);
    setProjectsError(null);
    try {
      const items = await listProjects({ q, aspectRatio: ratio });
      setProjects(items);
    } catch (err) {
      setProjectsError(err instanceof Error ? err.message : 'Unable to load projects.');
    } finally {
      setProjectsLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!user) return;
    void loadProjects(searchQuery, aspectFilter);
  }, [user, searchQuery, aspectFilter, loadProjects]);

  const selectedProject = projects.find((p) => p.id === selectedProjectId) ?? null;

  async function handleSaveProjectModal(values: {
    title: string;
    description: string;
    aspectRatio: AspectRatio;
    targetResolution: TargetResolution;
    targetFps: TargetFps;
    editingStyle: EditingStyle;
    lowDataMode: boolean;
  }) {
    if (editingProject) {
      const updated = await updateProject(editingProject.id, values);
      setProjects((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    } else {
      const created = await createProject(values);
      setProjects((prev) => [created, ...prev]);
      setSelectedProjectId(created.id);
      setActiveTab('studio');
    }
  }

  async function handleInlineUpdateProject(
    projectId: string,
    patch: Partial<{
      title: string;
      description: string;
      aspectRatio: AspectRatio;
      targetResolution: TargetResolution;
      targetFps: TargetFps;
      editingStyle: EditingStyle;
      lowDataMode: boolean;
    }>
  ): Promise<Project> {
    const updated = await updateProject(projectId, patch);
    setProjects((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    return updated;
  }

  async function handleDeleteProject(projectId: string) {
    await deleteProject(projectId);
    setProjects((prev) => prev.filter((p) => p.id !== projectId));
    if (selectedProjectId === projectId) {
      setSelectedProjectId(null);
    }
  }

  async function handleLogout() {
    await logoutAccount();
    setUser(null);
    setProjects([]);
    setSelectedProjectId(null);
    setActiveTab('projects');
  }

  if (!user) {
    return (
      <AuthPortal
        onAuthenticated={(authenticatedUser) => {
          setUser(authenticatedUser);
          setActiveTab('projects');
        }}
      />
    );
  }

  const navItems: { id: WorkspaceTab; label: string; icon: typeof FolderKanban }[] = [
    { id: 'projects', label: 'Projects', icon: FolderKanban },
    { id: 'studio', label: 'Studio', icon: Film },
    { id: 'architecture', label: 'Architecture', icon: Server },
    { id: 'account', label: 'Account', icon: UserIcon },
  ];

  const breadcrumbLabel =
    activeTab === 'projects'
      ? 'Projects'
      : activeTab === 'studio'
      ? selectedProject
        ? `Studio / ${selectedProject.title}`
        : 'Studio'
      : activeTab === 'architecture'
      ? 'Architecture & Engine'
      : 'Account';

  return (
    <div className="min-h-screen bg-[#0A0C10] text-[#F1F5F9] flex">
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 bg-[#11141B] border-r border-white/[0.08]">
        <div className="px-6 py-5 border-b border-white/[0.08]">
          <span className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap">
            EDITMIND AI
          </span>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1" aria-label="Workspace navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap min-h-[42px] ${
                  isActive
                    ? 'bg-[#171B24] text-white'
                    : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#E5A93C]' : 'text-slate-500'}`}
                  aria-hidden="true"
                />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-white/[0.08] space-y-3">
          <div className="space-y-0.5 min-w-0">
            <div className="text-xs font-semibold text-white truncate">{user.displayName}</div>
            <div className="text-[11px] text-slate-400 truncate">
              {user.lowDataMode ? 'Low-Data Mode On' : 'Standard Bandwidth'}
            </div>
          </div>
          <button
            type="button"
            onClick={() => void handleLogout()}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-lg border border-white/10 text-slate-300 hover:text-white hover:bg-white/[0.05] transition-colors min-h-[40px]"
          >
            <LogOut className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/70"
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative w-64 max-w-[80vw] bg-[#11141B] border-r border-white/[0.08] flex flex-col z-10">
            <div className="px-5 py-4 border-b border-white/[0.08] flex items-center justify-between">
              <span className="font-display text-base font-bold text-white">EDITMIND AI</span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close navigation"
                className="p-2 rounded-md text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3.5 py-3 text-sm font-medium rounded-lg min-h-[44px] ${
                      isActive
                        ? 'bg-[#171B24] text-white'
                        : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
                    }`}
                  >
                    <Icon
                      className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#E5A93C]' : 'text-slate-500'}`}
                      aria-hidden="true"
                    />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="p-4 border-t border-white/[0.08]">
              <button
                type="button"
                onClick={() => void handleLogout()}
                className="w-full flex items-center gap-2 px-3 py-2.5 text-xs font-medium rounded-lg border border-white/10 text-slate-300 hover:text-white min-h-[44px]"
              >
                <LogOut className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Sign Out</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <header className="border-b border-white/[0.08] bg-[#0A0C10] px-4 sm:px-8 py-3.5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation"
              className="lg:hidden p-2 rounded-md text-slate-300 hover:bg-white/[0.06] min-h-[40px] min-w-[40px] flex items-center justify-center"
            >
              <Menu className="w-5 h-5" />
            </button>
            <span className="text-sm font-medium text-slate-200 truncate">{breadcrumbLabel}</span>
          </div>

          <button
            type="button"
            onClick={() => {
              setEditingProject(null);
              setModalOpen(true);
            }}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-[#E5A93C] text-[#0A0C10] hover:bg-[#eab654] transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
          >
            New Project
          </button>
        </header>

        <main className="flex-1 px-4 sm:px-8 py-6 sm:py-8 max-w-7xl w-full mx-auto">
          {activeTab === 'projects' && (
            <ProjectsView
              projects={projects}
              loading={projectsLoading}
              error={projectsError}
              searchQuery={searchQuery}
              aspectFilter={aspectFilter}
              onSearchChange={setSearchQuery}
              onAspectFilterChange={setAspectFilter}
              onCreateNew={() => {
                setEditingProject(null);
                setModalOpen(true);
              }}
              onOpenProject={(project) => {
                setSelectedProjectId(project.id);
                setActiveTab('studio');
              }}
              onEditProject={(project) => {
                setEditingProject(project);
                setModalOpen(true);
              }}
              onDeleteProject={handleDeleteProject}
            />
          )}

          {activeTab === 'studio' && (
            <StudioView
              project={selectedProject}
              onBackToProjects={() => setActiveTab('projects')}
              onUpdateProject={handleInlineUpdateProject}
            />
          )}

          {activeTab === 'architecture' && <ArchitectureView />}

          {activeTab === 'account' && (
            <AccountView user={user} onUserUpdated={setUser} onLogout={handleLogout} />
          )}
        </main>
      </div>

      <CreateProjectModal
        open={modalOpen}
        editingProject={editingProject}
        defaultLowDataMode={user.lowDataMode}
        onClose={() => {
          setModalOpen(false);
          setEditingProject(null);
        }}
        onSave={handleSaveProjectModal}
      />
    </div>
  );
}
