# EDITMIND AI — Dependency Repair Status

## Manifest audit

- Node.js runtime requirement: `>=22.16.0`.
- All third-party packages imported by the source are declared in `dependencies` or `devDependencies`.
- Node built-ins (`node:*`, `fs`, `path`) correctly remain outside npm dependencies.
- Removed unused direct packages: `motion`, `autoprefixer`, `esbuild`.
- Removed the unused Gemini SDK dependency in the previous maintenance pass; no current source requires a Gemini API key.

## Checks in the maintenance environment

| Check | Result |
|---|---|
| `package.json` JSON parse | Passed |
| Node.js version | v22.16.0 |
| Server TypeScript syntax check | Passed: 23 files |
| FFmpeg / FFprobe executable presence | Present |
| `npm install` | Blocked: npm registry DNS returned `EAI_AGAIN` |
| `npm run typecheck` | Blocked: `@types/node` and `vite/client` unavailable because dependencies are not installed |
| `npm run build` | Blocked: Vite executable unavailable because dependencies are not installed |

## Lockfile

No lockfile is included. A valid npm lockfile cannot be safely fabricated without resolving package metadata from the registry. In a network-enabled environment, run `npm install`, verify the result, and commit the generated `package-lock.json`. Thereafter use `npm ci`.

## Next commands after transferring the project to a network-enabled machine

```bash
npm install
npm run verify
```

If `npm run verify` fails, fix the first actual TypeScript/build error before changing audio or video algorithms.
