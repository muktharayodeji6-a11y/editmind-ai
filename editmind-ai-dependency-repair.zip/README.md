# EDITMIND AI

Independent, server-side music-video editing workspace. The browser is the lightweight control surface; media analysis and future rendering are performed by the backend.

## Current implementation

- **Milestone 1:** project foundation, authentication, project workspace and configuration.
- **Milestone 2:** media library, chunked/resumable uploads, FFprobe validation, playback and low-data proxy support.
- **Milestone 3:** server-side audio analysis (BPM, beats, downbeats, tempo changes, musical sections and waveform/energy data).
- **Milestone 4:** server-side video metadata, scene/motion/quality analysis and scene thumbnails.
- **Milestones 5–8:** automatic editing, multi-track timeline, export/rendering, and final QA/deployment remain pending.

The presence of M3/M4 code does not by itself prove production accuracy. Validate with representative real-world audio/video before relying on analysis results.

## Requirements

- Node.js **22.16 or newer** (the server uses Node's built-in TypeScript stripping and `node:sqlite`).
- npm.
- FFmpeg and FFprobe available on the server `PATH`.

No Gemini API key is required for the core application or the current audio/video analysis engines.

## Install and run

```bash
npm install
npm run check:server
npm run lint
npm run build
npm run dev
```

The first successful `npm install` creates `package-lock.json`. Keep that file with the project; use `npm ci` for later reproducible installs.

For production, build the frontend and start the backend with:

```bash
NODE_ENV=production npm run build
NODE_ENV=production npm start
```

The server listens on `PORT` (default `3000`). Configuration is documented in `.env.example`.

## Data and storage

By default, SQLite and media files are stored under `./data`. Set `EDITMIND_DATA_DIR` to change this location. The local filesystem is suitable for development/single-instance testing only; use durable object storage and a production database before deploying a multi-instance service.

## Important operational notes

- Heavy audio/video processing runs on the backend.
- Uploading source media and downloading exports still consumes network data; low-data mode cannot eliminate those transfers.
- Do not expose this development instance publicly without reviewing authentication, rate limits, storage durability, secret management and upload limits.
