import { readdirSync } from 'node:fs';
import { join, relative } from 'node:path';
import { spawnSync } from 'node:child_process';

const root = process.cwd();
const files = ['server.ts', 'vite.config.ts'];

function collectTsFiles(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const fullPath = join(directory, entry.name);
    if (entry.isDirectory()) collectTsFiles(fullPath);
    else if (entry.isFile() && entry.name.endsWith('.ts')) files.push(fullPath);
  }
}

collectTsFiles(join(root, 'server'));
let failed = false;
for (const file of files) {
  const result = spawnSync(process.execPath, ['--experimental-strip-types', '--check', file], {
    cwd: root,
    encoding: 'utf8',
  });
  if (result.status !== 0) {
    failed = true;
    process.stderr.write(`\n[FAIL] ${relative(root, file)}\n${result.stderr || result.stdout}`);
  }
}

if (failed) process.exit(1);
console.log(`Server TypeScript syntax check passed (${files.length} files).`);
