import 'dotenv/config';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { pruneExpiredSessions } from './server/auth.ts';
import { config, ensureStorageDirectories } from './server/config.ts';
import { authRouter } from './server/routes/auth.ts';
import { audioAnalysisRouter } from './server/routes/audioAnalysis.ts';
import { mediaRouter } from './server/routes/media.ts';
import { projectsRouter } from './server/routes/projects.ts';
import { systemRouter } from './server/routes/system.ts';
import { videoAnalysisRouter } from './server/routes/videoAnalysis.ts';
import { sweepExpiredTempFiles } from './server/storage.ts';

async function startServer() {
  ensureStorageDirectories();
  pruneExpiredSessions();
  sweepExpiredTempFiles();

  const tempSweepTimer = setInterval(() => {
    try {
      pruneExpiredSessions();
      sweepExpiredTempFiles();
    } catch (err) {
      console.error('Background maintenance sweep failed:', err);
    }
  }, 60 * 60 * 1000);
  tempSweepTimer.unref();

  const app = express();
  app.set('trust proxy', 1);

  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  app.use(express.json({ limit: '1mb' }));

  app.use('/api/auth', authRouter);
  app.use('/api/projects', projectsRouter);
  app.use('/api/media', mediaRouter);
  app.use('/api/audio-analysis', audioAnalysisRouter);
  app.use('/api/video-analysis', videoAnalysisRouter);
  app.use('/api/system', systemRouter);
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, milestone: 4 });
  });

  if (!config.isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (req, res, next) => {
      if (req.path.startsWith('/api/')) {
        next();
        return;
      }
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Production bundle not found. Run npm run build first.');
      }
    });
  }

  app.use('/api/*', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  app.listen(config.port, '0.0.0.0', () => {
    console.log(`EDITMIND AI server listening on http://0.0.0.0:${config.port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start EDITMIND AI server:', err);
  process.exit(1);
});
